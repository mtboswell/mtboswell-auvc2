/*
 * File: torpedo_types.h
 *
 * Real-Time Workshop code generated for Simulink model torpedo.
 *
 * Model version                        : 1.63
 * Real-Time Workshop file version      : 7.6  (R2010b)  03-Aug-2010
 * Real-Time Workshop file generated on : Tue Jun 21 23:57:56 2011
 * TLC version                          : 7.6 (Jul 13 2010)
 * C/C++ source code generated on       : Tue Jun 21 23:57:56 2011
 *
 * Target selection: ert.tlc
 * Embedded hardware selection: 32-bit Generic
 * Code generation objectives: Unspecified
 * Validation result: Not run
 */

#ifndef RTW_HEADER_torpedo_types_h_
#define RTW_HEADER_torpedo_types_h_

/* Forward declaration for rtModel */
typedef struct RT_MODEL_torpedo RT_MODEL_torpedo;

#endif                                 /* RTW_HEADER_torpedo_types_h_ */

/*
 * File trailer for Real-Time Workshop generated code.
 *
 * [EOF]
 */
