/*
 * File: /home/auvt/auvc/src/vision/Final_Models/slprj/ert/_sharedutils/dbaidbaafkfkbimo_abs.h
 *
 * Real-Time Workshop code generated for Simulink model buoy_detector.
 *
 * Model version                        : 1.714
 * Real-Time Workshop file version      : 7.6  (R2010b)  03-Aug-2010
 * Real-Time Workshop file generated on : Thu Jun  9 20:26:37 2011
 * TLC version                          : 7.6 (Jul 13 2010)
 * C/C++ source code generated on       : Thu Jun  9 20:26:37 2011
 */

#ifndef SHARE_dbaidbaafkfkbimo_abs
#define SHARE_dbaidbaafkfkbimo_abs

extern void dbaidbaafkfkbimo_abs(const boolean_T x[50], real_T y[50]);

#endif

/*
 * File trailer for Real-Time Workshop generated code.
 *
 * [EOF]
 */
