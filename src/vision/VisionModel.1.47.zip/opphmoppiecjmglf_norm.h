/*
 * File: /home/auvt/auvc/src/vision/Final_Models/slprj/ert/_sharedutils/opphmoppiecjmglf_norm.h
 *
 * Real-Time Workshop code generated for Simulink model validation_gate_v4.
 *
 * Model version                        : 1.1120
 * Real-Time Workshop file version      : 7.6  (R2010b)  03-Aug-2010
 * Real-Time Workshop file generated on : Thu Jun  9 20:27:34 2011
 * TLC version                          : 7.6 (Jul 13 2010)
 * C/C++ source code generated on       : Thu Jun  9 20:27:34 2011
 */

#ifndef SHARE_opphmoppiecjmglf_norm
#define SHARE_opphmoppiecjmglf_norm

extern real_T opphmoppiecjmglf_norm(const real_T x[2]);

#endif

/*
 * File trailer for Real-Time Workshop generated code.
 *
 * [EOF]
 */
