/*
 * File: /home/auvt/auvc/src/vision/Final_Models/slprj/ert/_sharedutils/kfknaaaaecjemohd_conv2.h
 *
 * Real-Time Workshop code generated for Simulink model torpedo.
 *
 * Model version                        : 1.63
 * Real-Time Workshop file version      : 7.6  (R2010b)  03-Aug-2010
 * Real-Time Workshop file generated on : Mon Jun 20 23:28:21 2011
 * TLC version                          : 7.6 (Jul 13 2010)
 * C/C++ source code generated on       : Mon Jun 20 23:28:22 2011
 */

#ifndef SHARE_kfknaaaaecjemohd_conv2
#define SHARE_kfknaaaaecjemohd_conv2

extern void kfknaaaaecjemohd_conv2(const real_T arg1[307200], const real_T arg2
  [9], real_T c[304964]);

#endif

/*
 * File trailer for Real-Time Workshop generated code.
 *
 * [EOF]
 */
