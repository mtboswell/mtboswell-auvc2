/*
 * File: VisionModel.cpp
 *
 * Real-Time Workshop code generated for Simulink model VisionModel.
 *
 * Model version                        : 1.1598
 * Real-Time Workshop file version      : 7.6  (R2010b)  03-Aug-2010
 * Real-Time Workshop file generated on : Sat Jul 16 12:32:16 2011
 * TLC version                          : 7.6 (Jul 13 2010)
 * C/C++ source code generated on       : Sat Jul 16 12:32:17 2011
 *
 * Target selection: ert.tlc
 * Embedded hardware selection: 32-bit Generic
 * Code generation objectives: Unspecified
 * Validation result: Not run
 */

#include "VisionModel.h"
#include "VisionModel_private.h"

/* Block signals (auto storage) */
BlockIO_VisionModel VisionModel_B;

/* Block states (auto storage) */
D_Work_VisionModel VisionModel_DWork;

/* External inputs (root inport signals with auto storage) */
ExternalInputs_VisionModel VisionModel_U;

/* External outputs (root outports fed by signals with auto storage) */
ExternalOutputs_VisionModel VisionModel_Y;

/* Real-time model */
RT_MODEL_VisionModel VisionModel_M_;
RT_MODEL_VisionModel *VisionModel_M = &VisionModel_M_;

/* Forward declaration for local functions */
static void VisionModel_conv2(const real_T arg1[19200], const real_T arg2[9],
  real_T c[18644]);

/* Forward declaration for local functions */
static real_T VisionModel_sum(const real_T x[7]);
static real_T VisionModel_mod(real_T x, real_T y);
static real_T VisionModel_norm(const real_T x[2]);
static real_T VisionModel_sum_k(const real_T x[3]);
static void VisionModel_Outputs(const boolean_T U0[19200], int32_T Y0[50],
  real_T Y1[100], int32_T Y2[200], real_T Y3[50], real_T Y4[50], real_T Y5[50],
  real_T Y6[50], real_T Y7[50], uint8_T *Y8);
static void VisionModel_refp1_round(real_T *x);
int32_T div_s32_floor(int32_T numerator, int32_T denominator)
{
  int32_T quotient;
  uint32_T absNumerator;
  uint32_T absDenominator;
  uint32_T tempAbsQuotient;
  uint32_T quotientNeedsNegation;
  if (denominator == 0) {
    quotient = numerator >= 0 ? MAX_int32_T : MIN_int32_T;

    /* divide by zero handler */
  } else {
    absNumerator = (uint32_T)(numerator >= 0 ? numerator : -numerator);
    absDenominator = (uint32_T)(denominator >= 0 ? denominator : -denominator);
    quotientNeedsNegation = ((numerator < 0) != (denominator < 0));
    tempAbsQuotient = absNumerator / absDenominator;
    if (quotientNeedsNegation) {
      absNumerator = absNumerator % absDenominator;
      if (absNumerator > (uint32_T)0) {
        tempAbsQuotient = tempAbsQuotient + (uint32_T)1;
      }
    }

    quotient = quotientNeedsNegation ? (int32_T)(-((int32_T)tempAbsQuotient)) :
      (int32_T)tempAbsQuotient;
  }

  return quotient;
}

/* Function for Embedded MATLAB: '<S12>/Low Pass Filter' */
static void VisionModel_conv2(const real_T arg1[19200], const real_T arg2[9],
  real_T c[18644])
{
  int32_T j;
  int32_T jp;
  int32_T ja;
  int32_T i;
  int32_T ip;
  int32_T ia;
  real_T s;
  int32_T jb;
  int32_T jc;
  int32_T ic;
  int32_T ja_0;
  int32_T ia_0;
  for (jc = 0; jc < 118; jc++) {
    j = jc + 3;
    jp = j + 1;
    ja = jp - 3;
    for (ic = 0; ic < 158; ic++) {
      i = ic + 3;
      ip = i + 1;
      ia = ip - 3;
      s = 0.0;
      for (ja_0 = ja; ja_0 <= j; ja_0++) {
        jb = jp - ja_0;
        for (ia_0 = ia; ia_0 <= i; ia_0++) {
          s += arg1[(ja_0 - 1) * 160 + (ia_0 - 1)] * arg2[((ip - ia_0) - 1) +
            (jb - 1) * 3];
        }
      }

      c[ic + 158 * jc] = s;
    }
  }
}

/*
 * Output and update for atomic system:
 *    '<S12>/Low Pass Filter'
 *    '<S12>/Low Pass Filter1'
 *    '<S12>/Low Pass Filter2'
 */
void VisionModel_LowPassFilter(const real_T rtu_I[19200],
  rtB_LowPassFilter_VisionModel *localB)
{
  real_T G[9];
  real_T Gsum;
  int32_T i;

  /* Embedded MATLAB: '<S12>/Low Pass Filter' */
  /* Embedded MATLAB Function 'Blob_Analysis/IterativeSegmentation/Low Pass Filter/Low Pass Filter': '<S14>:1' */
  /*  This function calculates the gaussian blur of an intensity image */
  /*  Gaussian matrix rows */
  /*  Gaussian matrix columns */
  /* '<S14>:1:11' */
  memset((void *)(&localB->Iout[0]), 0, 19200U * sizeof(real_T));

  /* '<S14>:1:17' */
  memset((void *)&G[0], 0, 9U * sizeof(real_T));

  /* '<S14>:1:19' */
  /* '<S14>:1:21' */
  /* '<S14>:1:23' */
  Gsum = 0.0;

  /* '<S14>:1:24' */
  for (i = -1; i < 2; i++) {
    /* '<S14>:1:24' */
    /* '<S14>:1:25' */
    /* '<S14>:1:26' */
    G[i + 1] = exp((-((real_T)(i * i) + 1.0)) / 4.0000000000000009);

    /* '<S14>:1:27' */
    Gsum += G[i + 1];

    /* '<S14>:1:25' */
    /* '<S14>:1:26' */
    G[i + 4] = exp((real_T)(-(i * i)) / 4.0000000000000009);

    /* '<S14>:1:27' */
    Gsum += G[i + 4];

    /* '<S14>:1:25' */
    /* '<S14>:1:26' */
    G[i + 7] = exp((-((real_T)(i * i) + 1.0)) / 4.0000000000000009);

    /* '<S14>:1:27' */
    Gsum += G[i + 7];
  }

  /* '<S14>:1:31' */
  for (i = 0; i < 9; i++) {
    G[i] = G[i] / Gsum;
  }

  /* '<S14>:1:33' */
  VisionModel_conv2(&rtu_I[0], G, &localB->Itemp[0]);

  /*  reflect boundaries to keep image the same size */
  /*  top */
  /* '<S14>:1:37' */
  for (i = 0; i < 118; i++) {
    localB->Iout[160 * (1 + i)] = localB->Itemp[158 * i];
  }

  /*  bottom */
  /* '<S14>:1:39' */
  for (i = 0; i < 118; i++) {
    localB->Iout[159 + 160 * (1 + i)] = localB->Itemp[158 * i + 157];
  }

  /*  left */
  /* '<S14>:1:41' */
  memcpy((void *)(&localB->Iout[1]), (void *)(&localB->Itemp[0]), 158U * sizeof
         (real_T));

  /*  right */
  /* '<S14>:1:43' */
  memcpy((void *)(&localB->Iout[19041]), (void *)(&localB->Itemp[18486]), 158U *
         sizeof(real_T));

  /*  center */
  /* '<S14>:1:45' */
  for (i = 0; i < 118; i++) {
    memcpy((void *)(&localB->Iout[1 + 160 * (1 + i)]), (void *)(&localB->Itemp
            [158 * i]), 158U * sizeof(real_T));
  }

  /*  top left corner */
  /* '<S14>:1:47' */
  localB->Iout[0] = localB->Itemp[0];

  /*  top right corner */
  /* '<S14>:1:49' */
  localB->Iout[18880] = localB->Itemp[18328];
  localB->Iout[19040] = localB->Itemp[18486];

  /*  bottom left corner */
  /* '<S14>:1:51' */
  localB->Iout[158] = localB->Itemp[156];
  localB->Iout[159] = localB->Itemp[157];

  /*  bottom right corner */
  /* '<S14>:1:53' */
  localB->Iout[19038] = localB->Itemp[18484];
  localB->Iout[19039] = localB->Itemp[18485];
  localB->Iout[19198] = localB->Itemp[18642];
  localB->Iout[19199] = localB->Itemp[18643];
}

/*
 * Output and update for atomic system:
 *    '<S39>/Transform Coordinates3'
 *    '<S31>/Transform Coordinates3'
 *    '<S36>/Transform Coordinates3'
 *    '<S28>/Transform Coordinates3'
 */
void VisionMod_TransformCoordinates3(real_T rtu_which_camera, real_T rtu_x_in,
  real_T rtu_y_in, real_T rtu_z_in, const real_T rtu_Camera_Dimensions[2],
  rtB_TransformCoordinates3_Visio *localB)
{
  /* Embedded MATLAB: '<S39>/Transform Coordinates3' */
  /* Embedded MATLAB Function 'validation_gate/If Action Subsystem/Transform Coordinates3': '<S40>:1' */
  /*  This function, "transform Global to Local coordinates," transforms */
  /*    global coordinates that are sent to the controller into local */
  /*    coordinates that can be displayed over images. */
  /*  */
  /*  5-29-11 */
  /*  */
  /*  Input */
  /*    x_in, y_in, z_in = vectors of points in global (vehicle-centered) */
  /*      coordinate system */
  /*    bw_image_in = a 2-D array of pixel values (used only to extract image */
  /*      size) */
  /*    which_camera = selects which camera for relative coordinates */
  /*                 = 0 -> Forward camera */
  /*                 = 1 -> Down camera */
  /*  */
  /*  Output */
  /*    r_out, c_out = row, column pairs in local coordinate system */
  /* '<S40>:1:20' */
  /* '<S40>:1:21' */
  if (rtu_which_camera == 0.0) {
    /* '<S40>:1:22' */
    /* '<S40>:1:23' */
    localB->points[0] = floor(rtu_Camera_Dimensions[0] / 2.0) + rtu_z_in;
    localB->points[1] = floor(rtu_Camera_Dimensions[1] / 2.0) + rtu_y_in;
  } else {
    /* '<S40>:1:26' */
    localB->points[0] = floor(rtu_Camera_Dimensions[0] / 2.0) - rtu_x_in;
    localB->points[1] = floor(rtu_Camera_Dimensions[1] / 2.0) + rtu_y_in;
  }
}

/*
 * Output and update for action system:
 *    '<S5>/If Action Subsystem'
 *    '<S7>/If Action Subsystem'
 *    '<S4>/If Action Subsystem'
 */
void VisionModel_IfActionSubsystem(const real_T rtu_R_in[19200], real_T
  rtu_which_camera, real_T rtu_x_in, real_T rtu_y_in, real_T rtu_z_in, const
  real_T rtu_Camera_Dimensions[2], rtB_IfActionSubsystem_VisionMod *localB,
  rtP_IfActionSubsystem_VisionMod *localP)
{
  int32_T idxROI;
  int32_T row;
  int32_T col;
  int32_T size;
  int32_T in;
  int32_T idxPix;
  boolean_T isInBound;
  boolean_T visited;
  boolean_T visited_0;
  boolean_T done;
  int32_T OutCode;
  int32_T i;
  int32_T line_idx;
  int32_T line_idx_0;
  int32_T line_idx_1;
  int32_T line_idx_2;
  int32_T line_idx_3;
  int32_T line_idx_4;
  int32_T line_idx_5;
  int32_T line_idx_6;
  real_T tmp;

  /* Embedded MATLAB: '<S31>/Transform Coordinates3' */
  VisionMod_TransformCoordinates3(rtu_which_camera, rtu_x_in, rtu_y_in, rtu_z_in,
    rtu_Camera_Dimensions, &localB->sf_TransformCoordinates3);

  /* S-Function (svipdrawmarkers): '<S31>/Draw Target' */
  /* Copy the image from input to output. */
  for (i = 0; i < 19200; i++) {
    localB->DrawTarget_o1[i] = rtu_R_in[i];
    localB->DrawTarget_o2[i] = rtu_R_in[i];
    localB->DrawTarget_o3[i] = rtu_R_in[i];
  }

  /* Draw all X marks. */
  tmp = localP->DrawTarget_RTP_SIZE;
  if ((localP->DrawTarget_RTP_SIZE < 4.503599627370496E+15) &&
      (localP->DrawTarget_RTP_SIZE > -4.503599627370496E+15)) {
    tmp = floor(localP->DrawTarget_RTP_SIZE + 0.5);
  }

  size = (int32_T)tmp;
  for (idxROI = 0; idxROI < 2; idxROI += 2) {
    tmp = localB->sf_TransformCoordinates3.points[idxROI];
    if ((localB->sf_TransformCoordinates3.points[idxROI] < 4.503599627370496E+15)
        && (localB->sf_TransformCoordinates3.points[idxROI] >
            -4.503599627370496E+15)) {
      tmp = floor(localB->sf_TransformCoordinates3.points[idxROI] + 0.5);
    }

    row = (int32_T)tmp;
    tmp = localB->sf_TransformCoordinates3.points[idxROI + 1];
    if ((localB->sf_TransformCoordinates3.points[idxROI + 1] <
         4.503599627370496E+15) && (localB->
         sf_TransformCoordinates3.points[idxROI + 1] > -4.503599627370496E+15))
    {
      tmp = floor(localB->sf_TransformCoordinates3.points[idxROI + 1] + 0.5);
    }

    col = (int32_T)tmp;
    line_idx = row - size;
    line_idx_0 = col - size;
    line_idx_1 = row + size;
    line_idx_2 = col + size;
    isInBound = FALSE;

    /* Find the visible portion of a line. */
    visited = FALSE;
    visited_0 = FALSE;
    done = FALSE;
    line_idx_4 = line_idx;
    line_idx_3 = line_idx_0;
    line_idx_5 = line_idx_1;
    line_idx_6 = line_idx_2;
    while (!done) {
      in = 0;
      OutCode = 0;

      /* Determine viewport violations. */
      if (line_idx_4 < 0) {
        in = 4;
      } else {
        if (line_idx_4 > 159) {
          in = 8;
        }
      }

      if (line_idx_5 < 0) {
        OutCode = 4;
      } else {
        if (line_idx_5 > 159) {
          OutCode = 8;
        }
      }

      if (line_idx_3 < 0) {
        in = (int32_T)((uint32_T)in | 1U);
      } else {
        if (line_idx_3 > 119) {
          in = (int32_T)((uint32_T)in | 2U);
        }
      }

      if (line_idx_6 < 0) {
        OutCode = (int32_T)((uint32_T)OutCode | 1U);
      } else {
        if (line_idx_6 > 119) {
          OutCode = (int32_T)((uint32_T)OutCode | 2U);
        }
      }

      if (!((uint32_T)in | (uint32_T)OutCode)) {
        /* Line falls completely within bounds. */
        done = TRUE;
        isInBound = TRUE;
      } else if ((uint32_T)in & (uint32_T)OutCode) {
        /* Line falls completely out of bounds. */
        done = TRUE;
        isInBound = FALSE;
      } else if ((uint32_T)in != 0U) {
        /* Clip 1st point; if it's in-bounds, clip 2nd point. */
        if (visited) {
          line_idx_4 = line_idx;
          line_idx_3 = line_idx_0;
        }

        i = line_idx_5 - line_idx_4;
        idxPix = line_idx_6 - line_idx_3;
        if ((uint32_T)in & 4U) {
          /* Violated RMin. */
          in = (0 - line_idx_4) * idxPix;
          if (((in >= 0) && (i >= 0)) || ((in < 0) && (i < 0))) {
            line_idx_3 += (div_s32_floor(in << 1U, i) + 1) >> 1;
          } else {
            line_idx_3 += -((div_s32_floor((-in) << 1U, i) + 1) >> 1);
          }

          line_idx_4 = 0;
          visited = TRUE;
        } else if ((uint32_T)in & 8U) {
          /* Violated RMax. */
          in = (159 - line_idx_4) * idxPix;
          if (((in >= 0) && (i >= 0)) || ((in < 0) && (i < 0))) {
            line_idx_3 += (div_s32_floor(in << 1U, i) + 1) >> 1;
          } else {
            line_idx_3 += -((div_s32_floor((-in) << 1U, i) + 1) >> 1);
          }

          line_idx_4 = 159;
          visited = TRUE;
        } else if ((uint32_T)in & 1U) {
          /* Violated CMin. */
          in = (0 - line_idx_3) * i;
          if (((in >= 0) && (idxPix >= 0)) || ((in < 0) && (idxPix < 0))) {
            line_idx_4 += (div_s32_floor(in << 1U, idxPix) + 1) >> 1;
          } else {
            line_idx_4 += -((div_s32_floor((-in) << 1U, idxPix) + 1) >> 1);
          }

          line_idx_3 = 0;
          visited = TRUE;
        } else {
          /* Violated CMax. */
          in = (119 - line_idx_3) * i;
          if (((in >= 0) && (idxPix >= 0)) || ((in < 0) && (idxPix < 0))) {
            line_idx_4 += (div_s32_floor(in << 1U, idxPix) + 1) >> 1;
          } else {
            line_idx_4 += -((div_s32_floor((-in) << 1U, idxPix) + 1) >> 1);
          }

          line_idx_3 = 119;
          visited = TRUE;
        }
      } else {
        /* Clip the 2nd point. */
        if (visited_0) {
          line_idx_5 = line_idx_1;
          line_idx_6 = line_idx_2;
        }

        i = line_idx_5 - line_idx_4;
        idxPix = line_idx_6 - line_idx_3;
        if ((uint32_T)OutCode & 4U) {
          /* Violated RMin. */
          in = (0 - line_idx_5) * idxPix;
          if (((in >= 0) && (i >= 0)) || ((in < 0) && (i < 0))) {
            line_idx_6 += (div_s32_floor(in << 1U, i) + 1) >> 1;
          } else {
            line_idx_6 += -((div_s32_floor((-in) << 1U, i) + 1) >> 1);
          }

          line_idx_5 = 0;
          visited_0 = TRUE;
        } else if ((uint32_T)OutCode & 8U) {
          /* Violated RMax. */
          in = (159 - line_idx_5) * idxPix;
          if (((in >= 0) && (i >= 0)) || ((in < 0) && (i < 0))) {
            line_idx_6 += (div_s32_floor(in << 1U, i) + 1) >> 1;
          } else {
            line_idx_6 += -((div_s32_floor((-in) << 1U, i) + 1) >> 1);
          }

          line_idx_5 = 159;
          visited_0 = TRUE;
        } else if ((uint32_T)OutCode & 1U) {
          /* Violated CMin. */
          in = (0 - line_idx_6) * i;
          if (((in >= 0) && (idxPix >= 0)) || ((in < 0) && (idxPix < 0))) {
            line_idx_5 += (div_s32_floor(in << 1U, idxPix) + 1) >> 1;
          } else {
            line_idx_5 += -((div_s32_floor((-in) << 1U, idxPix) + 1) >> 1);
          }

          line_idx_6 = 0;
          visited_0 = TRUE;
        } else {
          /* Violated CMax. */
          in = (119 - line_idx_6) * i;
          if (((in >= 0) && (idxPix >= 0)) || ((in < 0) && (idxPix < 0))) {
            line_idx_5 += (div_s32_floor(in << 1U, idxPix) + 1) >> 1;
          } else {
            line_idx_5 += -((div_s32_floor((-in) << 1U, idxPix) + 1) >> 1);
          }

          line_idx_6 = 119;
          visited_0 = TRUE;
        }
      }
    }

    if (isInBound) {
      idxPix = line_idx_3 * 160 + line_idx_4;
      for (in = line_idx_4; in <= line_idx_5; in++) {
        localB->DrawTarget_o1[idxPix] = localP->DrawTarget_RTP_FILLCOLOR[0];
        localB->DrawTarget_o2[idxPix] = localP->DrawTarget_RTP_FILLCOLOR[1];
        localB->DrawTarget_o3[idxPix] = localP->DrawTarget_RTP_FILLCOLOR[2];
        idxPix += 161;
      }
    }

    line_idx = row - size;
    line_idx_0 = col + size;
    line_idx_1 = row + size;
    line_idx_2 = col - size;
    isInBound = FALSE;

    /* Find the visible portion of a line. */
    visited = FALSE;
    visited_0 = FALSE;
    done = FALSE;
    line_idx_4 = line_idx;
    line_idx_3 = line_idx_0;
    line_idx_5 = line_idx_1;
    line_idx_6 = line_idx_2;
    while (!done) {
      in = 0;
      OutCode = 0;

      /* Determine viewport violations. */
      if (line_idx_4 < 0) {
        in = 4;
      } else {
        if (line_idx_4 > 159) {
          in = 8;
        }
      }

      if (line_idx_5 < 0) {
        OutCode = 4;
      } else {
        if (line_idx_5 > 159) {
          OutCode = 8;
        }
      }

      if (line_idx_3 < 0) {
        in = (int32_T)((uint32_T)in | 1U);
      } else {
        if (line_idx_3 > 119) {
          in = (int32_T)((uint32_T)in | 2U);
        }
      }

      if (line_idx_6 < 0) {
        OutCode = (int32_T)((uint32_T)OutCode | 1U);
      } else {
        if (line_idx_6 > 119) {
          OutCode = (int32_T)((uint32_T)OutCode | 2U);
        }
      }

      if (!((uint32_T)in | (uint32_T)OutCode)) {
        /* Line falls completely within bounds. */
        done = TRUE;
        isInBound = TRUE;
      } else if ((uint32_T)in & (uint32_T)OutCode) {
        /* Line falls completely out of bounds. */
        done = TRUE;
        isInBound = FALSE;
      } else if ((uint32_T)in != 0U) {
        /* Clip 1st point; if it's in-bounds, clip 2nd point. */
        if (visited) {
          line_idx_4 = line_idx;
          line_idx_3 = line_idx_0;
        }

        i = line_idx_5 - line_idx_4;
        idxPix = line_idx_6 - line_idx_3;
        if ((uint32_T)in & 4U) {
          /* Violated RMin. */
          in = (0 - line_idx_4) * idxPix;
          if (((in >= 0) && (i >= 0)) || ((in < 0) && (i < 0))) {
            line_idx_3 += (div_s32_floor(in << 1U, i) + 1) >> 1;
          } else {
            line_idx_3 += -((div_s32_floor((-in) << 1U, i) + 1) >> 1);
          }

          line_idx_4 = 0;
          visited = TRUE;
        } else if ((uint32_T)in & 8U) {
          /* Violated RMax. */
          in = (159 - line_idx_4) * idxPix;
          if (((in >= 0) && (i >= 0)) || ((in < 0) && (i < 0))) {
            line_idx_3 += (div_s32_floor(in << 1U, i) + 1) >> 1;
          } else {
            line_idx_3 += -((div_s32_floor((-in) << 1U, i) + 1) >> 1);
          }

          line_idx_4 = 159;
          visited = TRUE;
        } else if ((uint32_T)in & 1U) {
          /* Violated CMin. */
          in = (0 - line_idx_3) * i;
          if (((in >= 0) && (idxPix >= 0)) || ((in < 0) && (idxPix < 0))) {
            line_idx_4 += (div_s32_floor(in << 1U, idxPix) + 1) >> 1;
          } else {
            line_idx_4 += -((div_s32_floor((-in) << 1U, idxPix) + 1) >> 1);
          }

          line_idx_3 = 0;
          visited = TRUE;
        } else {
          /* Violated CMax. */
          in = (119 - line_idx_3) * i;
          if (((in >= 0) && (idxPix >= 0)) || ((in < 0) && (idxPix < 0))) {
            line_idx_4 += (div_s32_floor(in << 1U, idxPix) + 1) >> 1;
          } else {
            line_idx_4 += -((div_s32_floor((-in) << 1U, idxPix) + 1) >> 1);
          }

          line_idx_3 = 119;
          visited = TRUE;
        }
      } else {
        /* Clip the 2nd point. */
        if (visited_0) {
          line_idx_5 = line_idx_1;
          line_idx_6 = line_idx_2;
        }

        i = line_idx_5 - line_idx_4;
        idxPix = line_idx_6 - line_idx_3;
        if ((uint32_T)OutCode & 4U) {
          /* Violated RMin. */
          in = (0 - line_idx_5) * idxPix;
          if (((in >= 0) && (i >= 0)) || ((in < 0) && (i < 0))) {
            line_idx_6 += (div_s32_floor(in << 1U, i) + 1) >> 1;
          } else {
            line_idx_6 += -((div_s32_floor((-in) << 1U, i) + 1) >> 1);
          }

          line_idx_5 = 0;
          visited_0 = TRUE;
        } else if ((uint32_T)OutCode & 8U) {
          /* Violated RMax. */
          in = (159 - line_idx_5) * idxPix;
          if (((in >= 0) && (i >= 0)) || ((in < 0) && (i < 0))) {
            line_idx_6 += (div_s32_floor(in << 1U, i) + 1) >> 1;
          } else {
            line_idx_6 += -((div_s32_floor((-in) << 1U, i) + 1) >> 1);
          }

          line_idx_5 = 159;
          visited_0 = TRUE;
        } else if ((uint32_T)OutCode & 1U) {
          /* Violated CMin. */
          in = (0 - line_idx_6) * i;
          if (((in >= 0) && (idxPix >= 0)) || ((in < 0) && (idxPix < 0))) {
            line_idx_5 += (div_s32_floor(in << 1U, idxPix) + 1) >> 1;
          } else {
            line_idx_5 += -((div_s32_floor((-in) << 1U, idxPix) + 1) >> 1);
          }

          line_idx_6 = 0;
          visited_0 = TRUE;
        } else {
          /* Violated CMax. */
          in = (119 - line_idx_6) * i;
          if (((in >= 0) && (idxPix >= 0)) || ((in < 0) && (idxPix < 0))) {
            line_idx_5 += (div_s32_floor(in << 1U, idxPix) + 1) >> 1;
          } else {
            line_idx_5 += -((div_s32_floor((-in) << 1U, idxPix) + 1) >> 1);
          }

          line_idx_6 = 119;
          visited_0 = TRUE;
        }
      }
    }

    if (isInBound) {
      idxPix = line_idx_3 * 160 + line_idx_4;
      for (in = line_idx_4; in <= line_idx_5; in++) {
        localB->DrawTarget_o1[idxPix] = localP->DrawTarget_RTP_FILLCOLOR[0];
        localB->DrawTarget_o2[idxPix] = localP->DrawTarget_RTP_FILLCOLOR[1];
        localB->DrawTarget_o3[idxPix] = localP->DrawTarget_RTP_FILLCOLOR[2];
        idxPix += -159;
      }
    }
  }
}

/* Function for Embedded MATLAB: '<S1>/Blob Extraction' */
static real_T VisionModel_sum(const real_T x[7])
{
  real_T y;
  int32_T k;
  y = x[0];
  for (k = 2; k < 8; k++) {
    y += x[k - 1];
  }

  return y;
}

/* Function for Embedded MATLAB: '<S4>/Identify L-Obstacle' */
static real_T VisionModel_mod(real_T x, real_T y)
{
  real_T r;
  real_T b_x;
  if (y == 0.0) {
    return x;
  } else if (y == floor(y)) {
    return x - floor(x / y) * y;
  } else {
    r = x / y;
    if (r < 0.0) {
      b_x = ceil(r - 0.5);
    } else {
      b_x = floor(r + 0.5);
    }

    if (fabs(r - b_x) <= 2.2204460492503131E-16 * fabs(r)) {
      return 0.0;
    } else {
      return (r - floor(r)) * y;
    }
  }
}

/* Function for Embedded MATLAB: '<S8>/Identify Validation Gate' */
static real_T VisionModel_norm(const real_T x[2])
{
  real_T y;
  real_T scale;
  boolean_T firstNonZero;
  real_T absxk;
  real_T t;
  y = 0.0;
  scale = 0.0;
  firstNonZero = TRUE;
  if (x[0] != 0.0) {
    scale = fabs(x[0]);
    y = 1.0;
    firstNonZero = FALSE;
  }

  if (x[1] != 0.0) {
    absxk = fabs(x[1]);
    if (firstNonZero) {
      scale = absxk;
      y = 1.0;
    } else if (scale < absxk) {
      t = scale / absxk;
      y = y * t * t + 1.0;
      scale = absxk;
    } else {
      t = absxk / scale;
      y += t * t;
    }
  }

  return scale * sqrt(y);
}

/* Function for Embedded MATLAB: '<S8>/Identify Validation Gate' */
static real_T VisionModel_sum_k(const real_T x[3])
{
  return (x[0] + x[1]) + x[2];
}

/* Function for Embedded MATLAB: '<S1>/Blob Extraction' */
static void VisionModel_Outputs(const boolean_T U0[19200], int32_T Y0[50],
  real_T Y1[100], int32_T Y2[200], real_T Y3[50], real_T Y4[50], real_T Y5[50],
  real_T Y6[50], real_T Y7[50], uint8_T *Y8)
{
  boolean_T maxNumBlobsReached;
  int32_T loop;
  uint8_T currentLabel;
  int32_T idx;
  int32_T n;
  uint32_T stackIdx;
  uint32_T pixIdx;
  uint32_T start_pixIdx;
  uint32_T walkerIdx;
  int32_T numBlobs;
  int32_T pixListMinc;
  int32_T pixListNinc;
  int32_T c_i;
  int32_T j;
  int32_T maxc;
  int32_T maxr;
  real_T xs;
  real_T ys;
  real_T xys;
  uint32_T k;
  real_T uxy;
  real_T common;
  real_T minorAxis;
  real_T majorAxisLen;
  real_T centroid_idx;
  real_T centroid_idx_0;

  /* System object Outputs function: video.BlobAnalysis */
  maxNumBlobsReached = FALSE;
  memset((void *)(&VisionModel_DWork.PAD_DW[0]), (int32_T)0U, 163U * sizeof
         (uint8_T));
  currentLabel = 1U;
  loop = 0;
  idx = 163;
  for (n = 0; n < 120; n++) {
    for (maxc = 0; maxc < 160; maxc++) {
      VisionModel_DWork.PAD_DW[idx] = (uint8_T)(U0[loop] ? 255 : 0);
      loop++;
      idx++;
    }

    VisionModel_DWork.PAD_DW[idx] = 0U;
    idx++;
    VisionModel_DWork.PAD_DW[idx] = 0U;
    idx++;
  }

  memset((void *)(&VisionModel_DWork.PAD_DW[idx]), (int32_T)0U, 161U * sizeof
         (uint8_T));
  loop = 1;
  stackIdx = 0U;
  pixIdx = 0U;
  for (n = 0; n < 120; n++) {
    maxc = 1;
    idx = loop * 162;
    for (maxr = 0; maxr < 160; maxr++) {
      k = (uint32_T)(idx + maxc);
      start_pixIdx = pixIdx;
      if (VisionModel_DWork.PAD_DW[k] == 255) {
        VisionModel_DWork.PAD_DW[k] = currentLabel;
        VisionModel_DWork.N_PIXLIST_DW[pixIdx] = (int16_T)(loop - 1);
        VisionModel_DWork.M_PIXLIST_DW[pixIdx] = (int16_T)(maxc - 1);
        pixIdx++;
        VisionModel_DWork.NUM_PIX_DW[currentLabel - 1] = 1U;
        VisionModel_DWork.STACK_DW[stackIdx] = k;
        stackIdx++;
        while (stackIdx) {
          stackIdx--;
          k = VisionModel_DWork.STACK_DW[stackIdx];
          for (j = 0; j < 8; j++) {
            walkerIdx = k + (uint32_T)VisionModel_DWork.WALKER_RTP[j];
            if (VisionModel_DWork.PAD_DW[walkerIdx] == 255) {
              VisionModel_DWork.PAD_DW[walkerIdx] = currentLabel;
              VisionModel_DWork.N_PIXLIST_DW[pixIdx] = (int16_T)((int16_T)
                (walkerIdx / 162U) - 1);
              VisionModel_DWork.M_PIXLIST_DW[pixIdx] = (int16_T)(walkerIdx %
                162U - 1U);
              pixIdx++;
              VisionModel_DWork.NUM_PIX_DW[currentLabel - 1] =
                VisionModel_DWork.NUM_PIX_DW[currentLabel - 1] + 1U;
              VisionModel_DWork.STACK_DW[stackIdx] = walkerIdx;
              stackIdx++;
            }
          }
        }

        if (VisionModel_DWork.NUM_PIX_DW[currentLabel - 1] <
            VisionModel_DWork.MINAREA_RTP) {
          currentLabel--;
          pixIdx = start_pixIdx;
        }

        if (currentLabel == 50) {
          maxNumBlobsReached = TRUE;
          n = 120;
          maxr = 160;
        }

        if (maxr < 160) {
          currentLabel++;
        }
      }

      maxc++;
    }

    loop++;
  }

  numBlobs = maxNumBlobsReached ? currentLabel : (uint8_T)(currentLabel - 1);
  *Y8 = (uint8_T)numBlobs;
  pixListMinc = 0;
  pixListNinc = 0;
  for (c_i = 0; c_i < numBlobs; c_i++) {
    Y0[c_i] = (int32_T)VisionModel_DWork.NUM_PIX_DW[c_i];
    loop = 0;
    n = 0;
    for (j = 0; j < (int32_T)VisionModel_DWork.NUM_PIX_DW[c_i]; j++) {
      loop += VisionModel_DWork.N_PIXLIST_DW[j + pixListNinc];
      n += VisionModel_DWork.M_PIXLIST_DW[j + pixListMinc];
    }

    centroid_idx = (real_T)n / (real_T)VisionModel_DWork.NUM_PIX_DW[c_i];
    centroid_idx_0 = (real_T)loop / (real_T)VisionModel_DWork.NUM_PIX_DW[c_i];
    Y1[c_i << 1] = centroid_idx;
    Y1[(c_i << 1) + 1] = centroid_idx_0;
    n = 120;
    idx = 160;
    maxc = 0;
    maxr = 0;
    for (j = 0; j < (int32_T)VisionModel_DWork.NUM_PIX_DW[c_i]; j++) {
      loop = j + pixListNinc;
      if (VisionModel_DWork.N_PIXLIST_DW[loop] < n) {
        n = VisionModel_DWork.N_PIXLIST_DW[loop];
      }

      if (VisionModel_DWork.N_PIXLIST_DW[loop] > maxc) {
        maxc = VisionModel_DWork.N_PIXLIST_DW[loop];
      }

      loop = j + pixListMinc;
      if (VisionModel_DWork.M_PIXLIST_DW[loop] < idx) {
        idx = VisionModel_DWork.M_PIXLIST_DW[loop];
      }

      if (VisionModel_DWork.M_PIXLIST_DW[loop] > maxr) {
        maxr = VisionModel_DWork.M_PIXLIST_DW[loop];
      }
    }

    maxr = (maxr + 1) - idx;
    j = (maxc + 1) - n;
    loop = c_i << 2;
    Y2[loop] = idx;
    Y2[loop + 1] = n;
    Y2[loop + 2] = maxr;
    Y2[loop + 3] = j;
    xs = 0.0;
    ys = 0.0;
    xys = 0.0;
    for (k = 0U; (int32_T)k < (int32_T)VisionModel_DWork.NUM_PIX_DW[c_i]; k++) {
      uxy = (real_T)VisionModel_DWork.N_PIXLIST_DW[pixListNinc + (int32_T)k] -
        centroid_idx_0;
      common = (real_T)VisionModel_DWork.M_PIXLIST_DW[pixListMinc + (int32_T)k]
        - centroid_idx;
      xs += uxy * uxy;
      ys += common * common;
      xys += uxy * (-common);
    }

    centroid_idx = xs / (real_T)VisionModel_DWork.NUM_PIX_DW[c_i] +
      0.083333333333333329;
    centroid_idx_0 = ys / (real_T)VisionModel_DWork.NUM_PIX_DW[c_i] +
      0.083333333333333329;
    uxy = xys / (real_T)VisionModel_DWork.NUM_PIX_DW[c_i];
    common = sqrt((centroid_idx - centroid_idx_0) * (centroid_idx -
      centroid_idx_0) + uxy * uxy * 4.0);
    xs = ((centroid_idx + centroid_idx_0) + common) * 8.0;
    minorAxis = ((centroid_idx + centroid_idx_0) - common) * 8.0;
    majorAxisLen = sqrt(xs);
    ys = sqrt(xs - minorAxis) / majorAxisLen;
    if (centroid_idx_0 > centroid_idx) {
      xys = (centroid_idx_0 - centroid_idx) + common;
      xs = 2.0 * uxy;
    } else {
      xys = 2.0 * uxy;
      xs = (centroid_idx - centroid_idx_0) + common;
    }

    minorAxis = sqrt(minorAxis);
    Y3[c_i] = majorAxisLen;
    Y4[c_i] = minorAxis;
    Y5[c_i] = atan(xys / (xs + 2.2204460492503131E-16));
    Y6[c_i] = ys;
    Y7[c_i] = (real_T)VisionModel_DWork.NUM_PIX_DW[c_i] / (real_T)(maxr * j);
    pixListMinc += (int32_T)VisionModel_DWork.NUM_PIX_DW[c_i];
    pixListNinc += (int32_T)VisionModel_DWork.NUM_PIX_DW[c_i];
  }

  for (loop = numBlobs; loop < 50; loop++) {
    Y0[loop] = VisionModel_DWork.F0_RTP;
  }

  for (loop = (int32_T)((uint32_T)numBlobs << 1); loop < 100; loop++) {
    Y1[loop] = VisionModel_DWork.F1_RTP;
  }

  for (loop = (int32_T)((uint32_T)numBlobs << 2); loop < 200; loop++) {
    Y2[loop] = VisionModel_DWork.F2_RTP;
  }

  for (loop = numBlobs; loop < 50; loop++) {
    Y3[loop] = VisionModel_DWork.F3_RTP;
  }

  for (loop = numBlobs; loop < 50; loop++) {
    Y4[loop] = VisionModel_DWork.F4_RTP;
  }

  for (loop = numBlobs; loop < 50; loop++) {
    Y5[loop] = VisionModel_DWork.F5_RTP;
  }

  for (loop = numBlobs; loop < 50; loop++) {
    Y6[loop] = VisionModel_DWork.F6_RTP;
  }

  for (loop = numBlobs; loop < 50; loop++) {
    Y7[loop] = VisionModel_DWork.F7_RTP;
  }
}

/* Function for Embedded MATLAB: '<S1>/Blob Extraction' */
static void VisionModel_refp1_round(real_T *x)
{
  if (*x < 0.0) {
    *x = ceil(*x - 0.5);
  } else {
    *x = floor(*x + 0.5);
  }
}

/* Model step function */
void VisionModel_step(void)
{
  int32_T flag;
  int32_T j;
  real_T ref_color_L_avg[50];
  real_T ref_color_a_avg[50];
  real_T ref_color_b_avg[50];
  real_T color_count[50];
  int32_T blob_area[50];
  int32_T blob_bbox[200];
  int8_T blob_color[50];
  int32_T find_white;
  int32_T find_black;
  real_T L_white;
  real_T L_black;
  real_T positive_area;
  boolean_T condition;
  uint8_T c_i;
  int32_T TArea[50];
  real_T TCentroid[100];
  int32_T TBBox[200];
  real_T TExtent[50];
  uint8_T TNumBlobs;
  boolean_T exitg;
  uint8_T rbinv[6];
  real_T ravgv[6];
  real_T tavgv[6];
  real_T vbinv[6];
  uint8_T rbinh[6];
  real_T ravgh[6];
  real_T tavgh[6];
  real_T vbinh[6];
  real_T u[2];
  boolean_T guard;
  int32_T idxROI;
  int32_T idxStart;
  real_T rho[200];
  real_T theta[200];
  int16_T i_index[200];
  uint8_T j_index[200];
  real_T theta_hold[200];
  int32_T found;
  real_T r;
  real_T c;
  boolean_T c_0;
  boolean_T exitg_0;
  int32_T imgIdxLL;
  int32_T imgIdxLR;
  real_T accumOne;
  real_T accumTwo;
  int32_T m;
  real_T accumThree;
  real_T accumFour;
  real_T Resize2_LineBuffer[160];
  int32_T i;
  real_T rtb_rho_gate_0[3];
  int32_T line_idx;
  int32_T line_idx_0;
  int32_T line_idx_1;
  int32_T line_idx_2;
  int32_T line_idx_3;
  int32_T line_idx_4;
  int32_T line_idx_5;
  int32_T line_idx_6;
  real_T rtb_theta_gate_idx;
  real_T rtb_rho_gate_idx;
  real_T rtb_theta_gate_idx_0;
  real_T rtb_rho_gate_idx_0;
  real_T i_gate_idx;
  real_T i_gate_idx_0;
  uint8_T tmp;
  for (i = 0; i < 19200; i++) {
    /* Product: '<S3>/Divide' incorporates:
     *  Inport: '<Root>/R_forward_in'
     *  Inport: '<Root>/Scale_Forward_R'
     */
    VisionModel_B.Divide5[i] = VisionModel_U.R_forward_in[i] *
      VisionModel_U.Scale_Forward_R;

    /* Product: '<S3>/Divide1' incorporates:
     *  Inport: '<Root>/G_forward_in'
     *  Inport: '<Root>/Scale_Forward_G'
     */
    VisionModel_B.Divide4[i] = VisionModel_U.G_forward_in[i] *
      VisionModel_U.Scale_Forward_G;

    /* Product: '<S3>/Divide2' incorporates:
     *  Inport: '<Root>/B_forward_in'
     *  Inport: '<Root>/Scale_Forward_B'
     */
    VisionModel_B.Divide3[i] = VisionModel_U.B_forward_in[i] *
      VisionModel_U.Scale_Forward_B;
  }

  /* S-Function (svipcolorconv): '<S3>/Color Space  Conversion1' */
  /* temporary variables for in-place operation */
  for (i = 0; i < 19200; i++) {
    /* First get the min and max of the RGB triplet */
    if (VisionModel_B.Divide5[i] > VisionModel_B.Divide4[i]) {
      if (VisionModel_B.Divide4[i] < VisionModel_B.Divide3[i]) {
        accumOne = VisionModel_B.Divide4[i];
      } else {
        accumOne = VisionModel_B.Divide3[i];
      }

      if (VisionModel_B.Divide5[i] > VisionModel_B.Divide3[i]) {
        accumTwo = VisionModel_B.Divide5[i];
      } else {
        accumTwo = VisionModel_B.Divide3[i];
      }
    } else {
      if (VisionModel_B.Divide5[i] < VisionModel_B.Divide3[i]) {
        accumOne = VisionModel_B.Divide5[i];
      } else {
        accumOne = VisionModel_B.Divide3[i];
      }

      if (VisionModel_B.Divide4[i] > VisionModel_B.Divide3[i]) {
        accumTwo = VisionModel_B.Divide4[i];
      } else {
        accumTwo = VisionModel_B.Divide3[i];
      }
    }

    accumOne = accumTwo - accumOne;
    if (accumTwo != 0.0) {
      c = accumOne / accumTwo;
    } else {
      c = 0.0;
    }

    if (accumOne != 0.0) {
      if (VisionModel_B.Divide5[i] == accumTwo) {
        accumFour = (VisionModel_B.Divide4[i] - VisionModel_B.Divide3[i]) /
          accumOne;
      } else if (VisionModel_B.Divide4[i] == accumTwo) {
        accumFour = (VisionModel_B.Divide3[i] - VisionModel_B.Divide5[i]) /
          accumOne + 2.0;
      } else {
        accumFour = (VisionModel_B.Divide5[i] - VisionModel_B.Divide4[i]) /
          accumOne + 4.0;
      }

      accumFour /= 6.0;
      if (accumFour < 0.0) {
        accumFour++;
      }
    } else {
      accumFour = 0.0;
    }

    /* assign the results */
    VisionModel_B.ColorSpaceConversion1_o1_m[i] = accumFour;
    VisionModel_B.ColorSpaceConversion1_o2_e[i] = c;
    VisionModel_B.ColorSpaceConversion1_o3_j[i] = accumTwo;
  }

  for (i = 0; i < 19200; i++) {
    /* Product: '<S3>/Divide3' incorporates:
     *  Inport: '<Root>/Scale_Forward_H'
     */
    VisionModel_B.Divide3[i] = VisionModel_B.ColorSpaceConversion1_o1_m[i] *
      VisionModel_U.Scale_Forward_H;

    /* Product: '<S3>/Divide4' incorporates:
     *  Inport: '<Root>/Scale_Forward_S'
     */
    VisionModel_B.Divide4[i] = VisionModel_B.ColorSpaceConversion1_o2_e[i] *
      VisionModel_U.Scale_Forward_S;

    /* Product: '<S3>/Divide5' incorporates:
     *  Inport: '<Root>/Scale_Forward_V'
     */
    VisionModel_B.Divide5[i] = VisionModel_B.ColorSpaceConversion1_o3_j[i] *
      VisionModel_U.Scale_Forward_V;
  }

  /* S-Function (svipcolorconv): '<S3>/Color Space  Conversion2' */
  /* temporary variables for in-place operation */
  accumFour = 0.0;
  c = 0.0;
  accumThree = 0.0;
  for (i = 0; i < 19200; i++) {
    accumOne = 6.0 * VisionModel_B.Divide3[i];
    i_gate_idx_0 = (real_T)(uint32_T)(accumOne - 1.3322676295501878E-15);
    accumOne -= i_gate_idx_0;
    accumTwo = 1.0 - VisionModel_B.Divide4[i];
    r = 1.0 - VisionModel_B.Divide4[i] * accumOne;
    accumOne = VisionModel_B.Divide4[i] * accumOne + accumTwo;
    if (i_gate_idx_0 == 0.0) {
      accumFour = 1.0;
      c = accumOne;
      accumThree = accumTwo;
    } else if (i_gate_idx_0 == 1.0) {
      accumFour = r;
      c = 1.0;
      accumThree = accumTwo;
    } else if (i_gate_idx_0 == 2.0) {
      accumFour = accumTwo;
      c = 1.0;
      accumThree = accumOne;
    } else if (i_gate_idx_0 == 3.0) {
      accumFour = accumTwo;
      c = r;
      accumThree = 1.0;
    } else if (i_gate_idx_0 == 4.0) {
      accumFour = accumOne;
      c = accumTwo;
      accumThree = 1.0;
    } else {
      if (i_gate_idx_0 == 5.0) {
        accumFour = 1.0;
        c = accumTwo;
        accumThree = r;
      }
    }

    if (accumFour > c) {
      accumTwo = accumFour;
    } else {
      accumTwo = c;
    }

    if (!(accumTwo > accumThree)) {
      accumTwo = accumThree;
    }

    accumOne = VisionModel_B.Divide5[i] / accumTwo;

    /* assign the results */
    VisionModel_B.ColorSpaceConversion2_o1[i] = accumOne * accumFour;
    VisionModel_B.ColorSpaceConversion2_o2[i] = accumOne * c;
    VisionModel_B.ColorSpaceConversion2_o3[i] = accumOne * accumThree;
  }

  /* Outputs for atomic SubSystem: '<Root>/ColorSelect' */

  /* If: '<S2>/If3' incorporates:
   *  ActionPort: '<S21>/Action Port'
   *  ActionPort: '<S22>/Action Port'
   *  ActionPort: '<S23>/Action Port'
   *  ActionPort: '<S24>/Action Port'
   *  ActionPort: '<S25>/Action Port'
   *  ActionPort: '<S26>/Action Port'
   *  Inport: '<Root>/ModeSelect'
   *  SubSystem: '<S2>/L_detector'
   *  SubSystem: '<S2>/buoy_detector'
   *  SubSystem: '<S2>/drop_mech'
   *  SubSystem: '<S2>/path_detector'
   *  SubSystem: '<S2>/torpedo'
   *  SubSystem: '<S2>/validation_gate'
   */
  if (VisionModel_U.ModeSelect == 1.0) {
    /* Constant: '<S26>/ColorFilter1' */
    for (i = 0; i < 7; i++) {
      VisionModel_B.ColorFilter1_c[i] = VisionModel_P.ColorFilter1_Value[i];
    }
  } else if (VisionModel_U.ModeSelect == 2.0) {
    /* Constant: '<S24>/ColorFilter1' */
    for (i = 0; i < 7; i++) {
      VisionModel_B.ColorFilter1_a[i] = VisionModel_P.ColorFilter1_Value_n[i];
    }
  } else if (VisionModel_U.ModeSelect == 3.0) {
    /* Constant: '<S22>/ColorFilter1' */
    for (i = 0; i < 7; i++) {
      VisionModel_B.ColorFilter1_l[i] = VisionModel_P.ColorFilter1_Value_nx[i];
    }
  } else if (VisionModel_U.ModeSelect == 4.0) {
    /* Constant: '<S25>/ColorFilter1' */
    for (i = 0; i < 7; i++) {
      VisionModel_B.ColorFilter1_f[i] = VisionModel_P.ColorFilter1_Value_l[i];
    }
  } else if (VisionModel_U.ModeSelect == 5.0) {
    /* Constant: '<S21>/ColorFilter1' */
    for (i = 0; i < 7; i++) {
      VisionModel_B.ColorFilter1_m[i] = VisionModel_P.ColorFilter1_Value_e[i];
    }
  } else {
    if (VisionModel_U.ModeSelect == 6.0) {
      /* Constant: '<S23>/ColorFilter1' */
      for (i = 0; i < 7; i++) {
        VisionModel_B.ColorFilter1[i] = VisionModel_P.ColorFilter1_Value_d[i];
      }
    }
  }

  /* Sum: '<S2>/Add22' */
  for (i = 0; i < 7; i++) {
    VisionModel_B.Add22[i] = ((((VisionModel_B.ColorFilter1_c[i] +
      VisionModel_B.ColorFilter1_a[i]) + VisionModel_B.ColorFilter1_l[i]) +
      VisionModel_B.ColorFilter1_f[i]) + VisionModel_B.ColorFilter1_m[i]) +
      VisionModel_B.ColorFilter1[i];
  }

  /* end of Outputs for SubSystem: '<Root>/ColorSelect' */

  /* Embedded MATLAB: '<Root>/make_color_range' incorporates:
   *  Inport: '<Root>/black_al'
   *  Inport: '<Root>/black_au'
   *  Inport: '<Root>/black_bl'
   *  Inport: '<Root>/black_bu'
   *  Inport: '<Root>/blue_al'
   *  Inport: '<Root>/blue_au'
   *  Inport: '<Root>/blue_bl'
   *  Inport: '<Root>/blue_bu'
   *  Inport: '<Root>/green_al'
   *  Inport: '<Root>/green_au'
   *  Inport: '<Root>/green_bl'
   *  Inport: '<Root>/green_bu'
   *  Inport: '<Root>/orange_al'
   *  Inport: '<Root>/orange_au'
   *  Inport: '<Root>/orange_bl'
   *  Inport: '<Root>/orange_bu'
   *  Inport: '<Root>/red_al'
   *  Inport: '<Root>/red_au'
   *  Inport: '<Root>/red_bl'
   *  Inport: '<Root>/red_bu'
   *  Inport: '<Root>/white_al'
   *  Inport: '<Root>/white_au'
   *  Inport: '<Root>/white_bl'
   *  Inport: '<Root>/white_bu'
   *  Inport: '<Root>/yellow_al'
   *  Inport: '<Root>/yellow_au'
   *  Inport: '<Root>/yellow_bl'
   *  Inport: '<Root>/yellow_bu'
   */
  /* Embedded MATLAB Function 'make_color_range': '<S6>:1' */
  /*  This function forms two compact matrices which pass all color range */
  /*    information to other functions in the model */
  /*  Initialize */
  /* '<S6>:1:8' */
  /* '<S6>:1:9' */
  for (i = 0; i < 14; i++) {
    VisionModel_B.a_range[i] = 0.0;
    VisionModel_B.b_range[i] = 0.0;
  }

  /*  Assign values to color range matrices */
  /* '<S6>:1:13' */
  VisionModel_B.a_range[0] = VisionModel_U.white_al;

  /* '<S6>:1:14' */
  VisionModel_B.a_range[1] = VisionModel_U.white_au;

  /* '<S6>:1:15' */
  VisionModel_B.b_range[0] = VisionModel_U.white_bl;

  /* '<S6>:1:16' */
  VisionModel_B.b_range[1] = VisionModel_U.white_bu;

  /* '<S6>:1:18' */
  VisionModel_B.a_range[2] = VisionModel_U.black_al;

  /* '<S6>:1:19' */
  VisionModel_B.a_range[3] = VisionModel_U.black_au;

  /* '<S6>:1:20' */
  VisionModel_B.b_range[2] = VisionModel_U.black_bl;

  /* '<S6>:1:21' */
  VisionModel_B.b_range[3] = VisionModel_U.black_bu;

  /* '<S6>:1:23' */
  VisionModel_B.a_range[4] = VisionModel_U.blue_al;

  /* '<S6>:1:24' */
  VisionModel_B.a_range[5] = VisionModel_U.blue_au;

  /* '<S6>:1:25' */
  VisionModel_B.b_range[4] = VisionModel_U.blue_bl;

  /* '<S6>:1:26' */
  VisionModel_B.b_range[5] = VisionModel_U.blue_bu;

  /* '<S6>:1:28' */
  VisionModel_B.a_range[6] = VisionModel_U.red_al;

  /* '<S6>:1:29' */
  VisionModel_B.a_range[7] = VisionModel_U.red_au;

  /* '<S6>:1:30' */
  VisionModel_B.b_range[6] = VisionModel_U.red_bl;

  /* '<S6>:1:31' */
  VisionModel_B.b_range[7] = VisionModel_U.red_bu;

  /* '<S6>:1:33' */
  VisionModel_B.a_range[8] = VisionModel_U.orange_al;

  /* '<S6>:1:34' */
  VisionModel_B.a_range[9] = VisionModel_U.orange_au;

  /* '<S6>:1:35' */
  VisionModel_B.b_range[8] = VisionModel_U.orange_bl;

  /* '<S6>:1:36' */
  VisionModel_B.b_range[9] = VisionModel_U.orange_bu;

  /* '<S6>:1:38' */
  VisionModel_B.a_range[10] = VisionModel_U.yellow_al;

  /* '<S6>:1:39' */
  VisionModel_B.a_range[11] = VisionModel_U.yellow_au;

  /* '<S6>:1:40' */
  VisionModel_B.b_range[10] = VisionModel_U.yellow_bl;

  /* '<S6>:1:41' */
  VisionModel_B.b_range[11] = VisionModel_U.yellow_bu;

  /* '<S6>:1:43' */
  VisionModel_B.a_range[12] = VisionModel_U.green_al;

  /* '<S6>:1:44' */
  VisionModel_B.a_range[13] = VisionModel_U.green_au;

  /* '<S6>:1:45' */
  VisionModel_B.b_range[12] = VisionModel_U.green_bl;

  /* '<S6>:1:46' */
  VisionModel_B.b_range[13] = VisionModel_U.green_bu;

  /* If: '<Root>/If1' incorporates:
   *  ActionPort: '<S1>/Action Port'
   *  Inport: '<Root>/ModeSelect'
   *  SubSystem: '<Root>/Blob_Analysis'
   */
  if ((VisionModel_U.ModeSelect == 1.0) || (VisionModel_U.ModeSelect == 3.0) ||
      (VisionModel_U.ModeSelect == 4.0) || (VisionModel_U.ModeSelect == 5.0)) {
    /* Embedded MATLAB: '<S12>/Low Pass Filter' */
    VisionModel_LowPassFilter(VisionModel_B.ColorSpaceConversion2_o1,
      &VisionModel_B.sf_LowPassFilter);

    /* Embedded MATLAB: '<S12>/Low Pass Filter1' */
    VisionModel_LowPassFilter(VisionModel_B.ColorSpaceConversion2_o2,
      &VisionModel_B.sf_LowPassFilter1);

    /* Embedded MATLAB: '<S12>/Low Pass Filter2' */
    VisionModel_LowPassFilter(VisionModel_B.ColorSpaceConversion2_o3,
      &VisionModel_B.sf_LowPassFilter2);

    /* S-Function (svipcolorconv): '<S10>/Color Space  Conversion1' */
    /* temporary variables for in-place operation */
    /* Convert to XYZ */
    /* temporary variables for in-place operation */
    for (i = 0; i < 19200; i++) {
      /* First, linearize (de-gamma) the RGB values; the operation is */
      /* equivalent to running the gamma correction block with break */
      /* point of 0.00304 and gamma of 2.4; it's built into this */
      /* conversion for convenience */
      if (VisionModel_B.sf_LowPassFilter.Iout[i] <= 0.039286085583733095) {
        accumOne = VisionModel_B.sf_LowPassFilter.Iout[i] / 12.923054468333255;
      } else {
        accumOne = rt_pow_snf((VisionModel_B.sf_LowPassFilter.Iout[i] +
          0.055000519817226347) / 1.0550005198172263, 2.4);
      }

      if (VisionModel_B.sf_LowPassFilter1.Iout[i] <= 0.039286085583733095) {
        accumTwo = VisionModel_B.sf_LowPassFilter1.Iout[i] / 12.923054468333255;
      } else {
        accumTwo = rt_pow_snf((VisionModel_B.sf_LowPassFilter1.Iout[i] +
          0.055000519817226347) / 1.0550005198172263, 2.4);
      }

      if (VisionModel_B.sf_LowPassFilter2.Iout[i] <= 0.039286085583733095) {
        accumThree = VisionModel_B.sf_LowPassFilter2.Iout[i] /
          12.923054468333255;
      } else {
        accumThree = rt_pow_snf((VisionModel_B.sf_LowPassFilter2.Iout[i] +
          0.055000519817226347) / 1.0550005198172263, 2.4);
      }

      /* The coefficients for this conversion were derived from ITU-R */
      /* BT.709 reference primaries for sRGB and CIE standard illuminant */
      /* D65, 2 degree observer */
      accumFour = (0.41239079926596 * accumOne + 0.35758433938388 * accumTwo) +
        0.18048078840183 * accumThree;
      c = (0.21263900587151 * accumOne + 0.71516867876776 * accumTwo) +
        0.07219231536073 * accumThree;
      accumThree = (0.01933081871559 * accumOne + 0.11919477979463 * accumTwo) +
        0.95053215224966 * accumThree;

      /* Make sure that the output is in [0..1] range; clip if necessary */
      if (accumFour > 1.0) {
        accumFour = 1.0;
      } else {
        if (accumFour < 0.0) {
          accumFour = 0.0;
        }
      }

      if (c > 1.0) {
        c = 1.0;
      } else {
        if (c < 0.0) {
          c = 0.0;
        }
      }

      if (accumThree > 1.0) {
        accumThree = 1.0;
      } else {
        if (accumThree < 0.0) {
          accumThree = 0.0;
        }
      }

      /* assign the results */
      VisionModel_B.ColorSpaceConversion1_o1[i] = accumFour;
      VisionModel_B.ColorSpaceConversion1_o2[i] = c;
      VisionModel_B.ColorSpaceConversion1_o3[i] = accumThree;
    }

    /* Convert from XYZ to L*a*b* */
    for (i = 0; i < 19200; i++) {
      accumOne = VisionModel_B.ColorSpaceConversion1_o1[i] / 0.9641986557609;
      accumThree = VisionModel_B.ColorSpaceConversion1_o3[i] / 0.82511648322104;

      /* Prepare Xf, Yf, and Zf for computation of a* and b* components */
      if (accumOne > 0.0088564516790356311) {
        accumFour = rt_pow_snf(accumOne, 0.33333333333333331);
      } else {
        accumFour = 7.7870370370370372 * accumOne + 0.13793103448275862;
      }

      if (VisionModel_B.ColorSpaceConversion1_o2[i] > 0.0088564516790356311) {
        accumTwo = rt_pow_snf(VisionModel_B.ColorSpaceConversion1_o2[i],
                              0.33333333333333331);
      } else {
        accumTwo = 7.7870370370370372 * VisionModel_B.ColorSpaceConversion1_o2[i]
          + 0.13793103448275862;
      }

      if (accumThree > 0.0088564516790356311) {
        accumOne = rt_pow_snf(accumThree, 0.33333333333333331);
      } else {
        accumOne = 7.7870370370370372 * accumThree + 0.13793103448275862;
      }

      /* assign the results */
      VisionModel_B.ColorSpaceConversion1_o1[i] = 116.0 * accumTwo - 16.0;
      VisionModel_B.ColorSpaceConversion1_o2[i] = (accumFour - accumTwo) * 500.0;
      VisionModel_B.ColorSpaceConversion1_o3[i] = (accumTwo - accumOne) * 200.0;
    }

    /* S-Function (svipresize): '<S19>/Resize' */
    /* use pre-computed weights and index table to perform interpolation */
    flag = 0;
    for (m = 0; m < 160; m++) {
      imgIdxLL = m;
      for (j = 0; j < 80; j++) {
        find_black = j + 80;
        accumOne =
          VisionModel_B.ColorSpaceConversion1_o1[VisionModel_ConstP.pooled8[j] *
          160 + m] * VisionModel_ConstP.pooled2[j] +
          VisionModel_B.ColorSpaceConversion1_o1[VisionModel_ConstP.pooled8[find_black]
          * 160 + m] * VisionModel_ConstP.pooled2[find_black];
        find_black += 80;
        accumOne +=
          VisionModel_B.ColorSpaceConversion1_o1[VisionModel_ConstP.pooled8[find_black]
          * 160 + m] * VisionModel_ConstP.pooled2[find_black];
        VisionModel_DWork.Resize_IntBuffer[imgIdxLL] = accumOne;
        imgIdxLL += 160;
      }
    }

    for (j = 0; j < 80; j++) {
      memcpy((void *)&Resize2_LineBuffer[0], (void *)
             (&VisionModel_DWork.Resize_IntBuffer[j * 160]), 160U * sizeof
             (real_T));
      for (m = 0; m < 60; m++) {
        find_black = m;
        accumOne = 0.0;
        for (find_white = 0; find_white < 6; find_white++) {
          accumOne += Resize2_LineBuffer[VisionModel_ConstP.pooled7[find_black]]
            * VisionModel_ConstP.pooled1[find_black];
          find_black += 60;
        }

        VisionModel_B.Resize[flag] = accumOne;
        flag++;
      }
    }

    /* S-Function (svipresize): '<S19>/Resize1' */
    /* use pre-computed weights and index table to perform interpolation */
    flag = 0;
    for (m = 0; m < 160; m++) {
      imgIdxLL = m;
      for (j = 0; j < 80; j++) {
        find_black = j + 80;
        accumOne =
          VisionModel_B.ColorSpaceConversion1_o2[VisionModel_ConstP.pooled8[j] *
          160 + m] * VisionModel_ConstP.pooled2[j] +
          VisionModel_B.ColorSpaceConversion1_o2[VisionModel_ConstP.pooled8[find_black]
          * 160 + m] * VisionModel_ConstP.pooled2[find_black];
        find_black += 80;
        accumOne +=
          VisionModel_B.ColorSpaceConversion1_o2[VisionModel_ConstP.pooled8[find_black]
          * 160 + m] * VisionModel_ConstP.pooled2[find_black];
        VisionModel_DWork.Resize1_IntBuffer[imgIdxLL] = accumOne;
        imgIdxLL += 160;
      }
    }

    for (j = 0; j < 80; j++) {
      memcpy((void *)&Resize2_LineBuffer[0], (void *)
             (&VisionModel_DWork.Resize1_IntBuffer[j * 160]), 160U * sizeof
             (real_T));
      for (m = 0; m < 60; m++) {
        find_black = m;
        accumOne = 0.0;
        for (find_white = 0; find_white < 6; find_white++) {
          accumOne += Resize2_LineBuffer[VisionModel_ConstP.pooled7[find_black]]
            * VisionModel_ConstP.pooled1[find_black];
          find_black += 60;
        }

        VisionModel_B.Resize1[flag] = accumOne;
        flag++;
      }
    }

    /* S-Function (svipresize): '<S19>/Resize2' */
    /* use pre-computed weights and index table to perform interpolation */
    flag = 0;
    for (m = 0; m < 160; m++) {
      imgIdxLL = m;
      for (j = 0; j < 80; j++) {
        find_black = j + 80;
        accumOne =
          VisionModel_B.ColorSpaceConversion1_o3[VisionModel_ConstP.pooled8[j] *
          160 + m] * VisionModel_ConstP.pooled2[j] +
          VisionModel_B.ColorSpaceConversion1_o3[VisionModel_ConstP.pooled8[find_black]
          * 160 + m] * VisionModel_ConstP.pooled2[find_black];
        find_black += 80;
        accumOne +=
          VisionModel_B.ColorSpaceConversion1_o3[VisionModel_ConstP.pooled8[find_black]
          * 160 + m] * VisionModel_ConstP.pooled2[find_black];
        VisionModel_DWork.Resize2_IntBuffer[imgIdxLL] = accumOne;
        imgIdxLL += 160;
      }
    }

    for (j = 0; j < 80; j++) {
      memcpy((void *)&Resize2_LineBuffer[0], (void *)
             (&VisionModel_DWork.Resize2_IntBuffer[j * 160]), 160U * sizeof
             (real_T));
      for (m = 0; m < 60; m++) {
        find_black = m;
        accumOne = 0.0;
        for (find_white = 0; find_white < 6; find_white++) {
          accumOne += Resize2_LineBuffer[VisionModel_ConstP.pooled7[find_black]]
            * VisionModel_ConstP.pooled1[find_black];
          find_black += 60;
        }

        VisionModel_B.Resize2[flag] = accumOne;
        flag++;
      }
    }

    /* Embedded MATLAB: '<S13>/Reference Color Selection' incorporates:
     *  Constant: '<S13>/Iter_Segment_Thresh'
     */
    /* Embedded MATLAB Function 'Blob_Analysis/IterativeSegmentation/Segmentation/Reference Color Selection': '<S18>:1' */
    /*  This function tries segmentation by adding new reference colors everytime */
    /*  a pixel is found with a distance greater than a certain amount from */
    /*  every other reference color */
    /* '<S18>:1:6' */
    /*  L = 0 to 100, a = -100 to 100, b = -100 to 100 */
    /*  max dist = 300 -> 60/300 is 20% */
    /*  coefficients determining distance calculation */
    /* '<S18>:1:14' */
    /* '<S18>:1:15' */
    memset((void *)(&VisionModel_B.ref_colors[0]), 0, 150U * sizeof(real_T));

    /*  At most 50 different reference colors */
    /* '<S18>:1:16' */
    memset((void *)(&VisionModel_B.LabelMatrix_m[0]), (int32_T)0U, 4800U *
           sizeof(uint32_T));

    /* '<S18>:1:17' */
    found = 1;

    /*  Define first reference color to be colr */
    /* '<S18>:1:23' */
    VisionModel_B.ref_colors[0] = VisionModel_B.Resize[2369];
    VisionModel_B.ref_colors[50] = VisionModel_B.Resize1[2369];
    VisionModel_B.ref_colors[100] = VisionModel_B.Resize2[2369];

    /* '<S18>:1:25' */
    flag = 0;

    /* '<S18>:1:26' */
    i = 1;

    /* '<S18>:1:27' */
    j = 1;
    while (i <= 60) {
      /* '<S18>:1:28' */
      /*  perform initial segmentation */
      while ((i <= 60) && (flag == 0)) {
        /* '<S18>:1:29' */
        while ((j <= 80) && (flag == 0)) {
          /* '<S18>:1:30' */
          /* '<S18>:1:31' */
          i_gate_idx_0 = 1.0;

          /* '<S18>:1:32' */
          accumOne = 1000.0;

          /* '<S18>:1:33' */
          accumTwo = 1.0;
          while ((uint32_T)i_gate_idx_0 <= (uint32_T)found) {
            /* '<S18>:1:34' */
            /* '<S18>:1:35' */
            accumThree = sqrt((rt_pow_snf(VisionModel_B.ref_colors[(int32_T)
              i_gate_idx_0 + 49] - VisionModel_B.Resize1[(j - 1) * 60 + (i - 1)],
              2.0) * 1.5 + rt_pow_snf(VisionModel_B.ref_colors[(int32_T)
              i_gate_idx_0 - 1] - VisionModel_B.Resize[(j - 1) * 60 + (i - 1)],
              2.0)) + rt_pow_snf(VisionModel_B.ref_colors[(int32_T)i_gate_idx_0
                                 + 99] - VisionModel_B.Resize2[(j - 1) * 60 + (i
              - 1)], 2.0) * 1.5);
            if (accumOne > accumThree) {
              /* '<S18>:1:36' */
              /* '<S18>:1:37' */
              accumOne = accumThree;

              /* '<S18>:1:38' */
              accumTwo = i_gate_idx_0;
            }

            /* '<S18>:1:40' */
            i_gate_idx_0++;
          }

          if ((accumOne > VisionModel_P.Iter_Segment_Thresh_Value) && (found <
               50)) {
            /* '<S18>:1:45' */
            /* '<S18>:1:46' */
            VisionModel_B.ref_colors[found] = VisionModel_B.Resize[(j - 1) * 60
              + (i - 1)];
            VisionModel_B.ref_colors[found + 50] = VisionModel_B.Resize1[(j - 1)
              * 60 + (i - 1)];
            VisionModel_B.ref_colors[found + 100] = VisionModel_B.Resize2[(j - 1)
              * 60 + (i - 1)];

            /* '<S18>:1:47' */
            found++;

            /* '<S18>:1:48' */
            flag = 1;

            /* '<S18>:1:49' */
            i = 0;

            /* '<S18>:1:50' */
            j = 0;
          } else {
            /* '<S18>:1:52' */
            VisionModel_B.LabelMatrix_m[(i - 1) + 60 * (j - 1)] = (uint32_T)
              accumTwo;
          }

          /* '<S18>:1:54' */
          j++;
        }

        /* '<S18>:1:56' */
        j = 1;

        /* '<S18>:1:57' */
        i++;
      }

      /* '<S18>:1:59' */
      flag = 0;
    }

    /*  Go through image once more to get more accurate values for the different regions */
    /* '<S18>:1:63' */
    /* '<S18>:1:64' */
    /* '<S18>:1:65' */
    /* '<S18>:1:66' */
    for (i = 0; i < 50; i++) {
      ref_color_L_avg[i] = 0.0;
      ref_color_a_avg[i] = 0.0;
      ref_color_b_avg[i] = 0.0;
      color_count[i] = 0.0;
    }

    /* '<S18>:1:67' */
    for (imgIdxLL = 0; imgIdxLL < 60; imgIdxLL++) {
      /* '<S18>:1:67' */
      /* '<S18>:1:68' */
      for (flag = 0; flag < 80; flag++) {
        /* '<S18>:1:68' */
        /* '<S18>:1:69' */
        /* '<S18>:1:70' */
        ref_color_L_avg[(int32_T)VisionModel_B.LabelMatrix_m[imgIdxLL + 60 *
          flag] - 1] = ref_color_L_avg[(int32_T)VisionModel_B.LabelMatrix_m[60 *
          flag + imgIdxLL] - 1] + VisionModel_B.Resize[60 * flag + imgIdxLL];

        /* '<S18>:1:71' */
        ref_color_a_avg[(int32_T)VisionModel_B.LabelMatrix_m[imgIdxLL + 60 *
          flag] - 1] = ref_color_a_avg[(int32_T)VisionModel_B.LabelMatrix_m[60 *
          flag + imgIdxLL] - 1] + VisionModel_B.Resize1[60 * flag + imgIdxLL];

        /* '<S18>:1:72' */
        ref_color_b_avg[(int32_T)VisionModel_B.LabelMatrix_m[imgIdxLL + 60 *
          flag] - 1] = ref_color_b_avg[(int32_T)VisionModel_B.LabelMatrix_m[60 *
          flag + imgIdxLL] - 1] + VisionModel_B.Resize2[60 * flag + imgIdxLL];

        /* '<S18>:1:73' */
        color_count[(int32_T)VisionModel_B.LabelMatrix_m[imgIdxLL + 60 * flag] -
          1] = color_count[(int32_T)VisionModel_B.LabelMatrix_m[60 * flag +
          imgIdxLL] - 1] + 1.0;
      }
    }

    /* '<S18>:1:76' */
    /* '<S18>:1:77' */
    /* '<S18>:1:78' */
    for (i = 0; i < 50; i++) {
      ref_color_L_avg[i] = ref_color_L_avg[i] / color_count[i];
      ref_color_a_avg[i] = ref_color_a_avg[i] / color_count[i];
      ref_color_b_avg[i] = ref_color_b_avg[i] / color_count[i];
    }

    /* '<S18>:1:80' */
    for (accumOne = 1.0; (uint32_T)accumOne <= (uint32_T)found; accumOne++) {
      /* '<S18>:1:80' */
      /* '<S18>:1:81' */
      VisionModel_B.ref_colors[(int32_T)accumOne - 1] = ref_color_L_avg[(int32_T)
        accumOne - 1];

      /* '<S18>:1:82' */
      VisionModel_B.ref_colors[(int32_T)accumOne + 49] = ref_color_a_avg
        [(int32_T)accumOne - 1];

      /* '<S18>:1:83' */
      VisionModel_B.ref_colors[(int32_T)accumOne + 99] = ref_color_b_avg
        [(int32_T)accumOne - 1];
    }

    VisionModel_B.num_colors = (real_T)found;

    /* Embedded MATLAB: '<S13>/LabSegmentation' */
    /* Embedded MATLAB Function 'Blob_Analysis/IterativeSegmentation/Segmentation/LabSegmentation': '<S17>:1' */
    /*  This function generates the label matrix */
    /* '<S17>:1:5' */
    memset((void *)(&VisionModel_B.LabelMatrix[0]), 0, 19200U * sizeof(real_T));

    /* '<S17>:1:7' */
    for (i = 0; i < 160; i++) {
      /* '<S17>:1:7' */
      /* '<S17>:1:8' */
      for (j = 0; j < 120; j++) {
        /* '<S17>:1:8' */
        /* '<S17>:1:9' */
        accumOne = 1000.0;

        /* '<S17>:1:10' */
        accumTwo = 1.0;

        /* '<S17>:1:11' */
        for (i_gate_idx_0 = 1.0; i_gate_idx_0 <= VisionModel_B.num_colors;
             i_gate_idx_0++) {
          /* '<S17>:1:11' */
          /* '<S17>:1:12' */
          accumThree = sqrt((rt_pow_snf(VisionModel_B.ref_colors[(int32_T)
            i_gate_idx_0 - 1] - VisionModel_B.ColorSpaceConversion1_o1[160 * j +
            i], 2.0) + rt_pow_snf(VisionModel_B.ref_colors[(int32_T)i_gate_idx_0
            + 49] - VisionModel_B.ColorSpaceConversion1_o2[160 * j + i], 2.0)) +
                            rt_pow_snf(VisionModel_B.ref_colors[(int32_T)
            i_gate_idx_0 + 99] - VisionModel_B.ColorSpaceConversion1_o3[160 * j
            + i], 2.0));
          if (accumThree < accumOne) {
            /* '<S17>:1:13' */
            /* '<S17>:1:14' */
            accumOne = accumThree;

            /* '<S17>:1:15' */
            accumTwo = i_gate_idx_0;
          }
        }

        /* '<S17>:1:18' */
        VisionModel_B.LabelMatrix[i + 160 * j] = accumTwo;
      }
    }

    /* Embedded MATLAB: '<S1>/Blob Extraction' */
    c = VisionModel_B.num_colors;

    /* Embedded MATLAB Function 'Blob_Analysis/Blob Extraction': '<S9>:1' */
    /*  This function calculates blob information for each color component after */
    /*    iterative segmentation */
    /*  Output */
    /*    blob_color = 1xN vector of color indices (global color scheme) */
    /*  Initialize */
    /* '<S9>:1:11' */
    /* '<S9>:1:16' */
    /* '<S9>:1:17' */
    for (i = 0; i < 19200; i++) {
      VisionModel_B.LogicMatrix[i] = FALSE;
      VisionModel_B.bw_image_c[i] = 0;
    }

    /* '<S9>:1:19' */
    memset((void *)(&VisionModel_B.blob_hues[0]), 0, 150U * sizeof(real_T));

    /* '<S9>:1:20' */
    for (i = 0; i < 50; i++) {
      blob_area[i] = -1;
    }

    /* '<S9>:1:21' */
    memset((void *)&blob_bbox[0], 0, 200U * sizeof(int32_T));

    /* '<S9>:1:22' */
    /* '<S9>:1:23' */
    for (i = 0; i < 50; i++) {
      VisionModel_B.blob_major_axis[i] = 0.0;
      VisionModel_B.blob_minor_axis[i] = 0.0;
    }

    /* '<S9>:1:24' */
    memset((void *)(&VisionModel_B.blob_centroids[0]), 0, 100U * sizeof(real_T));

    /* '<S9>:1:25' */
    /* '<S9>:1:26' */
    /* '<S9>:1:27' */
    /* '<S9>:1:28' */
    i_gate_idx = 0.0;

    /* '<S9>:1:30' */
    /* '<S9>:1:33' */
    /* '<S9>:1:35' */
    /*  Determine L_white and L_black as needed */
    /* '<S9>:1:39' */
    find_white = 0;

    /* '<S9>:1:40' */
    find_black = 0;

    /* '<S9>:1:41' */
    L_white = 101.0;

    /* '<S9>:1:42' */
    L_black = -1.0;

    /* '<S9>:1:43' */
    for (i = 0; i < 50; i++) {
      VisionModel_B.blob_eccentricity[i] = 0.0;
      VisionModel_B.blob_extent[i] = 0.0;
      VisionModel_B.blob_orientation[i] = 0.0;
      blob_color[i] = 0;
      ref_color_L_avg[i] = 0.0;
    }

    if (VisionModel_B.Add22[0] + VisionModel_B.Add22[1] > 0.0) {
      /* '<S9>:1:45' */
      /* '<S9>:1:46' */
      for (imgIdxLL = 0; imgIdxLL < 160; imgIdxLL++) {
        /* '<S9>:1:46' */
        /* '<S9>:1:47' */
        for (imgIdxLR = 0; imgIdxLR < 120; imgIdxLR++) {
          /* '<S9>:1:47' */
          /* '<S9>:1:48' */
          ref_color_L_avg[(int32_T)VisionModel_B.LabelMatrix[imgIdxLL + 160 *
            imgIdxLR] - 1] = ref_color_L_avg[(int32_T)VisionModel_B.LabelMatrix
            [160 * imgIdxLR + imgIdxLL] - 1] + 1.0;
        }
      }
    }

    if (VisionModel_B.Add22[0] == 1.0) {
      /* '<S9>:1:53' */
      /*  Determine the brightest colors, but allow a maximum area */
      /*    ratio of the image to be "white" */
      /* '<S9>:1:57' */
      find_white = 1;

      /* '<S9>:1:59' */
      positive_area = 0.0;

      /* '<S9>:1:60' */
      r = 1.0;
      condition = FALSE;
      while (((uint32_T)condition == 0U) && (r <= VisionModel_B.num_colors)) {
        /* '<S9>:1:60' */
        /* '<S9>:1:62' */
        accumOne = -1.0;

        /* '<S9>:1:63' */
        accumTwo = -1.0;

        /* '<S9>:1:64' */
        for (i_gate_idx_0 = 1.0; i_gate_idx_0 <= VisionModel_B.num_colors;
             i_gate_idx_0++) {
          /* '<S9>:1:64' */
          /* '<S9>:1:65' */
          if ((VisionModel_B.ref_colors[(int32_T)i_gate_idx_0 - 1] > accumOne) &&
              (VisionModel_B.ref_colors[(int32_T)i_gate_idx_0 - 1] < L_white)) {
            /* '<S9>:1:66' */
            /* '<S9>:1:67' */
            accumOne = VisionModel_B.ref_colors[(int32_T)i_gate_idx_0 - 1];

            /* '<S9>:1:68' */
            accumTwo = i_gate_idx_0;
          }
        }

        /* '<S9>:1:72' */
        positive_area += ref_color_L_avg[(int32_T)accumTwo - 1];
        if ((positive_area / 19200.0 >= 0.1) && (r > 1.0)) {
          /* '<S9>:1:73' */
          condition = TRUE;
        } else {
          /* '<S9>:1:77' */
          L_white = accumOne;
          r++;
        }
      }
    }

    if (VisionModel_B.Add22[1] == 1.0) {
      /* '<S9>:1:82' */
      /*  Determine the darkest colors, but allow a maximum area */
      /*    ratio of the image to be "black" */
      /* '<S9>:1:86' */
      find_black = 1;

      /* '<S9>:1:88' */
      for (found = 0; found < 160; found++) {
        /* '<S9>:1:88' */
        /* '<S9>:1:89' */
        for (flag = 0; flag < 120; flag++) {
          /* '<S9>:1:89' */
          /* '<S9>:1:90' */
          ref_color_L_avg[(int32_T)VisionModel_B.LabelMatrix[found + 160 * flag]
            - 1] = ref_color_L_avg[(int32_T)VisionModel_B.LabelMatrix[160 * flag
            + found] - 1] + 1.0;
        }
      }

      /* '<S9>:1:94' */
      positive_area = 0.0;

      /* '<S9>:1:95' */
      accumOne = 1.0;
      exitg = FALSE;
      while (((uint32_T)exitg == 0U) && (accumOne <= VisionModel_B.num_colors))
      {
        /* '<S9>:1:95' */
        /* '<S9>:1:97' */
        accumTwo = 101.0;

        /* '<S9>:1:98' */
        accumThree = -1.0;

        /* '<S9>:1:99' */
        for (accumFour = 1.0; accumFour <= VisionModel_B.num_colors; accumFour++)
        {
          /* '<S9>:1:99' */
          /* '<S9>:1:100' */
          if ((VisionModel_B.ref_colors[(int32_T)accumFour - 1] < accumTwo) &&
              (VisionModel_B.ref_colors[(int32_T)accumFour - 1] > L_black)) {
            /* '<S9>:1:101' */
            /* '<S9>:1:102' */
            accumTwo = VisionModel_B.ref_colors[(int32_T)accumFour - 1];

            /* '<S9>:1:103' */
            accumThree = accumFour;
          }
        }

        /* '<S9>:1:107' */
        positive_area += ref_color_L_avg[(int32_T)accumThree - 1];
        if ((positive_area / 19200.0 >= 0.1) && (accumOne > 1.0)) {
          /* '<S9>:1:108' */
          exitg = TRUE;
        } else {
          /* '<S9>:1:112' */
          L_black = accumTwo;
          accumOne++;
        }
      }
    }

    /*  Input hblob, a matrix containing [Area, blob_centroids, Eccentricity] for each */
    /*  identified blob */
    /*  Calculate geometric information about the blobs */
    /*  */
    /*  LogicMatrix is a binary version of LabelMatrix, with ones at all */
    /*    locations for which color values are k, and zeros everywhere else */
    /*  */
    /*  Explanation */
    /*    condition1 == 1 causes the k'th color to be analyzed by blob analysis, */
    /*      as well as be included in the black-and-white image */
    /*    condition1 == 0 disallows both of these items and simply ignores color */
    /*      k */
    /*    condition0 == 1 ensures that condition1 is true for all k */
    /*    condition0 == 0 enforces a filter which allows only the colors */
    /*      specified in the ColorFilter vector */
    /* '<S9>:1:143' */
    condition = (VisionModel_sum(&VisionModel_B.Add22[0]) == 0.0);

    /* '<S9>:1:144' */
    flag = 0;

    /* '<S9>:1:145' */
    for (accumOne = 1.0; accumOne <= c; accumOne++) {
      /* '<S9>:1:145' */
      /*  Decide whether or not to perform blob analysis */
      /* '<S9>:1:148' */
      found = 0;
      if (condition) {
        /* '<S9>:1:149' */
        /* '<S9>:1:150' */
        found = 1;
      } else {
        /* '<S9>:1:152' */
        /* '<S9>:1:153' */
        /* '<S9>:1:154' */
        i = 1;
        exitg_0 = FALSE;
        while (((uint32_T)exitg_0 == 0U) && (i <= 7)) {
          /* '<S9>:1:154' */
          /*  Skip colors that have not been specified */
          guard = FALSE;
          if (VisionModel_B.Add22[i - 1] == 0.0) {
            /* '<S9>:1:157' */
            guard = TRUE;
          } else if ((find_white == 1) && (VisionModel_B.ref_colors[(int32_T)
                      accumOne - 1] >= L_white)) {
            /* '<S9>:1:161' */
            /*  Handle "white" differently than other colors */
            /* '<S9>:1:162' */
            found = 1;

            /* '<S9>:1:163' */
            flag = 1;
            exitg_0 = TRUE;
          } else if ((find_black == 1) && (VisionModel_B.ref_colors[(int32_T)
                      accumOne - 1] <= L_black)) {
            /* '<S9>:1:165' */
            /*  Handle "black" differently than other colors */
            /* '<S9>:1:166' */
            found = 1;

            /* '<S9>:1:167' */
            flag = 2;
            exitg_0 = TRUE;
          } else if ((VisionModel_B.ref_colors[(int32_T)accumOne + 49] >=
                      VisionModel_B.a_range[((i - 1) << 1)]) &&
                     (VisionModel_B.ref_colors[(int32_T)accumOne + 49] <=
                      VisionModel_B.a_range[((i - 1) << 1) + 1]) &&
                     (VisionModel_B.ref_colors[(int32_T)accumOne + 99] >=
                      VisionModel_B.b_range[((i - 1) << 1)]) &&
                     (VisionModel_B.ref_colors[(int32_T)accumOne + 99] <=
                      VisionModel_B.b_range[((i - 1) << 1) + 1])) {
            /* '<S9>:1:169' */
            /* '<S9>:1:170' */
            found = 1;

            /* '<S9>:1:171' */
            flag = i;
            exitg_0 = TRUE;
          } else {
            guard = TRUE;
          }

          if (guard) {
            i++;
          }
        }
      }

      /*  Blob analysis */
      if (found == 1) {
        /* '<S9>:1:179' */
        /* '<S9>:1:181' */
        for (imgIdxLL = 0; imgIdxLL < 160; imgIdxLL++) {
          /* '<S9>:1:181' */
          /* '<S9>:1:182' */
          for (j = 0; j < 120; j++) {
            /* '<S9>:1:182' */
            if (VisionModel_B.LabelMatrix[160 * j + imgIdxLL] != accumOne) {
              /* '<S9>:1:183' */
              /* '<S9>:1:184' */
              VisionModel_B.LogicMatrix[imgIdxLL + 160 * j] = FALSE;
            } else {
              /* '<S9>:1:186' */
              VisionModel_B.LogicMatrix[imgIdxLL + 160 * j] = TRUE;

              /* '<S9>:1:187' */
              VisionModel_B.bw_image_c[imgIdxLL + 160 * j] = 1;
            }
          }
        }

        VisionModel_Outputs(&VisionModel_B.LogicMatrix[0], TArea, TCentroid,
                            TBBox, ref_color_L_avg, ref_color_a_avg,
                            ref_color_b_avg, color_count, TExtent, &TNumBlobs);

        /* '<S9>:1:194' */
        for (c_i = 1U; c_i <= TNumBlobs; c_i = (uint8_T)((uint32_T)c_i + 1U)) {
          /* '<S9>:1:194' */
          i_gate_idx_0 = floor((i_gate_idx + (real_T)TNumBlobs) + 0.5);
          if (i_gate_idx_0 < 256.0) {
            tmp = (uint8_T)i_gate_idx_0;
          } else {
            tmp = MAX_uint8_T;
          }

          if (tmp <= 50) {
            /* '<S9>:1:195' */
            /* '<S9>:1:197' */
            i_gate_idx_0 = floor((i_gate_idx + (real_T)c_i) + 0.5);
            if (i_gate_idx_0 < 256.0) {
              tmp = (uint8_T)i_gate_idx_0;
            } else {
              tmp = MAX_uint8_T;
            }

            VisionModel_B.blob_centroids[((tmp - 1) << 1)] = TCentroid[(c_i - 1)
              << 1];

            /* '<S9>:1:198' */
            i_gate_idx_0 = floor((i_gate_idx + (real_T)c_i) + 0.5);
            if (i_gate_idx_0 < 256.0) {
              tmp = (uint8_T)i_gate_idx_0;
            } else {
              tmp = MAX_uint8_T;
            }

            VisionModel_B.blob_centroids[1 + ((tmp - 1) << 1)] = TCentroid[((c_i
              - 1) << 1) + 1];

            /* '<S9>:1:200' */
            i_gate_idx_0 = floor((i_gate_idx + (real_T)c_i) + 0.5);
            if (i_gate_idx_0 < 256.0) {
              tmp = (uint8_T)i_gate_idx_0;
            } else {
              tmp = MAX_uint8_T;
            }

            accumTwo = VisionModel_B.blob_centroids[((tmp - 1) << 1)];
            VisionModel_refp1_round(&accumTwo);

            /* '<S9>:1:201' */
            i_gate_idx_0 = floor((i_gate_idx + (real_T)c_i) + 0.5);
            if (i_gate_idx_0 < 256.0) {
              tmp = (uint8_T)i_gate_idx_0;
            } else {
              tmp = MAX_uint8_T;
            }

            accumThree = VisionModel_B.blob_centroids[((tmp - 1) << 1) + 1];
            VisionModel_refp1_round(&accumThree);

            /* '<S9>:1:203' */
            i_gate_idx_0 = floor((i_gate_idx + (real_T)c_i) + 0.5);
            if (i_gate_idx_0 < 256.0) {
              tmp = (uint8_T)i_gate_idx_0;
            } else {
              tmp = MAX_uint8_T;
            }

            VisionModel_B.blob_hues[3 * (tmp - 1)] = VisionModel_B.ref_colors
              [(int32_T)VisionModel_B.LabelMatrix[((int32_T)accumThree - 1) *
              160 + ((int32_T)accumTwo - 1)] - 1];

            /* '<S9>:1:204' */
            i_gate_idx_0 = floor((i_gate_idx + (real_T)c_i) + 0.5);
            if (i_gate_idx_0 < 256.0) {
              tmp = (uint8_T)i_gate_idx_0;
            } else {
              tmp = MAX_uint8_T;
            }

            VisionModel_B.blob_hues[1 + 3 * (tmp - 1)] =
              VisionModel_B.ref_colors[(int32_T)VisionModel_B.LabelMatrix
              [((int32_T)accumThree - 1) * 160 + ((int32_T)accumTwo - 1)] + 49];

            /* '<S9>:1:205' */
            i_gate_idx_0 = floor((i_gate_idx + (real_T)c_i) + 0.5);
            if (i_gate_idx_0 < 256.0) {
              tmp = (uint8_T)i_gate_idx_0;
            } else {
              tmp = MAX_uint8_T;
            }

            VisionModel_B.blob_hues[2 + 3 * (tmp - 1)] =
              VisionModel_B.ref_colors[(int32_T)VisionModel_B.LabelMatrix
              [((int32_T)accumThree - 1) * 160 + ((int32_T)accumTwo - 1)] + 99];

            /* '<S9>:1:207' */
            i_gate_idx_0 = floor((i_gate_idx + (real_T)c_i) + 0.5);
            if (i_gate_idx_0 < 256.0) {
              tmp = (uint8_T)i_gate_idx_0;
            } else {
              tmp = MAX_uint8_T;
            }

            blob_area[tmp - 1] = TArea[c_i - 1];

            /* '<S9>:1:208' */
            i_gate_idx_0 = floor((i_gate_idx + (real_T)c_i) + 0.5);
            if (i_gate_idx_0 < 256.0) {
              tmp = (uint8_T)i_gate_idx_0;
            } else {
              tmp = MAX_uint8_T;
            }

            blob_bbox[tmp - 1] = TBBox[c_i - 1];

            /* '<S9>:1:209' */
            i_gate_idx_0 = floor((i_gate_idx + (real_T)c_i) + 0.5);
            if (i_gate_idx_0 < 256.0) {
              tmp = (uint8_T)i_gate_idx_0;
            } else {
              tmp = MAX_uint8_T;
            }

            VisionModel_B.blob_major_axis[tmp - 1] = ref_color_L_avg[c_i - 1];

            /* '<S9>:1:210' */
            i_gate_idx_0 = floor((i_gate_idx + (real_T)c_i) + 0.5);
            if (i_gate_idx_0 < 256.0) {
              tmp = (uint8_T)i_gate_idx_0;
            } else {
              tmp = MAX_uint8_T;
            }

            VisionModel_B.blob_minor_axis[tmp - 1] = ref_color_a_avg[c_i - 1];

            /* '<S9>:1:211' */
            i_gate_idx_0 = floor((i_gate_idx + (real_T)c_i) + 0.5);
            if (i_gate_idx_0 < 256.0) {
              tmp = (uint8_T)i_gate_idx_0;
            } else {
              tmp = MAX_uint8_T;
            }

            VisionModel_B.blob_eccentricity[tmp - 1] = color_count[c_i - 1];

            /* '<S9>:1:212' */
            i_gate_idx_0 = floor((i_gate_idx + (real_T)c_i) + 0.5);
            if (i_gate_idx_0 < 256.0) {
              tmp = (uint8_T)i_gate_idx_0;
            } else {
              tmp = MAX_uint8_T;
            }

            VisionModel_B.blob_extent[tmp - 1] = TExtent[c_i - 1];

            /* '<S9>:1:213' */
            i_gate_idx_0 = floor((i_gate_idx + (real_T)c_i) + 0.5);
            if (i_gate_idx_0 < 256.0) {
              tmp = (uint8_T)i_gate_idx_0;
            } else {
              tmp = MAX_uint8_T;
            }

            VisionModel_B.blob_orientation[tmp - 1] = ref_color_b_avg[c_i - 1];

            /* '<S9>:1:215' */
            i_gate_idx_0 = floor((i_gate_idx + (real_T)c_i) + 0.5);
            if (i_gate_idx_0 < 256.0) {
              tmp = (uint8_T)i_gate_idx_0;
            } else {
              tmp = MAX_uint8_T;
            }

            blob_color[tmp - 1] = (int8_T)flag;
          }
        }

        /* '<S9>:1:220' */
        i_gate_idx += (real_T)TNumBlobs;
      }
    }

    for (i = 0; i < 50; i++) {
      VisionModel_B.blob_area[i] = (real_T)blob_area[i];
    }

    for (i = 0; i < 200; i++) {
      VisionModel_B.blob_bbox[i] = (real_T)blob_bbox[i];
    }

    VisionModel_B.blob_count = i_gate_idx;
    for (i = 0; i < 50; i++) {
      VisionModel_B.blob_color[i] = (real_T)blob_color[i];
    }

    for (i = 0; i < 19200; i++) {
      VisionModel_B.bw_image[i] = (real_T)VisionModel_B.bw_image_c[i];
    }

    /* Outputs for atomic SubSystem: '<S1>/Segmented Image' */

    /* Embedded MATLAB: '<S11>/Display Image' */
    /* Embedded MATLAB Function 'Blob_Analysis/Segmented Image/Display Image': '<S20>:1' */
    /*  Initialize */
    /* '<S20>:1:6' */
    /* '<S20>:1:7' */
    /* '<S20>:1:8' */
    /*  Allow only colors in specified range */
    /* '<S20>:1:12' */
    for (flag = 0; flag < 160; flag++) {
      /* '<S20>:1:12' */
      /* '<S20>:1:13' */
      for (found = 0; found < 120; found++) {
        /* '<S20>:1:13' */
        /* '<S20>:1:15' */
        VisionModel_B.Divide5[flag + 160 * found] = VisionModel_B.ref_colors
          [(int32_T)VisionModel_B.LabelMatrix[160 * found + flag] - 1];

        /* '<S20>:1:16' */
        VisionModel_B.Divide4[flag + 160 * found] = VisionModel_B.ref_colors
          [(int32_T)VisionModel_B.LabelMatrix[160 * found + flag] + 49];

        /* '<S20>:1:17' */
        VisionModel_B.Divide3[flag + 160 * found] = VisionModel_B.ref_colors
          [(int32_T)VisionModel_B.LabelMatrix[160 * found + flag] + 99];
      }
    }

    /* S-Function (svipcolorconv): '<S11>/Color Space  Conversion' */
    /* temporary variables for in-place operation */
    /* First convert to XYZ */
    for (i = 0; i < 19200; i++) {
      c = (VisionModel_B.Divide5[i] + 16.0) / 116.0;
      accumFour = VisionModel_B.Divide4[i] / 500.0 + c;
      accumThree = VisionModel_B.Divide3[i] / -200.0 + c;
      if (accumFour <= 0.20689655172413793) {
        accumFour -= 0.13793103448275862;
        accumFour /= 7.7870370370370372;
      } else {
        accumFour = rt_pow_snf(accumFour, 3.0);
      }

      if (c <= 0.20689655172413793) {
        c -= 0.13793103448275862;
        c /= 7.7870370370370372;
      } else {
        c = rt_pow_snf(c, 3.0);
      }

      if (accumThree <= 0.20689655172413793) {
        accumThree -= 0.13793103448275862;
        accumThree /= 7.7870370370370372;
      } else {
        accumThree = rt_pow_snf(accumThree, 3.0);
      }

      accumFour *= 0.9504;
      accumThree *= 1.0889;

      /* assign the results */
      VisionModel_Y.R_forward_out1[i] = accumFour;
      VisionModel_Y.G_forward_out1[i] = c;
      VisionModel_Y.B_forward_out1[i] = accumThree;
    }

    /* Go from XYZ to sRGB; do it in place on the output buffer */
    /* temporary variables for in-place operation */
    for (i = 0; i < 19200; i++) {
      /* The coefficients for this conversion were derived from ITU-R */
      /* BT.709 reference primaries for sRGB and CIE standard illuminant */
      /* D65, 2 degree observer */
      accumFour = (3.24096994190451 * VisionModel_Y.R_forward_out1[i] +
                   -1.53738317757009 * VisionModel_Y.G_forward_out1[i]) +
        -0.49861076029299 * VisionModel_Y.B_forward_out1[i];
      c = (-0.96924363628087 * VisionModel_Y.R_forward_out1[i] +
           1.87596750150771 * VisionModel_Y.G_forward_out1[i]) +
        0.04155505740718 * VisionModel_Y.B_forward_out1[i];
      accumThree = (0.055630079697 * VisionModel_Y.R_forward_out1[i] +
                    -0.20397695888899 * VisionModel_Y.G_forward_out1[i]) +
        1.05697151424288 * VisionModel_Y.B_forward_out1[i];

      /* Apply gamma correction to get R'G'B' */
      if (accumFour <= 0.00304) {
        accumFour *= 12.923054468333255;
      } else {
        accumFour = 1.0550005198172263 * rt_pow_snf(accumFour,
          0.41666666666666669) - 0.055000519817226347;
      }

      if (c <= 0.00304) {
        c *= 12.923054468333255;
      } else {
        c = 1.0550005198172263 * rt_pow_snf(c, 0.41666666666666669) -
          0.055000519817226347;
      }

      if (accumThree <= 0.00304) {
        accumThree *= 12.923054468333255;
      } else {
        accumThree = 1.0550005198172263 * rt_pow_snf(accumThree,
          0.41666666666666669) - 0.055000519817226347;
      }

      /* Make sure that the output is in [0..1] range; clip if necessary */
      if (accumFour > 1.0) {
        accumFour = 1.0;
      } else {
        if (accumFour < 0.0) {
          accumFour = 0.0;
        }
      }

      if (c > 1.0) {
        c = 1.0;
      } else {
        if (c < 0.0) {
          c = 0.0;
        }
      }

      if (accumThree > 1.0) {
        accumThree = 1.0;
      } else {
        if (accumThree < 0.0) {
          accumThree = 0.0;
        }
      }

      /* assign the results */
      VisionModel_Y.R_forward_out1[i] = accumFour;
      VisionModel_Y.G_forward_out1[i] = c;
      VisionModel_Y.B_forward_out1[i] = accumThree;
    }

    /* end of Outputs for SubSystem: '<S1>/Segmented Image' */
  }

  /* If: '<Root>/If2' incorporates:
   *  ActionPort: '<S4>/Action Port'
   *  ActionPort: '<S5>/Action Port'
   *  ActionPort: '<S7>/Action Port'
   *  ActionPort: '<S8>/Action Port'
   *  Inport: '<Root>/ModeSelect'
   *  SubSystem: '<Root>/L_detector'
   *  SubSystem: '<Root>/buoy_detector'
   *  SubSystem: '<Root>/torpedo'
   *  SubSystem: '<Root>/validation_gate'
   */
  if (VisionModel_U.ModeSelect == 1.0) {
    /* S-Function (svipedge): '<S8>/Edge Detection' */
    for (find_white = 1; find_white < 119; find_white++) {
      for (flag = 1; flag < 159; flag++) {
        accumOne = 0.0;
        accumTwo = 0.0;
        found = find_white * 160 + flag;
        for (m = 0; m < 6; m++) {
          accumOne += VisionModel_B.bw_image[found +
            VisionModel_DWork.EdgeDetection_VO_DW[m]] *
            VisionModel_ConstP.pooled3[m];
          accumTwo += VisionModel_B.bw_image[found +
            VisionModel_DWork.EdgeDetection_HO_DW[m]] *
            VisionModel_ConstP.pooled4[m];
        }

        VisionModel_DWork.EdgeDetection1_GV_SQUARED_DW[found] = accumOne *
          accumOne;
        VisionModel_DWork.EdgeDetection1_GH_SQUARED_DW[found] = accumTwo *
          accumTwo;
      }
    }

    for (find_white = 1; find_white < 119; find_white++) {
      accumOne = 0.0;
      accumTwo = 0.0;
      accumThree = 0.0;
      accumFour = 0.0;
      found = find_white * 160;
      flag = find_white * 160 + 159;
      for (m = 0; m < 6; m++) {
        accumOne += VisionModel_B.bw_image[found +
          VisionModel_DWork.EdgeDetection_HOU_DW[m]] *
          VisionModel_ConstP.pooled4[m];
        accumTwo += VisionModel_B.bw_image[flag +
          VisionModel_DWork.EdgeDetection_HOD_DW[m]] *
          VisionModel_ConstP.pooled4[m];
        accumThree += VisionModel_B.bw_image[found +
          VisionModel_DWork.EdgeDetection_VOU_DW[m]] *
          VisionModel_ConstP.pooled3[m];
        accumFour += VisionModel_B.bw_image[flag +
          VisionModel_DWork.EdgeDetection_VOD_DW[m]] *
          VisionModel_ConstP.pooled3[m];
      }

      VisionModel_DWork.EdgeDetection1_GV_SQUARED_DW[found] = accumThree *
        accumThree;
      VisionModel_DWork.EdgeDetection1_GH_SQUARED_DW[found] = accumOne *
        accumOne;
      VisionModel_DWork.EdgeDetection1_GV_SQUARED_DW[flag] = accumFour *
        accumFour;
      VisionModel_DWork.EdgeDetection1_GH_SQUARED_DW[flag] = accumTwo * accumTwo;
    }

    for (flag = 1; flag < 159; flag++) {
      accumOne = 0.0;
      accumTwo = 0.0;
      accumThree = 0.0;
      accumFour = 0.0;
      found = 19040 + flag;
      for (m = 0; m < 6; m++) {
        accumOne += VisionModel_B.bw_image[flag +
          VisionModel_DWork.EdgeDetection_VOL_DW[m]] *
          VisionModel_ConstP.pooled3[m];
        accumTwo += VisionModel_B.bw_image[found +
          VisionModel_DWork.EdgeDetection_VOR_DW[m]] *
          VisionModel_ConstP.pooled3[m];
        accumThree += VisionModel_B.bw_image[flag +
          VisionModel_DWork.EdgeDetection_HOL_DW[m]] *
          VisionModel_ConstP.pooled4[m];
        accumFour += VisionModel_B.bw_image[found +
          VisionModel_DWork.EdgeDetection_HOR_DW[m]] *
          VisionModel_ConstP.pooled4[m];
      }

      VisionModel_DWork.EdgeDetection1_GV_SQUARED_DW[flag] = accumOne * accumOne;
      VisionModel_DWork.EdgeDetection1_GH_SQUARED_DW[flag] = accumThree *
        accumThree;
      VisionModel_DWork.EdgeDetection1_GV_SQUARED_DW[found] = accumTwo *
        accumTwo;
      VisionModel_DWork.EdgeDetection1_GH_SQUARED_DW[found] = accumFour *
        accumFour;
    }

    accumOne = 0.0;
    accumTwo = 0.0;
    accumThree = 0.0;
    accumFour = 0.0;
    for (m = 0; m < 6; m++) {
      accumOne +=
        VisionModel_B.bw_image[VisionModel_DWork.EdgeDetection_VOUL_DW[m]] *
        VisionModel_ConstP.pooled3[m];
      accumTwo +=
        VisionModel_B.bw_image[VisionModel_DWork.EdgeDetection_HOUL_DW[m]] *
        VisionModel_ConstP.pooled4[m];
      accumThree += VisionModel_B.bw_image[159 +
        VisionModel_DWork.EdgeDetection_VOLL_DW[m]] *
        VisionModel_ConstP.pooled3[m];
      accumFour += VisionModel_B.bw_image[159 +
        VisionModel_DWork.EdgeDetection_HOLL_DW[m]] *
        VisionModel_ConstP.pooled4[m];
    }

    VisionModel_DWork.EdgeDetection1_GV_SQUARED_DW[0] = accumOne * accumOne;
    VisionModel_DWork.EdgeDetection1_GH_SQUARED_DW[0] = accumTwo * accumTwo;
    VisionModel_DWork.EdgeDetection1_GV_SQUARED_DW[159] = accumThree *
      accumThree;
    VisionModel_DWork.EdgeDetection1_GH_SQUARED_DW[159] = accumFour * accumFour;
    accumOne = 0.0;
    accumTwo = 0.0;
    accumThree = 0.0;
    accumFour = 0.0;
    for (m = 0; m < 6; m++) {
      accumOne += VisionModel_B.bw_image[19040 +
        VisionModel_DWork.EdgeDetection_VOUR_DW[m]] *
        VisionModel_ConstP.pooled3[m];
      accumTwo += VisionModel_B.bw_image[19040 +
        VisionModel_DWork.EdgeDetection_HOUR_DW[m]] *
        VisionModel_ConstP.pooled4[m];
      accumThree += VisionModel_B.bw_image[19199 +
        VisionModel_DWork.EdgeDetection_VOLR_DW[m]] *
        VisionModel_ConstP.pooled3[m];
      accumFour += VisionModel_B.bw_image[19199 +
        VisionModel_DWork.EdgeDetection_HOLR_DW[m]] *
        VisionModel_ConstP.pooled4[m];
    }

    VisionModel_DWork.EdgeDetection1_GV_SQUARED_DW[19040] = accumOne * accumOne;
    VisionModel_DWork.EdgeDetection1_GH_SQUARED_DW[19040] = accumTwo * accumTwo;
    VisionModel_DWork.EdgeDetection1_GV_SQUARED_DW[19199] = accumThree *
      accumThree;
    VisionModel_DWork.EdgeDetection1_GH_SQUARED_DW[19199] = accumFour *
      accumFour;
    accumTwo = 0.0;
    for (m = 0; m < 19200; m++) {
      VisionModel_DWork.EdgeDetection1_GRAD_SUM_DW[m] =
        VisionModel_DWork.EdgeDetection1_GV_SQUARED_DW[m];
      VisionModel_DWork.EdgeDetection1_GRAD_SUM_DW[m] =
        VisionModel_DWork.EdgeDetection1_GRAD_SUM_DW[m] +
        VisionModel_DWork.EdgeDetection1_GH_SQUARED_DW[m];
      accumTwo += VisionModel_DWork.EdgeDetection1_GRAD_SUM_DW[m] *
        VisionModel_DWork.EdgeDetection_MEAN_FACTOR_DW;
    }

    accumOne = VisionModel_P.EdgeDetection_THRESH_TUNING_RTP * accumTwo;
    for (find_white = 0; find_white < 120; find_white++) {
      for (flag = 0; flag < 160; flag++) {
        m = find_white * 160 + flag;
        VisionModel_B.EdgeDetection[m] =
          ((VisionModel_DWork.EdgeDetection1_GRAD_SUM_DW[m] > accumOne) &&
           (((VisionModel_DWork.EdgeDetection1_GV_SQUARED_DW[m] >=
              VisionModel_DWork.EdgeDetection1_GH_SQUARED_DW[m]) && (find_white
              != 0 ? VisionModel_DWork.EdgeDetection1_GRAD_SUM_DW[m - 160] <=
              VisionModel_DWork.EdgeDetection1_GRAD_SUM_DW[m] : TRUE) &&
             (find_white != 119 ? VisionModel_DWork.EdgeDetection1_GRAD_SUM_DW[m]
              > VisionModel_DWork.EdgeDetection1_GRAD_SUM_DW[m + 160] : TRUE)) ||
            ((VisionModel_DWork.EdgeDetection1_GH_SQUARED_DW[m] >=
              VisionModel_DWork.EdgeDetection1_GV_SQUARED_DW[m]) && (flag != 0 ?
              VisionModel_DWork.EdgeDetection1_GRAD_SUM_DW[m - 1] <=
              VisionModel_DWork.EdgeDetection1_GRAD_SUM_DW[m] : TRUE) && (flag
              != 159 ? VisionModel_DWork.EdgeDetection1_GRAD_SUM_DW[m] >
              VisionModel_DWork.EdgeDetection1_GRAD_SUM_DW[m + 1] : TRUE))));
      }
    }

    /* S-Function (sviphough): '<S8>/Hough Transform1' */
    MWVIP_Hough_D(&VisionModel_B.EdgeDetection[0],
                  &VisionModel_B.HoughTransform1_o1[0],
                  &VisionModel_ConstP.pooled5[0], &VisionModel_ConstP.pooled6,
                  160, 120, 399, 91);

    /* Embedded MATLAB: '<S8>/Identify Validation Gate' incorporates:
     *  Constant: '<S8>/Constant1'
     *  Constant: '<S8>/Constant2'
     *  Constant: '<S8>/Forward_Fov'
     */
    memcpy((void *)(&VisionModel_B.hough_table[0]), (void *)
           (&VisionModel_B.HoughTransform1_o1[0]), 71820U * sizeof(real_T));

    /* Embedded MATLAB Function 'validation_gate/Identify Validation Gate': '<S38>:1' */
    /*  This function attempts to identfiy the validation gate, and returns */
    /*    targeting information, and a true/false gate_found parameter. */
    /*  */
    /*  5-29-11 */
    /*  */
    /*  Input */
    /*  */
    /*    target_height = fraction of goal post height to aim AUV at */
    /*    gate_aspect_ratio = used to infer unknown points with little extra */
    /*      processing (height/width of large goalpost-shape) */
    /*  */
    /*  Output */
    /*  */
    /*  Notes: */
    /*    The hough_table is destroyed in this function (acceptable if */
    /*      hough_table is not an output) */
    /*    Process: */
    /*      1. Identify primary, relatively "long" lines */
    /*      2.  */
    /* % Initialize */
    /*  Only the (max_num_lines) with the most votes will be considered as */
    /*    candidates for the validation gate */
    /* '<S38>:1:30' */
    /* rows = Forward_Camera_Dimensions(1); */
    /* cols = Forward_Camera_Dimensions(2); */
    /* rows = 120; */
    /* cols = 160; */
    /*  eps_rho must be at least as big as the gate leg diameter (units of */
    /*    pixels) */
    /* '<S38>:1:42' */
    /*  eps_theta is used to distinguish lines as "horizontal" or "vertical"; */
    /*    units are radians */
    /* '<S38>:1:45' */
    /*  These vectors contain the final three lines that compose the validation gate */
    /* '<S38>:1:49' */
    /* '<S38>:1:50' */
    accumFour = 0.0;
    positive_area = 0.0;
    rtb_rho_gate_idx_0 = 0.0;
    rtb_theta_gate_idx_0 = 0.0;
    rtb_rho_gate_idx = 0.0;
    rtb_theta_gate_idx = 0.0;

    /*  These vectors contain intermediate line information; as lines are */
    /*    eliminated from these vectors, their values are set to zero */
    /* '<S38>:1:54' */
    /* '<S38>:1:55' */
    /*  Identify the most popular max_num_lines lines */
    /* '<S38>:1:62' */
    /* '<S38>:1:63' */
    for (i = 0; i < 200; i++) {
      i_index[i] = 1;
      j_index[i] = 1U;
    }

    /* '<S38>:1:65' */
    for (m = 0; m < 200; m++) {
      /* '<S38>:1:66' */
      /* '<S38>:1:68' */
      accumOne = 0.0;

      /* '<S38>:1:69' */
      for (i = 0; i < 399; i++) {
        /* '<S38>:1:69' */
        /* '<S38>:1:70' */
        for (j = 0; j < 180; j++) {
          /* '<S38>:1:70' */
          if (VisionModel_B.hough_table[399 * j + i] > accumOne) {
            /* '<S38>:1:71' */
            /* '<S38>:1:72' */
            i_index[m] = (int16_T)(i + 1);

            /* '<S38>:1:73' */
            j_index[m] = (uint8_T)(j + 1);

            /* '<S38>:1:74' */
            accumOne = VisionModel_B.hough_table[399 * j + i];
          }
        }
      }

      /* '<S38>:1:79' */
      rho[m] = VisionModel_B.HoughTransform1_o3[i_index[m] - 1];

      /* '<S38>:1:80' */
      theta[m] = VisionModel_B.HoughTransform1_o2[j_index[m] - 1];

      /* '<S38>:1:81' */
      VisionModel_B.hough_table[(i_index[m] - 1) + 399 * (j_index[m] - 1)] = 0.0;

      /* '<S38>:1:82' */
    }

    /*  Effectively generate a small Hough table which contains only values of */
    /*    interest for the validation gate application */
    /* '<S38>:1:90' */
    /*  Rho bins for vertical lines */
    /*  Number of rho bins for vertical lines */
    /* '<S38>:1:92' */
    /*  Average rho values for each bin (note that the average value will generally differ slightly than the bin value) */
    /* '<S38>:1:93' */
    /*  Average theta values for each bin */
    /* '<S38>:1:94' */
    /*  Votes bins for vertical lines */
    /* '<S38>:1:96' */
    /* '<S38>:1:98' */
    /* '<S38>:1:99' */
    /* '<S38>:1:100' */
    for (i = 0; i < 6; i++) {
      rbinv[i] = (uint8_T)(i << 5);
      ravgv[i] = 0.0;
      tavgv[i] = 0.0;
      vbinv[i] = 0.0;
      rbinh[i] = (uint8_T)(i << 5);
      ravgh[i] = 0.0;
      tavgh[i] = 0.0;
      vbinh[i] = 0.0;
    }

    /*  Allow vertical lines along the left side of the image */
    /* '<S38>:1:103' */
    rbinv[0] = 1U;

    /* '<S38>:1:104' */
    rbinh[0] = 1U;

    /* '<S38>:1:106' */
    for (imgIdxLL = 0; imgIdxLL < 200; imgIdxLL++) {
      /* '<S38>:1:106' */
      /*  Consider only lines that are either vertical or horizontal, within */
      /*    tolerance */
      if ((fabs(theta[imgIdxLL] - 1.5707963267948966) <= 0.17453292519943295) ||
          (fabs(theta[imgIdxLL] + 1.5707963267948966) <= 0.17453292519943295)) {
        /* '<S38>:1:110' */
        condition = TRUE;
      } else {
        /* '<S38>:1:110' */
        condition = FALSE;
      }

      /*  Horizontal line */
      /* '<S38>:1:111' */
      /*  Vertical line */
      guard = FALSE;
      if (fabs(theta[imgIdxLL]) <= 0.17453292519943295) {
        /* '<S38>:1:113' */
        if ((rho[imgIdxLL] == 0.0) && (theta[imgIdxLL] == 0.0)) {
          /* '<S38>:1:113' */
          c_0 = TRUE;
        } else {
          /* '<S38>:1:113' */
          c_0 = FALSE;
        }

        if (!c_0) {
          /* '<S38>:1:113' */
          /*  Analyze vertical lines (ignore lines exactly along the left side of the image) */
          /* '<S38>:1:115' */
          flag = 1;
          exitg = FALSE;
          while (((uint32_T)exitg == 0U) && (flag <= 6)) {
            /* '<S38>:1:115' */
            /*  Place each rho value into a bin */
            if (fabs(rho[imgIdxLL] - (real_T)rbinv[flag - 1]) <= 16.0) {
              /* '<S38>:1:118' */
              /* '<S38>:1:119' */
              ravgv[flag - 1] = ravgv[flag - 1] + rho[imgIdxLL];

              /* '<S38>:1:120' */
              tavgv[flag - 1] = tavgv[flag - 1] + theta[imgIdxLL];

              /* '<S38>:1:121' */
              vbinv[flag - 1] = vbinv[flag - 1] + 1.0;
              exitg = TRUE;
            } else {
              flag++;
            }
          }
        } else {
          guard = TRUE;
        }
      } else {
        guard = TRUE;
      }

      if (guard && condition) {
        /* '<S38>:1:110' */
        /*  Analyze horizontal lines */
        if (theta[imgIdxLL] < 0.0) {
          /* '<S38>:1:129' */
          /* '<S38>:1:130' */
          theta[imgIdxLL] = theta[imgIdxLL] + 3.1415926535897931;

          /* '<S38>:1:131' */
          rho[imgIdxLL] = -rho[imgIdxLL];
        }

        /* '<S38>:1:134' */
        flag = 1;
        exitg_0 = FALSE;
        while (((uint32_T)exitg_0 == 0U) && (flag <= 6)) {
          /* '<S38>:1:134' */
          /*  Place each rho value into a bin */
          if (fabs(rho[imgIdxLL] - (real_T)rbinh[flag - 1]) <= 16.0) {
            /* '<S38>:1:137' */
            /* '<S38>:1:138' */
            ravgh[flag - 1] = ravgh[flag - 1] + rho[imgIdxLL];

            /* '<S38>:1:139' */
            tavgh[flag - 1] = tavgh[flag - 1] + theta[imgIdxLL];

            /* '<S38>:1:140' */
            vbinh[flag - 1] = vbinh[flag - 1] + 1.0;
            exitg_0 = TRUE;
          } else {
            flag++;
          }
        }
      }
    }

    /*  Average the values in ravg and tavg for horizontal and vertical lines */
    /* '<S38>:1:150' */
    /* '<S38>:1:159' */
    for (flag = 0; flag < 6; flag++) {
      /* '<S38>:1:150' */
      if (vbinv[flag] == 0.0) {
        /* '<S38>:1:151' */
        /* '<S38>:1:152' */
        i_gate_idx_0 = 0.0;

        /* '<S38>:1:153' */
        i_gate_idx = 0.0;
      } else {
        /* '<S38>:1:155' */
        i_gate_idx_0 = ravgv[flag] / vbinv[flag];

        /* '<S38>:1:156' */
        i_gate_idx = tavgv[flag] / vbinv[flag];
      }

      /* '<S38>:1:159' */
      if (vbinh[flag] == 0.0) {
        /* '<S38>:1:160' */
        /* '<S38>:1:161' */
        L_white = 0.0;

        /* '<S38>:1:162' */
        L_black = 0.0;
      } else {
        /* '<S38>:1:164' */
        L_white = ravgh[flag] / vbinh[flag];

        /* '<S38>:1:165' */
        L_black = tavgh[flag] / vbinh[flag];
      }

      ravgv[flag] = i_gate_idx_0;
      tavgv[flag] = i_gate_idx;
      ravgh[flag] = L_white;
      tavgh[flag] = L_black;
    }

    /* % Extract three lines that fit the criteria for being the validation gate */
    /* '<S38>:1:171' */
    accumOne = 10000.0;

    /* '<S38>:1:172' */
    accumTwo = -10000.0;

    /* '<S38>:1:173' */
    for (flag = 0; flag < 6; flag++) {
      /* '<S38>:1:173' */
      /*  Extract the left-most vertical line */
      if ((ravgv[flag] < accumOne) && (ravgv[flag] != 0.0)) {
        /* '<S38>:1:176' */
        /* '<S38>:1:177' */
        accumOne = ravgv[flag];

        /* '<S38>:1:178' */
        accumFour = ravgv[flag];

        /* '<S38>:1:179' */
        positive_area = tavgv[flag];
      }

      /*  Extract the right-most vertical line */
      if ((ravgv[flag] > accumTwo) && (ravgv[flag] != 0.0)) {
        /* '<S38>:1:183' */
        /* '<S38>:1:184' */
        accumTwo = ravgv[flag];

        /* '<S38>:1:185' */
        rtb_rho_gate_idx = ravgv[flag];

        /* '<S38>:1:186' */
        rtb_theta_gate_idx = tavgv[flag];
      }
    }

    /*  Check that the distance between the vertical lines is much greater than */
    /*    the minimum expected distance, eps_rho */
    if (fabs(rtb_rho_gate_idx - accumFour) < 32.0) {
      /* '<S38>:1:193' */
      /* '<S38>:1:194' */
      accumFour = 0.0;

      /* '<S38>:1:195' */
      rtb_rho_gate_idx = 0.0;

      /* '<S38>:1:196' */
      positive_area = 0.0;

      /* '<S38>:1:197' */
      rtb_theta_gate_idx = 0.0;
    }

    /* rmin = 10000; */
    /* '<S38>:1:201' */
    accumOne = 0.0;

    /* '<S38>:1:202' */
    for (flag = 0; flag < 6; flag++) {
      /* '<S38>:1:202' */
      /*  Extract the horizontal line with the most votes */
      if ((vbinh[flag] > accumOne) && (ravgh[flag] != 0.0)) {
        /* '<S38>:1:205' */
        /* '<S38>:1:206' */
        accumOne = vbinh[flag];

        /* '<S38>:1:207' */
        rtb_rho_gate_idx_0 = ravgh[flag];

        /* '<S38>:1:208' */
        rtb_theta_gate_idx_0 = tavgh[flag];
      }

      /*     % Extract the horizontal line that is highest up in the image */
      /*     if( ravgh(b) < rmin && ravgh(b) ~= 0 ) */
      /*         rmin = ravgh(b); */
      /*         rho_gate(2) = ravgh(b); */
      /*         theta_gate(2) = tavgh(b); */
      /*     end */
    }

    /* % Compute targeting information */
    /*  Compute intersections */
    /* '<S38>:1:222' */
    accumTwo = (accumFour / cos(positive_area) - rtb_rho_gate_idx_0 / cos
                (rtb_theta_gate_idx_0)) * (1.0 / (tan(positive_area) - tan
      (rtb_theta_gate_idx_0)));

    /* '<S38>:1:223' */
    accumThree = (accumFour - accumTwo * sin(positive_area)) * (1.0 / cos
      (positive_area));

    /* '<S38>:1:225' */
    r = (rtb_rho_gate_idx_0 / cos(rtb_theta_gate_idx_0) - rtb_rho_gate_idx / cos
         (rtb_theta_gate_idx)) * (1.0 / (tan(rtb_theta_gate_idx_0) - tan
      (rtb_theta_gate_idx)));

    /* '<S38>:1:226' */
    c = (rtb_rho_gate_idx_0 - r * sin(rtb_theta_gate_idx_0)) * (1.0 / cos
      (rtb_theta_gate_idx_0));

    /* '<S38>:1:228' */
    /* '<S38>:1:229' */
    /*  Compute gate width */
    /* '<S38>:1:232' */
    /*  Form unit vector pointing downward, parallel to gate posts */
    /* '<S38>:1:235' */
    /* '<S38>:1:236' */
    u[0] = 1.0;
    u[1] = tan((((rtb_theta_gate_idx_0 - 1.5707963267948966) + positive_area) +
                rtb_theta_gate_idx) / 3.0);

    /* '<S38>:1:237' */
    accumOne = VisionModel_norm(u);
    u[0] = 1.0 / accumOne;
    u[1] = u[1] / accumOne;

    /*  Compute target location */
    /* '<S38>:1:240' */
    accumOne = sqrt(rt_pow_snf(r - accumTwo, 2.0) + rt_pow_snf(c - accumThree,
      2.0)) * (VisionModel_P.Constant1_Value * VisionModel_P.Constant2_Value);

    /* '<S38>:1:241' */
    /* '<S38>:1:242' */
    /*  Determine if a gate is present (very simple, potentially inaccurate) */
    rtb_rho_gate_0[0] = (real_T)(accumFour == 0.0) + (real_T)(positive_area ==
      0.0);
    rtb_rho_gate_0[1] = (real_T)(rtb_rho_gate_idx_0 == 0.0) + (real_T)
      (rtb_theta_gate_idx_0 == 0.0);
    rtb_rho_gate_0[2] = (real_T)(rtb_rho_gate_idx == 0.0) + (real_T)
      (rtb_theta_gate_idx == 0.0);
    if (VisionModel_sum_k(rtb_rho_gate_0) > 0.0) {
      /* '<S38>:1:245' */
      /* '<S38>:1:247' */
      flag = 0;

      /* '<S38>:1:248' */
      VisionModel_B.target_z_o = 0.0;

      /* '<S38>:1:249' */
      accumOne = 0.0;

      /* '<S38>:1:250' */
      VisionModel_B.target_yaw_o = 0.0;
    } else {
      /* '<S38>:1:254' */
      flag = 1;

      /*  Transform target r, c to global coordinate system */
      /* '<S38>:1:257' */
      VisionModel_B.target_z_o = ((accumTwo + r) / 2.0 + accumOne * u[0]) - 80.0;

      /* '<S38>:1:258' */
      accumOne = ((accumThree + c) / 2.0 + accumOne * u[1]) - 60.0;

      /* '<S38>:1:259' */
      VisionModel_B.target_yaw_o = accumOne / 120.0 *
        VisionModel_P.Forward_Fov_Value;
    }

    VisionModel_B.target_y_c = accumOne;
    VisionModel_B.gate_found = (real_T)flag;

    /* If: '<S8>/If1' incorporates:
     *  ActionPort: '<S39>/Action Port'
     *  Inport: '<Root>/OutputImage'
     *  SubSystem: '<S8>/If Action Subsystem'
     */
    if (VisionModel_U.OutputImage > 0.0) {
      /* Embedded MATLAB: '<S39>/Transform Coordinates3' */
      VisionMod_TransformCoordinates3(VisionModel_P.which_camera_Value, 0.0,
        VisionModel_B.target_y_c, VisionModel_B.target_z_o,
        VisionModel_P.Forward_Camera_Dimensions1_Valu,
        &VisionModel_B.sf_TransformCoordinates3);

      /* S-Function (svipdrawmarkers): '<S39>/Draw Target' */
      /* Copy the image from input to output. */
      for (i = 0; i < 19200; i++) {
        VisionModel_B.Divide5[i] = VisionModel_B.bw_image[i];
        VisionModel_B.Divide4[i] = VisionModel_B.bw_image[i];
        VisionModel_B.Divide3[i] = VisionModel_B.bw_image[i];
      }

      /* Draw all X marks. */
      i_gate_idx_0 = VisionModel_P.DrawTarget_RTP_SIZE;
      if ((VisionModel_P.DrawTarget_RTP_SIZE < 4.503599627370496E+15) &&
          (VisionModel_P.DrawTarget_RTP_SIZE > -4.503599627370496E+15)) {
        i_gate_idx_0 = floor(VisionModel_P.DrawTarget_RTP_SIZE + 0.5);
      }

      find_white = (int32_T)i_gate_idx_0;
      for (idxROI = 0; idxROI < 2; idxROI += 2) {
        i_gate_idx_0 = VisionModel_B.sf_TransformCoordinates3.points[idxROI];
        if ((VisionModel_B.sf_TransformCoordinates3.points[idxROI] <
             4.503599627370496E+15) &&
            (VisionModel_B.sf_TransformCoordinates3.points[idxROI] >
             -4.503599627370496E+15)) {
          i_gate_idx_0 = floor
            (VisionModel_B.sf_TransformCoordinates3.points[idxROI] + 0.5);
        }

        imgIdxLL = (int32_T)i_gate_idx_0;
        i_gate_idx_0 = VisionModel_B.sf_TransformCoordinates3.points[idxROI + 1];
        if ((VisionModel_B.sf_TransformCoordinates3.points[idxROI + 1] <
             4.503599627370496E+15) &&
            (VisionModel_B.sf_TransformCoordinates3.points[idxROI + 1] >
             -4.503599627370496E+15)) {
          i_gate_idx_0 = floor
            (VisionModel_B.sf_TransformCoordinates3.points[idxROI + 1] + 0.5);
        }

        imgIdxLR = (int32_T)i_gate_idx_0;
        line_idx_5 = imgIdxLL - find_white;
        line_idx_3 = imgIdxLR - find_white;
        line_idx_1 = imgIdxLL + find_white;
        line_idx = imgIdxLR + find_white;
        condition = FALSE;

        /* Find the visible portion of a line. */
        exitg = FALSE;
        exitg_0 = FALSE;
        c_0 = FALSE;
        j = line_idx_5;
        line_idx_4 = line_idx_3;
        line_idx_2 = line_idx_1;
        line_idx_0 = line_idx;
        while (!c_0) {
          i = 0;
          m = 0;

          /* Determine viewport violations. */
          if (j < 0) {
            i = 4;
          } else {
            if (j > 159) {
              i = 8;
            }
          }

          if (line_idx_2 < 0) {
            m = 4;
          } else {
            if (line_idx_2 > 159) {
              m = 8;
            }
          }

          if (line_idx_4 < 0) {
            i = (int32_T)((uint32_T)i | 1U);
          } else {
            if (line_idx_4 > 119) {
              i = (int32_T)((uint32_T)i | 2U);
            }
          }

          if (line_idx_0 < 0) {
            m = (int32_T)((uint32_T)m | 1U);
          } else {
            if (line_idx_0 > 119) {
              m = (int32_T)((uint32_T)m | 2U);
            }
          }

          if (!((uint32_T)i | (uint32_T)m)) {
            /* Line falls completely within bounds. */
            c_0 = TRUE;
            condition = TRUE;
          } else if ((uint32_T)i & (uint32_T)m) {
            /* Line falls completely out of bounds. */
            c_0 = TRUE;
            condition = FALSE;
          } else if ((uint32_T)i != 0U) {
            /* Clip 1st point; if it's in-bounds, clip 2nd point. */
            if (exitg) {
              j = line_idx_5;
              line_idx_4 = line_idx_3;
            }

            found = line_idx_2 - j;
            flag = line_idx_0 - line_idx_4;
            if ((uint32_T)i & 4U) {
              /* Violated RMin. */
              find_black = (0 - j) * flag;
              if (((find_black >= 0) && (found >= 0)) || ((find_black < 0) &&
                   (found < 0))) {
                line_idx_4 += (div_s32_floor(find_black << 1U, found) + 1) >> 1;
              } else {
                line_idx_4 += -((div_s32_floor((-find_black) << 1U, found) + 1) >>
                                1);
              }

              j = 0;
              exitg = TRUE;
            } else if ((uint32_T)i & 8U) {
              /* Violated RMax. */
              find_black = (159 - j) * flag;
              if (((find_black >= 0) && (found >= 0)) || ((find_black < 0) &&
                   (found < 0))) {
                line_idx_4 += (div_s32_floor(find_black << 1U, found) + 1) >> 1;
              } else {
                line_idx_4 += -((div_s32_floor((-find_black) << 1U, found) + 1) >>
                                1);
              }

              j = 159;
              exitg = TRUE;
            } else if ((uint32_T)i & 1U) {
              /* Violated CMin. */
              find_black = (0 - line_idx_4) * found;
              if (((find_black >= 0) && (flag >= 0)) || ((find_black < 0) &&
                   (flag < 0))) {
                j += (div_s32_floor(find_black << 1U, flag) + 1) >> 1;
              } else {
                j += -((div_s32_floor((-find_black) << 1U, flag) + 1) >> 1);
              }

              line_idx_4 = 0;
              exitg = TRUE;
            } else {
              /* Violated CMax. */
              find_black = (119 - line_idx_4) * found;
              if (((find_black >= 0) && (flag >= 0)) || ((find_black < 0) &&
                   (flag < 0))) {
                j += (div_s32_floor(find_black << 1U, flag) + 1) >> 1;
              } else {
                j += -((div_s32_floor((-find_black) << 1U, flag) + 1) >> 1);
              }

              line_idx_4 = 119;
              exitg = TRUE;
            }
          } else {
            /* Clip the 2nd point. */
            if (exitg_0) {
              line_idx_2 = line_idx_1;
              line_idx_0 = line_idx;
            }

            found = line_idx_2 - j;
            flag = line_idx_0 - line_idx_4;
            if ((uint32_T)m & 4U) {
              /* Violated RMin. */
              find_black = (0 - line_idx_2) * flag;
              if (((find_black >= 0) && (found >= 0)) || ((find_black < 0) &&
                   (found < 0))) {
                line_idx_0 += (div_s32_floor(find_black << 1U, found) + 1) >> 1;
              } else {
                line_idx_0 += -((div_s32_floor((-find_black) << 1U, found) + 1) >>
                                1);
              }

              line_idx_2 = 0;
              exitg_0 = TRUE;
            } else if ((uint32_T)m & 8U) {
              /* Violated RMax. */
              find_black = (159 - line_idx_2) * flag;
              if (((find_black >= 0) && (found >= 0)) || ((find_black < 0) &&
                   (found < 0))) {
                line_idx_0 += (div_s32_floor(find_black << 1U, found) + 1) >> 1;
              } else {
                line_idx_0 += -((div_s32_floor((-find_black) << 1U, found) + 1) >>
                                1);
              }

              line_idx_2 = 159;
              exitg_0 = TRUE;
            } else if ((uint32_T)m & 1U) {
              /* Violated CMin. */
              find_black = (0 - line_idx_0) * found;
              if (((find_black >= 0) && (flag >= 0)) || ((find_black < 0) &&
                   (flag < 0))) {
                line_idx_2 += (div_s32_floor(find_black << 1U, flag) + 1) >> 1;
              } else {
                line_idx_2 += -((div_s32_floor((-find_black) << 1U, flag) + 1) >>
                                1);
              }

              line_idx_0 = 0;
              exitg_0 = TRUE;
            } else {
              /* Violated CMax. */
              find_black = (119 - line_idx_0) * found;
              if (((find_black >= 0) && (flag >= 0)) || ((find_black < 0) &&
                   (flag < 0))) {
                line_idx_2 += (div_s32_floor(find_black << 1U, flag) + 1) >> 1;
              } else {
                line_idx_2 += -((div_s32_floor((-find_black) << 1U, flag) + 1) >>
                                1);
              }

              line_idx_0 = 119;
              exitg_0 = TRUE;
            }
          }
        }

        if (condition) {
          flag = line_idx_4 * 160 + j;
          while (j <= line_idx_2) {
            VisionModel_B.Divide5[flag] =
              VisionModel_P.DrawTarget_RTP_FILLCOLOR[0];
            VisionModel_B.Divide4[flag] =
              VisionModel_P.DrawTarget_RTP_FILLCOLOR[1];
            VisionModel_B.Divide3[flag] =
              VisionModel_P.DrawTarget_RTP_FILLCOLOR[2];
            flag += 161;
            j++;
          }
        }

        line_idx_5 = imgIdxLL - find_white;
        line_idx_3 = imgIdxLR + find_white;
        line_idx_1 = imgIdxLL + find_white;
        line_idx = imgIdxLR - find_white;
        condition = FALSE;

        /* Find the visible portion of a line. */
        exitg = FALSE;
        exitg_0 = FALSE;
        c_0 = FALSE;
        j = line_idx_5;
        line_idx_4 = line_idx_3;
        line_idx_2 = line_idx_1;
        line_idx_0 = line_idx;
        while (!c_0) {
          i = 0;
          m = 0;

          /* Determine viewport violations. */
          if (j < 0) {
            i = 4;
          } else {
            if (j > 159) {
              i = 8;
            }
          }

          if (line_idx_2 < 0) {
            m = 4;
          } else {
            if (line_idx_2 > 159) {
              m = 8;
            }
          }

          if (line_idx_4 < 0) {
            i = (int32_T)((uint32_T)i | 1U);
          } else {
            if (line_idx_4 > 119) {
              i = (int32_T)((uint32_T)i | 2U);
            }
          }

          if (line_idx_0 < 0) {
            m = (int32_T)((uint32_T)m | 1U);
          } else {
            if (line_idx_0 > 119) {
              m = (int32_T)((uint32_T)m | 2U);
            }
          }

          if (!((uint32_T)i | (uint32_T)m)) {
            /* Line falls completely within bounds. */
            c_0 = TRUE;
            condition = TRUE;
          } else if ((uint32_T)i & (uint32_T)m) {
            /* Line falls completely out of bounds. */
            c_0 = TRUE;
            condition = FALSE;
          } else if ((uint32_T)i != 0U) {
            /* Clip 1st point; if it's in-bounds, clip 2nd point. */
            if (exitg) {
              j = line_idx_5;
              line_idx_4 = line_idx_3;
            }

            found = line_idx_2 - j;
            flag = line_idx_0 - line_idx_4;
            if ((uint32_T)i & 4U) {
              /* Violated RMin. */
              find_black = (0 - j) * flag;
              if (((find_black >= 0) && (found >= 0)) || ((find_black < 0) &&
                   (found < 0))) {
                line_idx_4 += (div_s32_floor(find_black << 1U, found) + 1) >> 1;
              } else {
                line_idx_4 += -((div_s32_floor((-find_black) << 1U, found) + 1) >>
                                1);
              }

              j = 0;
              exitg = TRUE;
            } else if ((uint32_T)i & 8U) {
              /* Violated RMax. */
              find_black = (159 - j) * flag;
              if (((find_black >= 0) && (found >= 0)) || ((find_black < 0) &&
                   (found < 0))) {
                line_idx_4 += (div_s32_floor(find_black << 1U, found) + 1) >> 1;
              } else {
                line_idx_4 += -((div_s32_floor((-find_black) << 1U, found) + 1) >>
                                1);
              }

              j = 159;
              exitg = TRUE;
            } else if ((uint32_T)i & 1U) {
              /* Violated CMin. */
              find_black = (0 - line_idx_4) * found;
              if (((find_black >= 0) && (flag >= 0)) || ((find_black < 0) &&
                   (flag < 0))) {
                j += (div_s32_floor(find_black << 1U, flag) + 1) >> 1;
              } else {
                j += -((div_s32_floor((-find_black) << 1U, flag) + 1) >> 1);
              }

              line_idx_4 = 0;
              exitg = TRUE;
            } else {
              /* Violated CMax. */
              find_black = (119 - line_idx_4) * found;
              if (((find_black >= 0) && (flag >= 0)) || ((find_black < 0) &&
                   (flag < 0))) {
                j += (div_s32_floor(find_black << 1U, flag) + 1) >> 1;
              } else {
                j += -((div_s32_floor((-find_black) << 1U, flag) + 1) >> 1);
              }

              line_idx_4 = 119;
              exitg = TRUE;
            }
          } else {
            /* Clip the 2nd point. */
            if (exitg_0) {
              line_idx_2 = line_idx_1;
              line_idx_0 = line_idx;
            }

            found = line_idx_2 - j;
            flag = line_idx_0 - line_idx_4;
            if ((uint32_T)m & 4U) {
              /* Violated RMin. */
              find_black = (0 - line_idx_2) * flag;
              if (((find_black >= 0) && (found >= 0)) || ((find_black < 0) &&
                   (found < 0))) {
                line_idx_0 += (div_s32_floor(find_black << 1U, found) + 1) >> 1;
              } else {
                line_idx_0 += -((div_s32_floor((-find_black) << 1U, found) + 1) >>
                                1);
              }

              line_idx_2 = 0;
              exitg_0 = TRUE;
            } else if ((uint32_T)m & 8U) {
              /* Violated RMax. */
              find_black = (159 - line_idx_2) * flag;
              if (((find_black >= 0) && (found >= 0)) || ((find_black < 0) &&
                   (found < 0))) {
                line_idx_0 += (div_s32_floor(find_black << 1U, found) + 1) >> 1;
              } else {
                line_idx_0 += -((div_s32_floor((-find_black) << 1U, found) + 1) >>
                                1);
              }

              line_idx_2 = 159;
              exitg_0 = TRUE;
            } else if ((uint32_T)m & 1U) {
              /* Violated CMin. */
              find_black = (0 - line_idx_0) * found;
              if (((find_black >= 0) && (flag >= 0)) || ((find_black < 0) &&
                   (flag < 0))) {
                line_idx_2 += (div_s32_floor(find_black << 1U, flag) + 1) >> 1;
              } else {
                line_idx_2 += -((div_s32_floor((-find_black) << 1U, flag) + 1) >>
                                1);
              }

              line_idx_0 = 0;
              exitg_0 = TRUE;
            } else {
              /* Violated CMax. */
              find_black = (119 - line_idx_0) * found;
              if (((find_black >= 0) && (flag >= 0)) || ((find_black < 0) &&
                   (flag < 0))) {
                line_idx_2 += (div_s32_floor(find_black << 1U, flag) + 1) >> 1;
              } else {
                line_idx_2 += -((div_s32_floor((-find_black) << 1U, flag) + 1) >>
                                1);
              }

              line_idx_0 = 119;
              exitg_0 = TRUE;
            }
          }
        }

        if (condition) {
          flag = line_idx_4 * 160 + j;
          while (j <= line_idx_2) {
            VisionModel_B.Divide5[flag] =
              VisionModel_P.DrawTarget_RTP_FILLCOLOR[0];
            VisionModel_B.Divide4[flag] =
              VisionModel_P.DrawTarget_RTP_FILLCOLOR[1];
            VisionModel_B.Divide3[flag] =
              VisionModel_P.DrawTarget_RTP_FILLCOLOR[2];
            flag += -159;
            j++;
          }
        }
      }

      /* S-Function (sviphoughlines): '<S39>/Hough Lines' */
      j = 0;
      accumOne = (accumFour + 2.2204460492503131E-16) / (cos(positive_area) +
        2.2204460492503131E-16);

      /* part-1: top horizontal axis */
      accumTwo = floor(accumOne + 0.5);
      if ((accumTwo >= 0.0) && (accumTwo <= 119.0)) {
        VisionModel_B.HoughLines[0] = 0;
        VisionModel_B.HoughLines[1] = (int32_T)floor((real_T)(int32_T)accumTwo +
          0.5);
        j = 1;
      }

      accumThree = (accumFour + 2.2204460492503131E-16) / (sin(positive_area) +
        2.2204460492503131E-16);

      /* part-2: left vertical axis */
      accumTwo = floor(accumThree + 0.5);
      if ((accumTwo >= 0.0) && (accumTwo <= 159.0)) {
        VisionModel_B.HoughLines[(j << 1)] = (int32_T)floor((real_T)(int32_T)
          accumTwo + 0.5);
        VisionModel_B.HoughLines[1 + (j << 1)] = 0;
        j++;
      }

      /* part-3: Right vertical axis */
      if (j < 2) {
        accumTwo = floor((accumOne - 119.0) * (accumThree / accumOne) + 0.5);
        if ((accumTwo >= 0.0) && (accumTwo <= 159.0)) {
          VisionModel_B.HoughLines[(j << 1)] = (int32_T)floor((real_T)(int32_T)
            accumTwo + 0.5);
          VisionModel_B.HoughLines[1 + (j << 1)] = 119;
          j++;
        }
      }

      /* part-4: bottom horizontal axis */
      if (j < 2) {
        accumTwo = floor((accumOne - accumOne / accumThree * 159.0) + 0.5);
        if ((accumTwo >= 0.0) && (accumTwo <= 119.0)) {
          VisionModel_B.HoughLines[(j << 1)] = 159;
          VisionModel_B.HoughLines[1 + (j << 1)] = (int32_T)floor((real_T)
            (int32_T)accumTwo + 0.5);
          j++;
        }
      }

      if (j < 2) {
        VisionModel_B.HoughLines[0] = -1;
        VisionModel_B.HoughLines[1] = -1;
        VisionModel_B.HoughLines[2] = -1;
        VisionModel_B.HoughLines[3] = -1;
      }

      j = 0;
      accumOne = (rtb_rho_gate_idx_0 + 2.2204460492503131E-16) / (cos
        (rtb_theta_gate_idx_0) + 2.2204460492503131E-16);

      /* part-1: top horizontal axis */
      accumTwo = floor(accumOne + 0.5);
      if ((accumTwo >= 0.0) && (accumTwo <= 119.0)) {
        VisionModel_B.HoughLines[4] = 0;
        VisionModel_B.HoughLines[5] = (int32_T)floor((real_T)(int32_T)accumTwo +
          0.5);
        j = 1;
      }

      accumThree = (rtb_rho_gate_idx_0 + 2.2204460492503131E-16) / (sin
        (rtb_theta_gate_idx_0) + 2.2204460492503131E-16);

      /* part-2: left vertical axis */
      accumTwo = floor(accumThree + 0.5);
      if ((accumTwo >= 0.0) && (accumTwo <= 159.0)) {
        VisionModel_B.HoughLines[4 + (j << 1)] = (int32_T)floor((real_T)(int32_T)
          accumTwo + 0.5);
        VisionModel_B.HoughLines[5 + (j << 1)] = 0;
        j++;
      }

      /* part-3: Right vertical axis */
      if (j < 2) {
        accumTwo = floor((accumOne - 119.0) * (accumThree / accumOne) + 0.5);
        if ((accumTwo >= 0.0) && (accumTwo <= 159.0)) {
          VisionModel_B.HoughLines[4 + (j << 1)] = (int32_T)floor((real_T)
            (int32_T)accumTwo + 0.5);
          VisionModel_B.HoughLines[5 + (j << 1)] = 119;
          j++;
        }
      }

      /* part-4: bottom horizontal axis */
      if (j < 2) {
        accumTwo = floor((accumOne - accumOne / accumThree * 159.0) + 0.5);
        if ((accumTwo >= 0.0) && (accumTwo <= 119.0)) {
          VisionModel_B.HoughLines[4 + (j << 1)] = 159;
          VisionModel_B.HoughLines[5 + (j << 1)] = (int32_T)floor((real_T)
            (int32_T)accumTwo + 0.5);
          j++;
        }
      }

      if (j < 2) {
        VisionModel_B.HoughLines[4] = -1;
        VisionModel_B.HoughLines[5] = -1;
        VisionModel_B.HoughLines[6] = -1;
        VisionModel_B.HoughLines[7] = -1;
      }

      j = 0;
      accumOne = (rtb_rho_gate_idx + 2.2204460492503131E-16) / (cos
        (rtb_theta_gate_idx) + 2.2204460492503131E-16);

      /* part-1: top horizontal axis */
      accumTwo = floor(accumOne + 0.5);
      if ((accumTwo >= 0.0) && (accumTwo <= 119.0)) {
        VisionModel_B.HoughLines[8] = 0;
        VisionModel_B.HoughLines[9] = (int32_T)floor((real_T)(int32_T)accumTwo +
          0.5);
        j = 1;
      }

      accumThree = (rtb_rho_gate_idx + 2.2204460492503131E-16) / (sin
        (rtb_theta_gate_idx) + 2.2204460492503131E-16);

      /* part-2: left vertical axis */
      accumTwo = floor(accumThree + 0.5);
      if ((accumTwo >= 0.0) && (accumTwo <= 159.0)) {
        VisionModel_B.HoughLines[8 + (j << 1)] = (int32_T)floor((real_T)(int32_T)
          accumTwo + 0.5);
        VisionModel_B.HoughLines[9 + (j << 1)] = 0;
        j++;
      }

      /* part-3: Right vertical axis */
      if (j < 2) {
        accumTwo = floor((accumOne - 119.0) * (accumThree / accumOne) + 0.5);
        if ((accumTwo >= 0.0) && (accumTwo <= 159.0)) {
          VisionModel_B.HoughLines[8 + (j << 1)] = (int32_T)floor((real_T)
            (int32_T)accumTwo + 0.5);
          VisionModel_B.HoughLines[9 + (j << 1)] = 119;
          j++;
        }
      }

      /* part-4: bottom horizontal axis */
      if (j < 2) {
        accumTwo = floor((accumOne - accumOne / accumThree * 159.0) + 0.5);
        if ((accumTwo >= 0.0) && (accumTwo <= 119.0)) {
          VisionModel_B.HoughLines[8 + (j << 1)] = 159;
          VisionModel_B.HoughLines[9 + (j << 1)] = (int32_T)floor((real_T)
            (int32_T)accumTwo + 0.5);
          j++;
        }
      }

      if (j < 2) {
        VisionModel_B.HoughLines[8] = -1;
        VisionModel_B.HoughLines[9] = -1;
        VisionModel_B.HoughLines[10] = -1;
        VisionModel_B.HoughLines[11] = -1;
      }

      /* S-Function (svipdrawshapes): '<S39>/Draw Shapes' */
      /* Copy the image from input to output. */
      for (i = 0; i < 19200; i++) {
        VisionModel_B.DrawShapes_o1[i] = VisionModel_B.Divide5[i];
        VisionModel_B.DrawShapes_o2[i] = VisionModel_B.Divide4[i];
        VisionModel_B.DrawShapes_o3[i] = VisionModel_B.Divide3[i];
      }

      idxStart = 0;
      for (idxROI = 0; idxROI < 3; idxROI++) {
        for (i = 0; i < 1; i = 1) {
          line_idx_5 = VisionModel_B.HoughLines[idxStart];
          line_idx_3 = VisionModel_B.HoughLines[idxStart + 1];
          line_idx_1 = VisionModel_B.HoughLines[idxStart + 2];
          line_idx = VisionModel_B.HoughLines[idxStart + 3];
          if ((VisionModel_B.HoughLines[idxStart + 2] !=
               VisionModel_B.HoughLines[idxStart]) ||
              (VisionModel_B.HoughLines[idxStart + 1] !=
               VisionModel_B.HoughLines[idxStart + 3])) {
            condition = FALSE;

            /* Find the visible portion of a line. */
            exitg = FALSE;
            exitg_0 = FALSE;
            c_0 = FALSE;
            line_idx_6 = VisionModel_B.HoughLines[idxStart];
            line_idx_4 = VisionModel_B.HoughLines[idxStart + 1];
            line_idx_2 = VisionModel_B.HoughLines[idxStart + 2];
            line_idx_0 = VisionModel_B.HoughLines[idxStart + 3];
            while (!c_0) {
              i = 0;
              m = 0;

              /* Determine viewport violations. */
              if (line_idx_6 < 0) {
                i = 4;
              } else {
                if (line_idx_6 > 159) {
                  i = 8;
                }
              }

              if (line_idx_2 < 0) {
                m = 4;
              } else {
                if (line_idx_2 > 159) {
                  m = 8;
                }
              }

              if (line_idx_4 < 0) {
                i = (int32_T)((uint32_T)i | 1U);
              } else {
                if (line_idx_4 > 119) {
                  i = (int32_T)((uint32_T)i | 2U);
                }
              }

              if (line_idx_0 < 0) {
                m = (int32_T)((uint32_T)m | 1U);
              } else {
                if (line_idx_0 > 119) {
                  m = (int32_T)((uint32_T)m | 2U);
                }
              }

              if (!((uint32_T)i | (uint32_T)m)) {
                /* Line falls completely within bounds. */
                c_0 = TRUE;
                condition = TRUE;
              } else if ((uint32_T)i & (uint32_T)m) {
                /* Line falls completely out of bounds. */
                c_0 = TRUE;
                condition = FALSE;
              } else if ((uint32_T)i != 0U) {
                /* Clip 1st point; if it's in-bounds, clip 2nd point. */
                if (exitg) {
                  line_idx_6 = line_idx_5;
                  line_idx_4 = line_idx_3;
                }

                found = line_idx_2 - line_idx_6;
                flag = line_idx_0 - line_idx_4;
                if ((uint32_T)i & 4U) {
                  /* Violated RMin. */
                  find_black = (0 - line_idx_6) * flag;
                  if (((find_black >= 0) && (found >= 0)) || ((find_black < 0) &&
                       (found < 0))) {
                    line_idx_4 += (div_s32_floor(find_black << 1U, found) + 1) >>
                      1;
                  } else {
                    line_idx_4 += -((div_s32_floor((-find_black) << 1U, found) +
                                     1) >> 1);
                  }

                  line_idx_6 = 0;
                  exitg = TRUE;
                } else if ((uint32_T)i & 8U) {
                  /* Violated RMax. */
                  find_black = (159 - line_idx_6) * flag;
                  if (((find_black >= 0) && (found >= 0)) || ((find_black < 0) &&
                       (found < 0))) {
                    line_idx_4 += (div_s32_floor(find_black << 1U, found) + 1) >>
                      1;
                  } else {
                    line_idx_4 += -((div_s32_floor((-find_black) << 1U, found) +
                                     1) >> 1);
                  }

                  line_idx_6 = 159;
                  exitg = TRUE;
                } else if ((uint32_T)i & 1U) {
                  /* Violated CMin. */
                  find_black = (0 - line_idx_4) * found;
                  if (((find_black >= 0) && (flag >= 0)) || ((find_black < 0) &&
                       (flag < 0))) {
                    line_idx_6 += (div_s32_floor(find_black << 1U, flag) + 1) >>
                      1;
                  } else {
                    line_idx_6 += -((div_s32_floor((-find_black) << 1U, flag) +
                                     1) >> 1);
                  }

                  line_idx_4 = 0;
                  exitg = TRUE;
                } else {
                  /* Violated CMax. */
                  find_black = (119 - line_idx_4) * found;
                  if (((find_black >= 0) && (flag >= 0)) || ((find_black < 0) &&
                       (flag < 0))) {
                    line_idx_6 += (div_s32_floor(find_black << 1U, flag) + 1) >>
                      1;
                  } else {
                    line_idx_6 += -((div_s32_floor((-find_black) << 1U, flag) +
                                     1) >> 1);
                  }

                  line_idx_4 = 119;
                  exitg = TRUE;
                }
              } else {
                /* Clip the 2nd point. */
                if (exitg_0) {
                  line_idx_2 = line_idx_1;
                  line_idx_0 = line_idx;
                }

                found = line_idx_2 - line_idx_6;
                flag = line_idx_0 - line_idx_4;
                if ((uint32_T)m & 4U) {
                  /* Violated RMin. */
                  find_black = (0 - line_idx_2) * flag;
                  if (((find_black >= 0) && (found >= 0)) || ((find_black < 0) &&
                       (found < 0))) {
                    line_idx_0 += (div_s32_floor(find_black << 1U, found) + 1) >>
                      1;
                  } else {
                    line_idx_0 += -((div_s32_floor((-find_black) << 1U, found) +
                                     1) >> 1);
                  }

                  line_idx_2 = 0;
                  exitg_0 = TRUE;
                } else if ((uint32_T)m & 8U) {
                  /* Violated RMax. */
                  find_black = (159 - line_idx_2) * flag;
                  if (((find_black >= 0) && (found >= 0)) || ((find_black < 0) &&
                       (found < 0))) {
                    line_idx_0 += (div_s32_floor(find_black << 1U, found) + 1) >>
                      1;
                  } else {
                    line_idx_0 += -((div_s32_floor((-find_black) << 1U, found) +
                                     1) >> 1);
                  }

                  line_idx_2 = 159;
                  exitg_0 = TRUE;
                } else if ((uint32_T)m & 1U) {
                  /* Violated CMin. */
                  find_black = (0 - line_idx_0) * found;
                  if (((find_black >= 0) && (flag >= 0)) || ((find_black < 0) &&
                       (flag < 0))) {
                    line_idx_2 += (div_s32_floor(find_black << 1U, flag) + 1) >>
                      1;
                  } else {
                    line_idx_2 += -((div_s32_floor((-find_black) << 1U, flag) +
                                     1) >> 1);
                  }

                  line_idx_0 = 0;
                  exitg_0 = TRUE;
                } else {
                  /* Violated CMax. */
                  find_black = (119 - line_idx_0) * found;
                  if (((find_black >= 0) && (flag >= 0)) || ((find_black < 0) &&
                       (flag < 0))) {
                    line_idx_2 += (div_s32_floor(find_black << 1U, flag) + 1) >>
                      1;
                  } else {
                    line_idx_2 += -((div_s32_floor((-find_black) << 1U, flag) +
                                     1) >> 1);
                  }

                  line_idx_0 = 119;
                  exitg_0 = TRUE;
                }
              }
            }

            if (condition) {
              /* Draw a line using Bresenham algorithm. */
              /* Initialize the Bresenham algorithm. */
              if (line_idx_2 >= line_idx_6) {
                found = line_idx_2 - line_idx_6;
              } else {
                found = line_idx_6 - line_idx_2;
              }

              if (line_idx_0 >= line_idx_4) {
                flag = line_idx_0 - line_idx_4;
              } else {
                flag = line_idx_4 - line_idx_0;
              }

              if (found > flag) {
                m = 1;
                flag = 160;
              } else {
                m = 160;
                flag = 1;
                found = line_idx_6;
                line_idx_6 = line_idx_4;
                line_idx_4 = found;
                found = line_idx_2;
                line_idx_2 = line_idx_0;
                line_idx_0 = found;
              }

              if (line_idx_6 > line_idx_2) {
                found = line_idx_6;
                line_idx_6 = line_idx_2;
                line_idx_2 = found;
                found = line_idx_4;
                line_idx_4 = line_idx_0;
                line_idx_0 = found;
              }

              j = line_idx_2 - line_idx_6;
              if (line_idx_4 <= line_idx_0) {
                found = 1;
                find_white = line_idx_0 - line_idx_4;
              } else {
                found = -1;
                find_white = line_idx_4 - line_idx_0;
              }

              find_black = line_idx_6;
              imgIdxLL = -((j + 1) >> 1);
              imgIdxLR = line_idx_6 * m + line_idx_4 * flag;
              found = found * flag + m;
              for (condition = (line_idx_6 <= line_idx_2); condition; condition =
                   (find_black <= line_idx_2)) {
                VisionModel_B.DrawShapes_o1[imgIdxLR] =
                  VisionModel_ConstP.DrawShapes_RTP_FILLCO[0];
                VisionModel_B.DrawShapes_o2[imgIdxLR] =
                  VisionModel_ConstP.DrawShapes_RTP_FILLCO[1];
                VisionModel_B.DrawShapes_o3[imgIdxLR] =
                  VisionModel_ConstP.DrawShapes_RTP_FILLCO[2];

                /* Compute the next location using Bresenham algorithm. */
                /* Move to the next pixel location. */
                imgIdxLL += find_white;
                if (imgIdxLL >= 0) {
                  imgIdxLL -= j;
                  imgIdxLR += found;
                } else {
                  imgIdxLR += m;
                }

                find_black++;
              }
            }
          }

          idxStart += 2;
        }

        idxStart += 2;
      }
    }

    /* Constant: '<S8>/Constant3' */
    VisionModel_B.Constant3 = VisionModel_P.Constant3_Value;
  } else {
    if (!(VisionModel_U.ModeSelect == 2.0)) {
      if (VisionModel_U.ModeSelect == 3.0) {
        /* Embedded MATLAB: '<S5>/Shape_Analysis' incorporates:
         *  Constant: '<S5>/Constant'
         *  Constant: '<S5>/Constant1'
         *  Constant: '<S5>/Constant2'
         *  Constant: '<S5>/Constant3'
         */
        /* Embedded MATLAB Function 'buoy_detector/Shape_Analysis': '<S32>:1' */
        /*  This function takes in vectors representing blobs present in the image, */
        /*    and returns information about how many and what kind of buoys are */
        /*    present. Buoys are identified by shape only. */
        /*  */
        /*  Input */
        /*    blob_hues = Nx3 vector of hues of blobs in image (values are Lab */
        /*      components) */
        /*    blob_centroids = Nx2 matrix of x-y pairs of blob centroid locations */
        /*    blob_eccentricity = Nx1 vector of blob eccentricites */
        /*    blob_extent = Nx1 vector of blob extents */
        /*    blob_count = integer number of blobs in image */
        /*  */
        /*    Min_Hue,Max_Hue = Nx1 limits on valid buoy hues; hue is between 0 and 1 */
        /*    Min_Eccent,Max_Eccent = scalar limits on buoy eccentricity */
        /*    Min_Extent,Max_Extent = scalar limits on buoy extent */
        /*  */
        /*    Buoy_Count_Max = maximum number of buoys that will be analyzed */
        /*  */
        /*  Output */
        /*    buoy_hues = Nx1 vector of buoy colors */
        /*    buoy_centroids = Nx2 matrix of x-y pairs of buoy centroid locations */
        /*    buoy_count = integer number of buoys found in image */
        /*    buoy_colors = 1xN vector of buoy colors identified by blob analysis */
        /*  Initialize */
        /* '<S32>:1:30' */
        for (i = 0; i < 100; i++) {
          VisionModel_B.buoy_centroids[i] = -500.0;
        }

        /*  Initialize to points clearly not located in image */
        /* '<S32>:1:31' */
        i_gate_idx = 0.0;

        /* '<S32>:1:32' */
        memset((void *)&ref_color_L_avg[0], 0, 50U * sizeof(real_T));

        /*  Loop through blobs, and extract information about blobs shaped like buoys */
        /* '<S32>:1:36' */
        for (accumOne = 1.0; accumOne <= VisionModel_B.blob_count; accumOne++) {
          /* '<S32>:1:36' */
          /*  Store buoy information if geometric conditions are met */
          /*    Conditions: 1) Blob eccentricity is within specified range */
          /*                2) Blob extent is within specified range */
          if ((VisionModel_B.blob_eccentricity[(int32_T)accumOne - 1] >=
               VisionModel_P.Constant_Value) &&
              (VisionModel_B.blob_eccentricity[(int32_T)accumOne - 1] <=
               VisionModel_P.Constant1_Value_f) && (VisionModel_B.blob_extent
               [(int32_T)accumOne - 1] >= VisionModel_P.Constant2_Value_h) &&
              (VisionModel_B.blob_extent[(int32_T)accumOne - 1] <=
               VisionModel_P.Constant3_Value_i)) {
            /* '<S32>:1:41' */
            /* '<S32>:1:43' */
            i_gate_idx++;

            /* '<S32>:1:49' */
            VisionModel_B.buoy_centroids[(((int32_T)i_gate_idx - 1) << 1U)] =
              VisionModel_B.blob_centroids[(((int32_T)accumOne - 1) << 1U)];

            /* '<S32>:1:50' */
            VisionModel_B.buoy_centroids[1 + (((int32_T)i_gate_idx - 1) << 1U)] =
              VisionModel_B.blob_centroids[(((int32_T)accumOne - 1) << 1U) + 1];

            /*         buoy_centroids(buoy_count,1) = blob_centroids(i,1); */
            /*         buoy_centroids(buoy_count,2) = blob_centroids(i,2); */
            /* '<S32>:1:54' */
            ref_color_L_avg[(int32_T)i_gate_idx - 1] = VisionModel_B.blob_color
              [(int32_T)accumOne - 1];
          }
        }

        /*  If no buoy is identified, then loosen the shape restrictions and try again */
        if (i_gate_idx == 0.0) {
          /* '<S32>:1:62' */
          /* '<S32>:1:64' */
          accumOne = (VisionModel_P.Constant1_Value_f -
                      VisionModel_P.Constant_Value) * 0.6;

          /* '<S32>:1:65' */
          accumTwo = (VisionModel_P.Constant1_Value_f +
                      VisionModel_P.Constant_Value) * 0.6;

          /* '<S32>:1:66' */
          accumThree = (VisionModel_P.Constant3_Value_i -
                        VisionModel_P.Constant2_Value_h) * 0.5;

          /* '<S32>:1:67' */
          accumFour = (VisionModel_P.Constant3_Value_i +
                       VisionModel_P.Constant2_Value_h) * 0.5;

          /* '<S32>:1:68' */
          r = accumTwo - accumOne;

          /* '<S32>:1:69' */
          positive_area = accumTwo + accumOne;

          /* '<S32>:1:70' */
          c = accumFour - accumThree;

          /* '<S32>:1:71' */
          accumOne = accumFour + accumThree;

          /* '<S32>:1:72' */
          for (accumTwo = 1.0; accumTwo <= VisionModel_B.blob_count; accumTwo++)
          {
            /* '<S32>:1:72' */
            /*  Store buoy information if geometric conditions are met */
            /*    Conditions: 1) Blob eccentricity is within specified range */
            /*                2) Blob extent is within specified range */
            if ((VisionModel_B.blob_eccentricity[(int32_T)accumTwo - 1] >= r) &&
                (VisionModel_B.blob_eccentricity[(int32_T)accumTwo - 1] <=
                 positive_area) && (VisionModel_B.blob_extent[(int32_T)accumTwo
                                    - 1] >= c) && (VisionModel_B.blob_extent
                 [(int32_T)accumTwo - 1] <= accumOne)) {
              /* '<S32>:1:77' */
              /* '<S32>:1:79' */
              i_gate_idx++;

              /* '<S32>:1:86' */
              VisionModel_B.buoy_centroids[(((int32_T)i_gate_idx - 1) << 1U)] =
                VisionModel_B.blob_centroids[(((int32_T)accumTwo - 1) << 1U)];

              /* '<S32>:1:87' */
              VisionModel_B.buoy_centroids[1 + (((int32_T)i_gate_idx - 1) << 1U)]
                = VisionModel_B.blob_centroids[(((int32_T)accumTwo - 1) << 1U) +
                1];

              /* buoy_centroids(buoy_count,1) = blob_centroids(i,1); */
              /* buoy_centroids(buoy_count,2) = blob_centroids(i,2); */
              /* '<S32>:1:91' */
              ref_color_L_avg[(int32_T)i_gate_idx - 1] =
                VisionModel_B.blob_color[(int32_T)accumTwo - 1];
            }
          }
        }

        /* Embedded MATLAB: '<S5>/Choose_Buoy' incorporates:
         *  Constant: '<S5>/Forward_Camera_Dimensions1'
         *  Constant: '<S5>/Forward_Camera_Dimensions3'
         *  Inport: '<Root>/DesiredBuoyColor'
         */
        /* Embedded MATLAB Function 'buoy_detector/Choose_Buoy': '<S30>:1' */
        /*  This function takes in vectors representing buoys present in the image, */
        /*    and decides which buoy to target. */
        /*  */
        /*  Input */
        /*    buoy_hues = Nx3 matrix of Lab components for each buoy */
        /*    buoy_centroids = 2xN matrix of x-y pairs of buoy centroids */
        /*    buoy_count = number of buoys identified in the image */
        /*    buoy_colors = 1xN vector of buoy color indices */
        /*    a_range, b_range = 2xN matrix of lower/upper bounds on a, b for each */
        /*      color */
        /*    which_color = which buoy color should be targeted; integer value */
        /*      represents: */
        /*                1 -> White */
        /*                2 -> Black */
        /*                3 -> Blue */
        /*                4 -> Red */
        /*                5 -> Orange */
        /*                6 -> Yellow */
        /*                7 -> Green */
        /*  */
        /*  Output */
        /*    target_select = input to MotionController.mdl, which selects which */
        /*      camera to use */
        /*    maintain_heading = instructs MotionController to strafe xor turn: */
        /*                     = 0 -> Turn toward target (use targetYaw) */
        /*                     = 1 -> Strafe to target (use targetY) */
        /*    targetY, targetZ = position of buoy in absolute coordinates */
        /*    targetYaw = relative, lateral angular displacement of buoy from */
        /*      straight ahead (in degrees) */
        /*    target_detected = informs the script that a buoy is being tracked */
        /*  Initialize */
        /* '<S30>:1:35' */
        VisionModel_B.target_select_f = 1.0;

        /* '<S30>:1:36' */
        /* '<S30>:1:37' */
        accumTwo = 0.0;

        /* '<S30>:1:38' */
        VisionModel_B.targetZ = 0.0;

        /* '<S30>:1:39' */
        VisionModel_B.targetYaw = 0.0;

        /* '<S30>:1:40' */
        flag = 0;

        /* '<S30>:1:41' */
        /* '<S30>:1:42' */
        /* { */
        /*  Classify each buoy by color */
        /* for i = 1:buoy_count */
        /*      */
        /*     a = buoy_hues(i, 2); */
        /*     b = buoy_hues(i, 3); */
        /*      */
        /*     % Note that colors 1 and 2 are black and white, resp. and do not have */
        /*     %   useful ranges in the a and b color components */
        /*     for col = 3:max_num_colors */
        /*         if( a >= a_range(1,col) && a <= a_range(2,col) && b >= b_range(1,col) && b <= b_range(2,col) ) */
        /*             buoy_colors(i) = col; */
        /*             break; */
        /*         end */
        /*     end */
        /*      */
        /* end */
        /* } */
        /*  Examine buoys from left to right; if one has the correct color, then */
        /*    target it; else do not recognize a target */
        /* '<S30>:1:68' */
        accumOne = 1.0;
        exitg_0 = FALSE;
        while (((uint32_T)exitg_0 == 0U) && (accumOne <= i_gate_idx)) {
          /* '<S30>:1:68' */
          if (ref_color_L_avg[(int32_T)accumOne - 1] ==
              VisionModel_U.DesiredBuoyColor) {
            /* '<S30>:1:69' */
            /* '<S30>:1:70' */
            accumTwo = VisionModel_B.buoy_centroids[(((int32_T)accumOne - 1) <<
              1U) + 1] - floor(VisionModel_P.Forward_Camera_Dimensions1_Va_f[1] /
                               2.0);

            /* '<S30>:1:71' */
            VisionModel_B.targetZ = VisionModel_B.buoy_centroids[(((int32_T)
              accumOne - 1) << 1U)] - floor
              (VisionModel_P.Forward_Camera_Dimensions1_Va_f[0] / 2.0);

            /* '<S30>:1:72' */
            VisionModel_B.targetYaw = accumTwo /
              VisionModel_P.Forward_Camera_Dimensions1_Va_f[1] *
              VisionModel_P.Forward_Camera_Dimensions3_Valu;

            /* '<S30>:1:73' */
            flag = 1;
            exitg_0 = TRUE;
          } else {
            accumOne++;
          }
        }

        /*  If no buoy was targeted, then pick one of the remaining buoys to target */
        if (flag == 0) {
          /* '<S30>:1:81' */
          /* '<S30>:1:82' */
          accumTwo = VisionModel_B.buoy_centroids[1] - floor
            (VisionModel_P.Forward_Camera_Dimensions1_Va_f[1] / 2.0);

          /* '<S30>:1:83' */
          VisionModel_B.targetZ = VisionModel_B.buoy_centroids[0] - floor
            (VisionModel_P.Forward_Camera_Dimensions1_Va_f[0] / 2.0);

          /* '<S30>:1:84' */
          VisionModel_B.targetYaw = accumTwo /
            VisionModel_P.Forward_Camera_Dimensions1_Va_f[1] *
            VisionModel_P.Forward_Camera_Dimensions3_Valu;
        }

        /* { */
        /*  */
        /* buoy_hues = double(zeros(Buoy_Count_Max,1)); */
        /* buoy_centroids = double(-500.*ones(Buoy_Count_Max,2));  % Initialize to points clearly not located in image */
        /*  */
        /* buoy_id = double(-1.*ones(Buoy_Count_Max,1)); */
        /* Buoy_Hue_HalfRange = 10; */
        /* Buoy1_Hue = 30; */
        /* Buoy2_Hue = 80; */
        /* Buoy3_Hue = 15; */
        /*  */
        /*  Loop through blobs, and analyze and extract buoy information */
        /* for i = 1:blob_count */
        /*      */
        /*     % Convert Lab to XYZ */
        /*     R = buoy_hues(i); */
        /*     G = buoy_hues(i); */
        /*     B = buoy_hues(i); */
        /*      */
        /*     L = blob_hues(:,1); %refcolors(LabelMatrix(1,1,1)); */
        /*     a = blob_hues(:,2); */
        /*     b = blob_hues(:,3); */
        /*      */
        /*     var_Y = L./10; */
        /*     var_X = ( a./17.5 ).*( L./10 ); */
        /*     var_Z = ( b./7 ).*( L./10 ); */
        /*      */
        /*     Y = var_Y.^2; */
        /*     X = ( var_X + Y )./1.02; */
        /*     Z = -( var_Z - Y )./0.847; */
        /*      */
        /*     % Convert XYZ to RGB */
        /*     var_X = X./100;        %X from 0 to  95.047      (Observer = 2 degrees, Illuminant = D65) */
        /*     var_Y = Y./100;        %Y from 0 to 100.000 */
        /*     var_Z = Z./100;        %Z from 0 to 108.883 */
        /*      */
        /*     var_R = var_X.*3.2406 + var_Y.*(-1.5372) + var_Z.* -0.4986; */
        /*     var_G = var_X .* -0.9689 + var_Y .*  1.8758 + var_Z.*  0.0415; */
        /*     var_B = var_X .*  0.0557 + var_Y .* -0.2040 + var_Z .*  1.0570; */
        /*      */
        /*     var_R = ( var_R > 0.0031308 ).*( 1.055.*( var_R.^( 1./2.4 ) ) - 0.055 ) + ( var_R <= 0.0031308 ).*(12.92.*var_R); */
        /*     var_G = ( var_G > 0.0031308 ).*( 1.055.*( var_G.^( 1./2.4 ) ) - 0.055 ) + ( var_G <= 0.0031308 ).*( var_G <= 12.92.*var_G ); */
        /*     var_B = ( var_B > 0.0031308 ).*( 1.055 .* ( var_B .^ ( 1 ./ 2.4 ) ) - 0.055 ) + ( var_B <= 0.0031308 ).*( 12.92 .* var_B ); */
        /*      */
        /*     R = var_R .* 255; */
        /*     G = var_G .* 255; */
        /*     B = var_B .* 255; */
        /*      */
        /*     % Convert RGB to HSV */
        /*     var_R = ( R ./ 255 );  % RGB from 0 to 255 */
        /*     var_G = ( G ./ 255 ); */
        /*     var_B = ( B ./ 255 ); */
        /*      */
        /*     var_Min = min( [var_R, var_G, var_B], [], 2 );  % Min. value of RGB */
        /*     var_Max = max( [var_R, var_G, var_B], [], 2 );  % Max. value of RGB */
        /*     del_Max = var_Max - var_Min;  % Delta RGB value */
        /*      */
        /*     V = var_Max; */
        /*      */
        /*     H = (del_Max != 0).*(  ); */
        /*     S = (del_Max != 0).*( del_Max./var_Max ); */
        /*     if ( max(abs(del_Max == 0)) );  % This is a gray, no chroma... */
        /*         H = zeros(size(var_R));  % HSV results from 0 to 1 */
        /*         S = zeros(size(var_R)); */
        /*     else  % Chromatic data... */
        /*          */
        /*         S = del_Max ./ var_Max; */
        /*          */
        /*         del_R = ( ( ( var_Max - var_R ) ./ 6 ) + ( del_Max ./ 2 ) ) ./ del_Max; */
        /*         del_G = ( ( ( var_Max - var_G ) ./ 6 ) + ( del_Max ./ 2 ) ) ./ del_Max; */
        /*         del_B = ( ( ( var_Max - var_B ) ./ 6 ) + ( del_Max ./ 2 ) ) ./ del_Max; */
        /*          */
        /*         H = ( var_R == var_Max ).*( del_B - del_G ) + ( var_G == var_Max ).*( ( 1 ./ 3 ) + del_R - del_B ) + ( var_B == var_Max ).*( ( 2 ./ 3 ) + del_G - del_R ); */
        /*         H = ( H < 0 ).*( H + 1 ) + ( H > 1 ).*( H - 1 ); */
        /*          */
        /* {         */
        /*         if( var_R == var_Max ) */
        /*             H = del_B - del_G; */
        /*         elseif( var_G == var_Max ) */
        /*             H = ( 1 ./ 3 ) + del_R - del_B; */
        /*         elseif( var_B == var_Max ) */
        /*             H = ( 2 ./ 3 ) + del_G - del_R; */
        /*         else */
        /*             H = 0; */
        /*         end */
        /*          */
        /*         if( H < 0 ) */
        /*             H = H + 1; */
        /*         end */
        /*         if( H > 1 ) */
        /*             H = H - 1; */
        /*         end */
        /* }         */
        /*     end */
        /*      */
        /*     % Store buoy information if blob conditions are met */
        /*     %   Conditions: 1) Blob eccentricity is within specified range */
        /*     %               2) Blob extent is within specified range */
        /*     %               3) Blob hue is within specified range for several buoy */
        /*     %                 types */
        /*     if( (blob_eccentricity(i)>=Min_Eccent) && (blob_eccentricity(i)<=Max_Eccent) && (blob_extent(i)>=Min_Extent) && (blob_extent(i)<=Max_Extent) ) */
        /*          */
        /*         %if( (blob_hues(i)>=Buoy1_Hue-Buoy_Hue_HalfRange) && (blob_hues(i)<=Buoy1_Hue+Buoy_Hue_HalfRange) ) */
        /*             buoy_count = buoy_count + 1; */
        /*             buoy_hues(buoy_count) = blob_hues(i); */
        /*             buoy_id(buoy_count) = 1; */
        /*             buoy_centroids(buoy_count,1) = blob_centroids(i,1); */
        /*             buoy_centroids(buoy_count,2) = blob_centroids(i,2); */
        /*         %end */
        /*         if( (blob_hues(i)>=Buoy2_Hue-Buoy_Hue_HalfRange) && (blob_hues(i)<=Buoy2_Hue+Buoy_Hue_HalfRange) ) */
        /*             buoy_count = buoy_count + 1; */
        /*             buoy_hues(buoy_count) = blob_hues(i); */
        /*             buoy_id(buoy_count) = 2; */
        /*             buoy_centroids(buoy_count,1) = blob_centroids(i,1); */
        /*             buoy_centroids(buoy_count,2) = blob_centroids(i,2); */
        /*         end */
        /*         if( (blob_hues(i)>=Buoy3_Hue-Buoy_Hue_HalfRange) && (blob_hues(i)<=Buoy3_Hue+Buoy_Hue_HalfRange) ) */
        /*             buoy_count = buoy_count + 1; */
        /*             buoy_hues(buoy_count) = blob_hues(i); */
        /*             buoy_id(buoy_count) = 3; */
        /*             buoy_centroids(buoy_count,1) = blob_centroids(i,1); */
        /*             buoy_centroids(buoy_count,2) = blob_centroids(i,2); */
        /*         end */
        /*     end */
        /*      */
        /* end */
        /*  */
        /*  Resize output arrays */
        /* buoy_hues = buoy_hues(1:buoy_count); */
        /* buoy_centroids = buoy_centroids(1:buoy_count,:); */
        /* buoy_id = ; */
        /*  */
        /* } */
        VisionModel_B.targetY = accumTwo;
        VisionModel_B.target_detected_d = (real_T)flag;

        /* If: '<S5>/If1' incorporates:
         *  ActionPort: '<S31>/Action Port'
         *  Inport: '<Root>/OutputImage'
         *  SubSystem: '<S5>/If Action Subsystem'
         */
        if (VisionModel_U.OutputImage > 0.0) {
          VisionModel_IfActionSubsystem(VisionModel_B.bw_image,
            VisionModel_P.which_camera_Value_k, 0.0, VisionModel_B.targetY,
            VisionModel_B.targetZ, VisionModel_P.Forward_Camera_Dimensions2_Valu,
            &VisionModel_B.IfActionSubsystem_h, (rtP_IfActionSubsystem_VisionMod
            *) &VisionModel_P.IfActionSubsystem_h);
        }
      } else if (VisionModel_U.ModeSelect == 4.0) {
        /* Embedded MATLAB: '<S7>/Analyze LabelMatrix for Targets' */
        /* Embedded MATLAB Function 'torpedo/Analyze LabelMatrix for Targets': '<S34>:1' */
        /*  This function takes in vectors representing blobs present in the image, */
        /*    and returns information about how many and what kind of buoys are */
        /*    present. */
        /*  */
        /*  Input */
        /*    blob_count = integer number of blobs in image */
        /*    blob_hues = Nx1 vector of hues of blobs in image */
        /*    blob_centroids = Nx2 matrix of x-y pairs of blob centroid locations */
        /*    blob_eccentricity = Nx1 vector of blob eccentricites */
        /*    blob_extent = Nx1 vector of blob extents */
        /*  */
        /*    Buoy_Count_Min = integer; minimum number of buoys searched for in an */
        /*      image (mission/controls needs requires this option) */
        /*    Buoy_Count_Max = maximum number of buoys allowed per image; arbitrary */
        /*      limit */
        /*    Min_Hue,Max_Hue = Nx1 limits on valid buoy hues; hue is between 0 and 1 */
        /*    Min_Eccent,Max_Eccent = scalar limits on buoy eccentricity */
        /*    Min_Extent,Max_Extent = scalar limits on buoy extent */
        /*  */
        /*  Output */
        /*    successive_valid_image_count = integer value of the number of times an */
        /*      image with more than Min_Num_Buoys is processed; persistant between */
        /*      function calls, so that the number of successive images containing */
        /*      at least Min_Num_Buoys buoys is tracked */
        /*    buoy_count = integer number of buoys in image */
        /*    buoy_hues = Nx1 vector of buoy colors */
        /*    buoy_centroids = Nx2 matrix of x-y pairs of buoy centroid locations */
        /* '<S34>:1:30' */
        /* '<S34>:1:31' */
        /* { */
        /*  */
        /*  Initialize */
        /* persistent successive_valid_image_count; */
        /* buoy_count = double(0); */
        /*  */
        /* debug */
        /* successive_valid_image_count = 0; */
        /* Buoy_Count_Max = 50; */
        /*  */
        /* /debug */
        /* buoy_hues = double(zeros(Buoy_Count_Max,1)); */
        /* buoy_centroids = double(-500.*ones(Buoy_Count_Max,2));  % Initialize to points clearly not located in image */
        /*  */
        /* buoy_id = double(-1.*ones(Buoy_Count_Max,1)); */
        /* Buoy_Hue_HalfRange = 10; */
        /* Buoy1_Hue = 30; */
        /* Buoy2_Hue = 80; */
        /* Buoy3_Hue = 15; */
        /*  */
        /*  Loop through blobs, and analyze and extract buoy information */
        /* for i = 1:blob_count */
        /*      */
        /*     % Convert Lab to XYZ */
        /*     R = buoy_hues(i); */
        /*     G = buoy_hues(i); */
        /*     B = buoy_hues(i); */
        /*      */
        /*     L = blob_hues(:,1); %refcolors(LabelMatrix(1,1,1)); */
        /*     a = blob_hues(:,2); */
        /*     b = blob_hues(:,3); */
        /*      */
        /*     var_Y = L./10; */
        /*     var_X = ( a./17.5 ).*( L./10 ); */
        /*     var_Z = ( b./7 ).*( L./10 ); */
        /*      */
        /*     Y = var_Y.^2; */
        /*     X = ( var_X + Y )./1.02; */
        /*     Z = -( var_Z - Y )./0.847; */
        /*      */
        /*     % Convert XYZ to RGB */
        /*     var_X = X./100;        %X from 0 to  95.047      (Observer = 2 degrees, Illuminant = D65) */
        /*     var_Y = Y./100;        %Y from 0 to 100.000 */
        /*     var_Z = Z./100;        %Z from 0 to 108.883 */
        /*      */
        /*     var_R = var_X.*3.2406 + var_Y.*(-1.5372) + var_Z.* -0.4986; */
        /*     var_G = var_X .* -0.9689 + var_Y .*  1.8758 + var_Z.*  0.0415; */
        /*     var_B = var_X .*  0.0557 + var_Y .* -0.2040 + var_Z .*  1.0570; */
        /*      */
        /*     var_R = ( var_R > 0.0031308 ).*( 1.055.*( var_R.^( 1./2.4 ) ) - 0.055 ) + ( var_R <= 0.0031308 ).*(12.92.*var_R); */
        /*     var_G = ( var_G > 0.0031308 ).*( 1.055.*( var_G.^( 1./2.4 ) ) - 0.055 ) + ( var_G <= 0.0031308 ).*( var_G <= 12.92.*var_G ); */
        /*     var_B = ( var_B > 0.0031308 ).*( 1.055 .* ( var_B .^ ( 1 ./ 2.4 ) ) - 0.055 ) + ( var_B <= 0.0031308 ).*( 12.92 .* var_B ); */
        /*      */
        /*     R = var_R .* 255; */
        /*     G = var_G .* 255; */
        /*     B = var_B .* 255; */
        /*      */
        /*     % Convert RGB to HSV */
        /*     var_R = ( R ./ 255 );  % RGB from 0 to 255 */
        /*     var_G = ( G ./ 255 ); */
        /*     var_B = ( B ./ 255 ); */
        /*      */
        /*     var_Min = min( [var_R, var_G, var_B], [], 2 );  % Min. value of RGB */
        /*     var_Max = max( [var_R, var_G, var_B], [], 2 );  % Max. value of RGB */
        /*     del_Max = var_Max - var_Min;  % Delta RGB value */
        /*      */
        /*     V = var_Max; */
        /*      */
        /*     H = (del_Max != 0).*(  ); */
        /*     S = (del_Max != 0).*( del_Max./var_Max ); */
        /*     if ( max(abs(del_Max == 0)) );  % This is a gray, no chroma... */
        /*         H = zeros(size(var_R));  % HSV results from 0 to 1 */
        /*         S = zeros(size(var_R)); */
        /*     else  % Chromatic data... */
        /*          */
        /*         S = del_Max ./ var_Max; */
        /*          */
        /*         del_R = ( ( ( var_Max - var_R ) ./ 6 ) + ( del_Max ./ 2 ) ) ./ del_Max; */
        /*         del_G = ( ( ( var_Max - var_G ) ./ 6 ) + ( del_Max ./ 2 ) ) ./ del_Max; */
        /*         del_B = ( ( ( var_Max - var_B ) ./ 6 ) + ( del_Max ./ 2 ) ) ./ del_Max; */
        /*          */
        /*         H = ( var_R == var_Max ).*( del_B - del_G ) + ( var_G == var_Max ).*( ( 1 ./ 3 ) + del_R - del_B ) + ( var_B == var_Max ).*( ( 2 ./ 3 ) + del_G - del_R ); */
        /*         H = ( H < 0 ).*( H + 1 ) + ( H > 1 ).*( H - 1 ); */
        /*          */
        /* {         */
        /*         if( var_R == var_Max ) */
        /*             H = del_B - del_G; */
        /*         elseif( var_G == var_Max ) */
        /*             H = ( 1 ./ 3 ) + del_R - del_B; */
        /*         elseif( var_B == var_Max ) */
        /*             H = ( 2 ./ 3 ) + del_G - del_R; */
        /*         else */
        /*             H = 0; */
        /*         end */
        /*          */
        /*         if( H < 0 ) */
        /*             H = H + 1; */
        /*         end */
        /*         if( H > 1 ) */
        /*             H = H - 1; */
        /*         end */
        /* }         */
        /*     end */
        /*      */
        /*     % Store buoy information if blob conditions are met */
        /*     %   Conditions: 1) Blob eccentricity is within specified range */
        /*     %               2) Blob extent is within specified range */
        /*     %               3) Blob hue is within specified range for several buoy */
        /*     %                 types */
        /*     if( (blob_eccentricity(i)>=Min_Eccent) && (blob_eccentricity(i)<=Max_Eccent) && (blob_extent(i)>=Min_Extent) && (blob_extent(i)<=Max_Extent) ) */
        /*          */
        /*         %if( (blob_hues(i)>=Buoy1_Hue-Buoy_Hue_HalfRange) && (blob_hues(i)<=Buoy1_Hue+Buoy_Hue_HalfRange) ) */
        /*             buoy_count = buoy_count + 1; */
        /*             buoy_hues(buoy_count) = blob_hues(i); */
        /*             buoy_id(buoy_count) = 1; */
        /*             buoy_centroids(buoy_count,1) = blob_centroids(i,1); */
        /*             buoy_centroids(buoy_count,2) = blob_centroids(i,2); */
        /*         %end */
        /*         if( (blob_hues(i)>=Buoy2_Hue-Buoy_Hue_HalfRange) && (blob_hues(i)<=Buoy2_Hue+Buoy_Hue_HalfRange) ) */
        /*             buoy_count = buoy_count + 1; */
        /*             buoy_hues(buoy_count) = blob_hues(i); */
        /*             buoy_id(buoy_count) = 2; */
        /*             buoy_centroids(buoy_count,1) = blob_centroids(i,1); */
        /*             buoy_centroids(buoy_count,2) = blob_centroids(i,2); */
        /*         end */
        /*         if( (blob_hues(i)>=Buoy3_Hue-Buoy_Hue_HalfRange) && (blob_hues(i)<=Buoy3_Hue+Buoy_Hue_HalfRange) ) */
        /*             buoy_count = buoy_count + 1; */
        /*             buoy_hues(buoy_count) = blob_hues(i); */
        /*             buoy_id(buoy_count) = 3; */
        /*             buoy_centroids(buoy_count,1) = blob_centroids(i,1); */
        /*             buoy_centroids(buoy_count,2) = blob_centroids(i,2); */
        /*         end */
        /*     end */
        /*      */
        /* end */
        /*  */
        /*  Resize output arrays */
        /* buoy_hues = buoy_hues(1:buoy_count); */
        /* buoy_centroids = buoy_centroids(1:buoy_count,:); */
        /* buoy_id = ; */
        /*  */
        /* } */

        /* Embedded MATLAB: '<S7>/Decide which target to follow' */
        /* Embedded MATLAB Function 'torpedo/Decide which target to follow': '<S35>:1' */
        /*  Decide which target to shoot at, based on which color is wanted. */
        /*  */
        /*  Input */
        /*  */
        /*  Output */
        /*  */
        /*  Initialize */
        /*  */
        /* '<S35>:1:14' */
        VisionModel_B.target_select_j = 1.0;

        /* '<S35>:1:15' */
        /* '<S35>:1:16' */
        VisionModel_B.target_y_m = 0.0;

        /* '<S35>:1:17' */
        VisionModel_B.target_z_d = 0.0;

        /* '<S35>:1:18' */
        VisionModel_B.target_yaw_k = 0.0;

        /* '<S35>:1:19' */
        VisionModel_B.target_detected_e = 0.0;

        /* '<S35>:1:20' */
        VisionModel_B.fire_authorization = 0.0;

        /* If: '<S7>/If1' incorporates:
         *  ActionPort: '<S36>/Action Port'
         *  Inport: '<Root>/OutputImage'
         *  SubSystem: '<S7>/If Action Subsystem'
         */
        if (VisionModel_U.OutputImage > 0.0) {
          VisionModel_IfActionSubsystem(VisionModel_B.bw_image,
            VisionModel_P.which_camera_Value_j, 0.0, VisionModel_B.target_y_m,
            VisionModel_B.target_z_d,
            VisionModel_P.Forward_Camera_Dimensions2_Va_d,
            &VisionModel_B.IfActionSubsystem_l, (rtP_IfActionSubsystem_VisionMod
            *) &VisionModel_P.IfActionSubsystem_l);
        }
      } else {
        if (VisionModel_U.ModeSelect == 5.0) {
          /* S-Function (svipedge): '<S4>/Edge Detection1' */
          for (find_white = 1; find_white < 119; find_white++) {
            for (flag = 1; flag < 159; flag++) {
              accumOne = 0.0;
              accumTwo = 0.0;
              found = find_white * 160 + flag;
              for (m = 0; m < 6; m++) {
                accumOne += VisionModel_B.bw_image[found +
                  VisionModel_DWork.EdgeDetection1_VO_DW[m]] *
                  VisionModel_ConstP.pooled3[m];
                accumTwo += VisionModel_B.bw_image[found +
                  VisionModel_DWork.EdgeDetection1_HO_DW[m]] *
                  VisionModel_ConstP.pooled4[m];
              }

              VisionModel_DWork.EdgeDetection1_GV_SQUARED_DW[found] = accumOne *
                accumOne;
              VisionModel_DWork.EdgeDetection1_GH_SQUARED_DW[found] = accumTwo *
                accumTwo;
            }
          }

          for (find_white = 1; find_white < 119; find_white++) {
            accumOne = 0.0;
            accumTwo = 0.0;
            accumThree = 0.0;
            accumFour = 0.0;
            found = find_white * 160;
            flag = find_white * 160 + 159;
            for (m = 0; m < 6; m++) {
              accumOne += VisionModel_B.bw_image[found +
                VisionModel_DWork.EdgeDetection1_HOU_DW[m]] *
                VisionModel_ConstP.pooled4[m];
              accumTwo += VisionModel_B.bw_image[flag +
                VisionModel_DWork.EdgeDetection1_HOD_DW[m]] *
                VisionModel_ConstP.pooled4[m];
              accumThree += VisionModel_B.bw_image[found +
                VisionModel_DWork.EdgeDetection1_VOU_DW[m]] *
                VisionModel_ConstP.pooled3[m];
              accumFour += VisionModel_B.bw_image[flag +
                VisionModel_DWork.EdgeDetection1_VOD_DW[m]] *
                VisionModel_ConstP.pooled3[m];
            }

            VisionModel_DWork.EdgeDetection1_GV_SQUARED_DW[found] = accumThree *
              accumThree;
            VisionModel_DWork.EdgeDetection1_GH_SQUARED_DW[found] = accumOne *
              accumOne;
            VisionModel_DWork.EdgeDetection1_GV_SQUARED_DW[flag] = accumFour *
              accumFour;
            VisionModel_DWork.EdgeDetection1_GH_SQUARED_DW[flag] = accumTwo *
              accumTwo;
          }

          for (flag = 1; flag < 159; flag++) {
            accumOne = 0.0;
            accumTwo = 0.0;
            accumThree = 0.0;
            accumFour = 0.0;
            found = 19040 + flag;
            for (m = 0; m < 6; m++) {
              accumOne += VisionModel_B.bw_image[flag +
                VisionModel_DWork.EdgeDetection1_VOL_DW[m]] *
                VisionModel_ConstP.pooled3[m];
              accumTwo += VisionModel_B.bw_image[found +
                VisionModel_DWork.EdgeDetection1_VOR_DW[m]] *
                VisionModel_ConstP.pooled3[m];
              accumThree += VisionModel_B.bw_image[flag +
                VisionModel_DWork.EdgeDetection1_HOL_DW[m]] *
                VisionModel_ConstP.pooled4[m];
              accumFour += VisionModel_B.bw_image[found +
                VisionModel_DWork.EdgeDetection1_HOR_DW[m]] *
                VisionModel_ConstP.pooled4[m];
            }

            VisionModel_DWork.EdgeDetection1_GV_SQUARED_DW[flag] = accumOne *
              accumOne;
            VisionModel_DWork.EdgeDetection1_GH_SQUARED_DW[flag] = accumThree *
              accumThree;
            VisionModel_DWork.EdgeDetection1_GV_SQUARED_DW[found] = accumTwo *
              accumTwo;
            VisionModel_DWork.EdgeDetection1_GH_SQUARED_DW[found] = accumFour *
              accumFour;
          }

          accumOne = 0.0;
          accumTwo = 0.0;
          accumThree = 0.0;
          accumFour = 0.0;
          for (m = 0; m < 6; m++) {
            accumOne +=
              VisionModel_B.bw_image[VisionModel_DWork.EdgeDetection1_VOUL_DW[m]]
              * VisionModel_ConstP.pooled3[m];
            accumTwo +=
              VisionModel_B.bw_image[VisionModel_DWork.EdgeDetection1_HOUL_DW[m]]
              * VisionModel_ConstP.pooled4[m];
            accumThree += VisionModel_B.bw_image[159 +
              VisionModel_DWork.EdgeDetection1_VOLL_DW[m]] *
              VisionModel_ConstP.pooled3[m];
            accumFour += VisionModel_B.bw_image[159 +
              VisionModel_DWork.EdgeDetection1_HOLL_DW[m]] *
              VisionModel_ConstP.pooled4[m];
          }

          VisionModel_DWork.EdgeDetection1_GV_SQUARED_DW[0] = accumOne *
            accumOne;
          VisionModel_DWork.EdgeDetection1_GH_SQUARED_DW[0] = accumTwo *
            accumTwo;
          VisionModel_DWork.EdgeDetection1_GV_SQUARED_DW[159] = accumThree *
            accumThree;
          VisionModel_DWork.EdgeDetection1_GH_SQUARED_DW[159] = accumFour *
            accumFour;
          accumOne = 0.0;
          accumTwo = 0.0;
          accumThree = 0.0;
          accumFour = 0.0;
          for (m = 0; m < 6; m++) {
            accumOne += VisionModel_B.bw_image[19040 +
              VisionModel_DWork.EdgeDetection1_VOUR_DW[m]] *
              VisionModel_ConstP.pooled3[m];
            accumTwo += VisionModel_B.bw_image[19040 +
              VisionModel_DWork.EdgeDetection1_HOUR_DW[m]] *
              VisionModel_ConstP.pooled4[m];
            accumThree += VisionModel_B.bw_image[19199 +
              VisionModel_DWork.EdgeDetection1_VOLR_DW[m]] *
              VisionModel_ConstP.pooled3[m];
            accumFour += VisionModel_B.bw_image[19199 +
              VisionModel_DWork.EdgeDetection1_HOLR_DW[m]] *
              VisionModel_ConstP.pooled4[m];
          }

          VisionModel_DWork.EdgeDetection1_GV_SQUARED_DW[19040] = accumOne *
            accumOne;
          VisionModel_DWork.EdgeDetection1_GH_SQUARED_DW[19040] = accumTwo *
            accumTwo;
          VisionModel_DWork.EdgeDetection1_GV_SQUARED_DW[19199] = accumThree *
            accumThree;
          VisionModel_DWork.EdgeDetection1_GH_SQUARED_DW[19199] = accumFour *
            accumFour;
          accumTwo = 0.0;
          for (m = 0; m < 19200; m++) {
            VisionModel_DWork.EdgeDetection1_GRAD_SUM_DW[m] =
              VisionModel_DWork.EdgeDetection1_GV_SQUARED_DW[m];
            VisionModel_DWork.EdgeDetection1_GRAD_SUM_DW[m] =
              VisionModel_DWork.EdgeDetection1_GRAD_SUM_DW[m] +
              VisionModel_DWork.EdgeDetection1_GH_SQUARED_DW[m];
            accumTwo += VisionModel_DWork.EdgeDetection1_GRAD_SUM_DW[m] *
              VisionModel_DWork.EdgeDetection1_MEAN_FACTOR_DW;
          }

          accumOne = VisionModel_P.EdgeDetection1_THRESH_TUNING_RT * accumTwo;
          for (find_white = 0; find_white < 120; find_white++) {
            for (flag = 0; flag < 160; flag++) {
              m = find_white * 160 + flag;
              VisionModel_B.EdgeDetection1[m] =
                ((VisionModel_DWork.EdgeDetection1_GRAD_SUM_DW[m] > accumOne) &&
                 (((VisionModel_DWork.EdgeDetection1_GV_SQUARED_DW[m] >=
                    VisionModel_DWork.EdgeDetection1_GH_SQUARED_DW[m]) &&
                   (find_white != 0 ?
                    VisionModel_DWork.EdgeDetection1_GRAD_SUM_DW[m - 160] <=
                    VisionModel_DWork.EdgeDetection1_GRAD_SUM_DW[m] : TRUE) &&
                   (find_white != 119 ?
                    VisionModel_DWork.EdgeDetection1_GRAD_SUM_DW[m] >
                    VisionModel_DWork.EdgeDetection1_GRAD_SUM_DW[m + 160] : TRUE))
                  || ((VisionModel_DWork.EdgeDetection1_GH_SQUARED_DW[m] >=
                       VisionModel_DWork.EdgeDetection1_GV_SQUARED_DW[m]) &&
                      (flag != 0 ?
                       VisionModel_DWork.EdgeDetection1_GRAD_SUM_DW[m - 1] <=
                       VisionModel_DWork.EdgeDetection1_GRAD_SUM_DW[m] : TRUE) &&
                      (flag != 159 ?
                       VisionModel_DWork.EdgeDetection1_GRAD_SUM_DW[m] >
                       VisionModel_DWork.EdgeDetection1_GRAD_SUM_DW[m + 1] :
                       TRUE))));
            }
          }

          /* S-Function (sviphough): '<S4>/Hough Transform2' */
          MWVIP_Hough_D(&VisionModel_B.EdgeDetection1[0],
                        &VisionModel_B.HoughTransform2_o1[0],
                        &VisionModel_ConstP.pooled5[0],
                        &VisionModel_ConstP.pooled6, 160, 120, 399, 91);

          /* Embedded MATLAB: '<S4>/Identify L-Obstacle' incorporates:
           *  Constant: '<S4>/Constant1'
           *  Constant: '<S4>/Constant2'
           *  Constant: '<S4>/Constant5'
           *  Constant: '<S4>/Forward_Camera_Dimensions'
           */
          memcpy((void *)(&VisionModel_B.hough_table[0]), (void *)
                 (&VisionModel_B.HoughTransform2_o1[0]), 71820U * sizeof(real_T));
          memcpy((void *)&ref_color_L_avg[0], (void *)
                 (&VisionModel_B.blob_orientation[0]), 50U * sizeof(real_T));

          /* Embedded MATLAB Function 'L_detector/Identify L-Obstacle': '<S27>:1' */
          /* { */
          /*  */
          /* 1. Iteratively segment image */
          /* 2. Obtain information about all blobs in image */
          /* 3. Generate a bw image by filtering colors (thresholding) */
          /*  */
          /* 3.5. Identify one appropriate horizontal and one appropriate vertical blob */
          /*  */
          /* 4. Perform edge detection then Hough transform to bw image */
          /* 5. Identify the most popular lines (any orientation) that are: */
          /*      a) Nearly colinear with blobs, and */
          /*      b) At approximately 90 degrees from each other */
          /*  */
          /* 6. Target appropriately */
          /*  */
          /* } */
          /*  This function attempts to identfiy the L-shaped obstacle, and returns */
          /*    targeting information, and a true/false target_detected parameter. */
          /*  Initialize */
          /* '<S27>:1:28' */
          VisionModel_B.target_select = 1.0;

          /* '<S27>:1:30' */
          /*  Only the (max_num_lines) with the most votes will be considered as */
          /*    candidates for the gate */
          /* '<S27>:1:41' */
          /* '<S27>:1:42' */
          /* '<S27>:1:44' */
          accumThree = VisionModel_P.Forward_Camera_Dimensions_Val_h[0] *
            VisionModel_P.Forward_Camera_Dimensions_Val_h[1];

          /* '<S27>:1:45' */
          /*  Ratio of blob area to image area considered to imply the blob is actually background noise */
          /*  eps_rho must be at least as big as the gate leg diameter (units of */
          /*    pixels) */
          /* '<S27>:1:49' */
          accumFour = ((VisionModel_P.Forward_Camera_Dimensions_Val_h[0] >=
                        VisionModel_P.Forward_Camera_Dimensions_Val_h[1]) ||
                       rtIsNaN(VisionModel_P.Forward_Camera_Dimensions_Val_h[1])
                       ? VisionModel_P.Forward_Camera_Dimensions_Val_h[0] :
                       VisionModel_P.Forward_Camera_Dimensions_Val_h[1]) * 0.1;

          /*  eps_theta is used to distinguish lines as "horizontal" or "vertical"; */
          /*    units are radians */
          /* '<S27>:1:52' */
          /*  These vectors contain the final two lines that compose the L-obstacle */
          /*  These vectors contain intermediate line information; as lines are */
          /*    eliminated from these vectors, their values are set to zero */
          /*  Note that rho_in and theta_in are referred to by hough_table; they do not */
          /*    constitute (rho,theta) pairs without hough_table. rho and theta, */
          /*    however, do constitute (rho,theta) pairs. */
          /* '<S27>:1:63' */
          /* '<S27>:1:64' */
          /*  Identify the most popular max_num_lines lines */
          /* '<S27>:1:68' */
          /* '<S27>:1:69' */
          for (i = 0; i < 200; i++) {
            i_index[i] = 1;
            j_index[i] = 1U;
          }

          /* '<S27>:1:71' */
          for (m = 0; m < 200; m++) {
            /* '<S27>:1:71' */
            /* '<S27>:1:73' */
            accumOne = 0.0;

            /* '<S27>:1:74' */
            for (i = 0; i < 399; i++) {
              /* '<S27>:1:74' */
              /* '<S27>:1:75' */
              for (j = 0; j < 180; j++) {
                /* '<S27>:1:75' */
                if (VisionModel_B.hough_table[399 * j + i] > accumOne) {
                  /* '<S27>:1:76' */
                  /* '<S27>:1:77' */
                  i_index[m] = (int16_T)(i + 1);

                  /* '<S27>:1:78' */
                  j_index[m] = (uint8_T)(j + 1);

                  /* '<S27>:1:79' */
                  accumOne = VisionModel_B.hough_table[399 * j + i];
                }
              }
            }

            /* '<S27>:1:84' */
            rho[m] = VisionModel_B.HoughTransform2_o3[i_index[m] - 1];

            /* '<S27>:1:85' */
            theta[m] = VisionModel_B.HoughTransform2_o2[j_index[m] - 1];

            /* '<S27>:1:86' */
            VisionModel_B.hough_table[(i_index[m] - 1) + 399 * (j_index[m] - 1)]
              = 0.0;
          }

          /*  Correct orientations to vehicle coordinates */
          /* '<S27>:1:92' */
          for (accumOne = 1.0; accumOne <= VisionModel_B.blob_count; accumOne++)
          {
            /* '<S27>:1:92' */
            /*  theta_hold: */
            /*    -is between [-pi/2, +pi/2] */
            /*  blob_orientation: */
            /*    -is potentially outside this range */
            /*    -needs to be corrected by pi/2 to get relative heading */
            /* '<S27>:1:98' */
            ref_color_L_avg[(int32_T)accumOne - 1] = VisionModel_mod
              (3.1415926535897931 - ref_color_L_avg[(int32_T)accumOne - 1],
               3.1415926535897931) - 1.5707963267948966;
          }

          /*  Determine the most popular lines which are nearly colinear to blobs */
          /* '<S27>:1:103' */
          memcpy((void *)&theta_hold[0], (void *)&theta[0], 200U * sizeof(real_T));

          /* '<S27>:1:104' */
          i = 0;
          i_gate_idx_0 = 0.0;
          m = 0;
          i_gate_idx = 0.0;

          /*  Indices for line and blob, respectively */
          /* '<S27>:1:105' */
          /* '<S27>:1:107' */
          found = 0;

          /* '<S27>:1:108' */
          imgIdxLL = 1;
          exitg_0 = FALSE;
          while (((uint32_T)exitg_0 == 0U) && (imgIdxLL <= 200)) {
            /* '<S27>:1:108' */
            /* '<S27>:1:109' */
            accumOne = 1.0;
            exitg = FALSE;
            while (((uint32_T)exitg == 0U) && (accumOne <=
                    VisionModel_B.blob_count)) {
              /* '<S27>:1:109' */
              /*  Search for a match between one blob and one line */
              /* '<S27>:1:112' */
              /* '<S27>:1:113' */
              if ((theta_hold[imgIdxLL - 1] != 1000.0) && (ref_color_L_avg
                   [(int32_T)accumOne - 1] != 1000.0)) {
                /* '<S27>:1:114' */
                c_0 = TRUE;
              } else {
                /* '<S27>:1:114' */
                c_0 = FALSE;
              }

              /* '<S27>:1:115' */
              /* '<S27>:1:116' */
              /* '<S27>:1:117' */
              accumTwo = VisionModel_B.blob_centroids[(((int32_T)accumOne - 1) <<
                1U) + 1] * sin(theta[imgIdxLL - 1]) + (rho[imgIdxLL - 1] * cos
                (theta[imgIdxLL - 1]) - VisionModel_B.blob_centroids[(((int32_T)
                accumOne - 1) << 1U)]);

              /* '<S27>:1:118' */
              /* '<S27>:1:119' */
              /* '<S27>:1:120' */
              if ((fabs(theta_hold[imgIdxLL - 1] - ref_color_L_avg[(int32_T)
                        accumOne - 1]) <= 0.17453292519943295) &&
                  (VisionModel_B.blob_area[(int32_T)accumOne - 1] / accumThree <=
                   0.8) && c_0 && (sqrt(rt_pow_snf(((-(1.0 / tan(theta[imgIdxLL
                         - 1]))) * accumTwo + rho[imgIdxLL - 1] / sin
                      (theta[imgIdxLL - 1])) - VisionModel_B.blob_centroids
                     [(((int32_T)accumOne - 1) << 1U)], 2.0) + rt_pow_snf
                    (accumTwo - VisionModel_B.blob_centroids[(((int32_T)accumOne
                       - 1) << 1U) + 1], 2.0)) <= accumFour)) {
                /* '<S27>:1:121' */
                /* '<S27>:1:114' */
                /* '<S27>:1:121' */
                /* '<S27>:1:123' */
                /*  Determine the first gate element */
                /* '<S27>:1:126' */
                i = imgIdxLL;

                /* '<S27>:1:127' */
                i_gate_idx_0 = accumOne;

                /* '<S27>:1:141' */
                theta_hold[imgIdxLL - 1] = 1000.0;

                /*  Invalid angle; do not want this line to be selected again */
                /* '<S27>:1:142' */
                ref_color_L_avg[(int32_T)accumOne - 1] = 1000.0;

                /* '<S27>:1:143' */
                found = 1;
                exitg = TRUE;
              } else {
                accumOne++;
              }
            }

            if (found == 1) {
              /* '<S27>:1:149' */
              exitg_0 = TRUE;
            } else {
              imgIdxLL++;
            }
          }

          /* '<S27>:1:105' */
          /* '<S27>:1:107' */
          found = 0;

          /* '<S27>:1:108' */
          imgIdxLL = 1;
          exitg_0 = FALSE;
          while (((uint32_T)exitg_0 == 0U) && (imgIdxLL <= 200)) {
            /* '<S27>:1:108' */
            /* '<S27>:1:109' */
            accumOne = 1.0;
            exitg = FALSE;
            while (((uint32_T)exitg == 0U) && (accumOne <=
                    VisionModel_B.blob_count)) {
              /* '<S27>:1:109' */
              /*  Search for a match between one blob and one line */
              /* '<S27>:1:112' */
              /* '<S27>:1:113' */
              if ((theta_hold[imgIdxLL - 1] != 1000.0) && (ref_color_L_avg
                   [(int32_T)accumOne - 1] != 1000.0)) {
                /* '<S27>:1:114' */
                c_0 = TRUE;
              } else {
                /* '<S27>:1:114' */
                c_0 = FALSE;
              }

              /* '<S27>:1:115' */
              /* '<S27>:1:116' */
              /* '<S27>:1:117' */
              accumTwo = VisionModel_B.blob_centroids[(((int32_T)accumOne - 1) <<
                1U) + 1] * sin(theta[imgIdxLL - 1]) + (rho[imgIdxLL - 1] * cos
                (theta[imgIdxLL - 1]) - VisionModel_B.blob_centroids[(((int32_T)
                accumOne - 1) << 1U)]);

              /* '<S27>:1:118' */
              /* '<S27>:1:119' */
              /* '<S27>:1:120' */
              if ((fabs(theta_hold[imgIdxLL - 1] - ref_color_L_avg[(int32_T)
                        accumOne - 1]) <= 0.17453292519943295) &&
                  (VisionModel_B.blob_area[(int32_T)accumOne - 1] / accumThree <=
                   0.8) && c_0 && (sqrt(rt_pow_snf(((-(1.0 / tan(theta[imgIdxLL
                         - 1]))) * accumTwo + rho[imgIdxLL - 1] / sin
                      (theta[imgIdxLL - 1])) - VisionModel_B.blob_centroids
                     [(((int32_T)accumOne - 1) << 1U)], 2.0) + rt_pow_snf
                    (accumTwo - VisionModel_B.blob_centroids[(((int32_T)accumOne
                       - 1) << 1U) + 1], 2.0)) <= accumFour)) {
                /* '<S27>:1:121' */
                /* '<S27>:1:114' */
                /* '<S27>:1:121' */
                /*  Assume the first gate element was found correctly; */
                /*    check that all other gate elements are at right */
                /*    angles to the first */
                if (fabs(1.5707963267948966 - fabs(theta_hold[imgIdxLL - 1] -
                      theta_hold[i - 1])) <= 0.17453292519943295) {
                  /* '<S27>:1:134' */
                  /* '<S27>:1:135' */
                  m = imgIdxLL;

                  /* '<S27>:1:136' */
                  i_gate_idx = accumOne;
                }

                /* '<S27>:1:141' */
                theta_hold[imgIdxLL - 1] = 1000.0;

                /*  Invalid angle; do not want this line to be selected again */
                /* '<S27>:1:142' */
                ref_color_L_avg[(int32_T)accumOne - 1] = 1000.0;

                /* '<S27>:1:143' */
                found = 1;
                exitg = TRUE;
              } else {
                accumOne++;
              }
            }

            if (found == 1) {
              /* '<S27>:1:149' */
              exitg_0 = TRUE;
            } else {
              imgIdxLL++;
            }
          }

          if ((i == 0) && (i_gate_idx_0 == 0.0)) {
            /* '<S27>:1:157' */
            condition = TRUE;
          } else {
            /* '<S27>:1:157' */
            condition = FALSE;
          }

          if (!condition) {
            /* '<S27>:1:157' */
            /*  Sort elements of i_gate to place the vertical element in the first */
            /*    position, horizontal element in second position */
            /* '<S27>:1:161' */
            /* '<S27>:1:162' */
            accumOne = i_gate_idx_0;
            if (fabs(theta[i - 1]) > fabs(theta[m - 1])) {
              /* '<S27>:1:163' */
              /* '<S27>:1:164' */
              /* '<S27>:1:165' */
              i_gate_idx_0 = i_gate_idx;

              /* '<S27>:1:167' */
              /* '<S27>:1:168' */
              i_gate_idx = accumOne;
            }

            /*  Assign appropriate gate information */
            /* '<S27>:1:173' */
            /*  Compute targeting information */
            /*  Determine side lengths and distances for target */
            /* '<S27>:1:181' */
            /* '<S27>:1:182' */
            /* '<S27>:1:183' */
            accumTwo = VisionModel_B.blob_major_axis[(int32_T)i_gate_idx_0 - 1] *
              VisionModel_P.Constant1_Value_i;

            /* '<S27>:1:184' */
            accumThree = VisionModel_B.blob_major_axis[(int32_T)i_gate_idx - 1] *
              VisionModel_P.Constant5_Value;

            /* '<S27>:1:186' */
            /* '<S27>:1:187' */
            /* '<S27>:1:188' */
            positive_area = 1.5707963267948966 - ref_color_L_avg[(int32_T)
              i_gate_idx_0 - 1];

            /* '<S27>:1:189' */
            accumFour = 1.5707963267948966 - ref_color_L_avg[(int32_T)i_gate_idx
              - 1];

            /* '<S27>:1:191' */
            /* '<S27>:1:192' */
            /* '<S27>:1:193' */
            /* '<S27>:1:194' */
            /* '<S27>:1:196' */
            accumOne = VisionModel_B.blob_centroids[(((int32_T)i_gate_idx_0 - 1)
              << 1U) + 1] * sin(positive_area) + VisionModel_B.blob_centroids
              [(((int32_T)i_gate_idx_0 - 1) << 1U)] * cos(positive_area);

            /* '<S27>:1:197' */
            /* '<S27>:1:199' */
            r = (accumOne * sin(accumFour) - (VisionModel_B.blob_centroids
                  [(((int32_T)i_gate_idx - 1) << 1U) + 1] * sin(accumFour) +
                  VisionModel_B.blob_centroids[(((int32_T)i_gate_idx - 1) << 1U)]
                  * cos(accumFour)) * sin(positive_area)) * (1.0 / (cos
              (positive_area) * sin(accumFour) - cos(accumFour) * sin
              (positive_area)));

            /* '<S27>:1:200' */
            c = (-(1.0 / tan(positive_area))) * r + accumOne / sin(positive_area);

            /* r3 = (1/( sin(phi1)*cos(phi2) - sin(phi2)*cos(phi1) ))*( c2 - c1 + sin(pih1)*cos(phi2)*r1 - sin(phi2)*cos(phi1)*r2 ); */
            /* c3 = r3*tan(phi1) + c1 - r1*tan(phi1); */
            /* '<S27>:1:204' */
            /* '<S27>:1:205' */
            /* '<S27>:1:207' */
            /* '<S27>:1:208' */
            /* '<S27>:1:213' */
            accumTwo = (sin(ref_color_L_avg[(int32_T)i_gate_idx_0 - 1]) *
                        accumTwo + c) * sin(positive_area) + (r - cos
              (ref_color_L_avg[(int32_T)i_gate_idx_0 - 1]) * accumTwo) * cos
              (positive_area);

            /* '<S27>:1:214' */
            /* '<S27>:1:216' */
            accumOne = (accumTwo * sin(accumFour) - ((cos(ref_color_L_avg
              [(int32_T)i_gate_idx - 1]) * accumThree + c) * sin(accumFour) +
              (sin(ref_color_L_avg[(int32_T)i_gate_idx - 1]) * accumThree + r) *
              cos(accumFour)) * sin(positive_area)) * (1.0 / (cos(positive_area)
              * sin(accumFour) - cos(accumFour) * sin(positive_area)));

            /* '<S27>:1:217' */
            /*  Transform target r, c to global coordinate system */
            /* '<S27>:1:222' */
            VisionModel_B.target_z = accumOne - floor
              (VisionModel_P.Forward_Camera_Dimensions_Val_h[0] / 2.0);

            /* '<S27>:1:223' */
            accumOne = ((-(1.0 / tan(positive_area))) * accumOne + accumTwo /
                        sin(positive_area)) - floor
              (VisionModel_P.Forward_Camera_Dimensions_Val_h[1] / 2.0);

            /* '<S27>:1:225' */
            VisionModel_B.target_yaw = accumOne /
              VisionModel_P.Forward_Camera_Dimensions_Val_h[1] *
              VisionModel_P.Constant2_Value_f;

            /* '<S27>:1:226' */
            VisionModel_B.target_detected = 0.0;
          } else {
            /* '<S27>:1:230' */
            accumOne = 0.0;

            /* '<S27>:1:231' */
            VisionModel_B.target_z = 0.0;

            /* '<S27>:1:232' */
            VisionModel_B.target_yaw = 0.0;

            /* '<S27>:1:233' */
            VisionModel_B.target_detected = 0.0;
          }

          VisionModel_B.target_y = accumOne;

          /* If: '<S4>/If1' incorporates:
           *  ActionPort: '<S28>/Action Port'
           *  Inport: '<Root>/OutputImage'
           *  SubSystem: '<S4>/If Action Subsystem'
           */
          if (VisionModel_U.OutputImage > 0.0) {
            VisionModel_IfActionSubsystem(VisionModel_B.bw_image,
              VisionModel_P.which_camera_Value_h, 0.0, VisionModel_B.target_y,
              VisionModel_B.target_z,
              VisionModel_P.Forward_Camera_Dimensions2_Va_e,
              &VisionModel_B.IfActionSubsystem_m,
              (rtP_IfActionSubsystem_VisionMod *)
              &VisionModel_P.IfActionSubsystem_m);
          }
        }
      }
    }
  }

  for (i = 0; i < 19200; i++) {
    /* Outport: '<Root>/R_forward_out' incorporates:
     *  Sum: '<Root>/Add22'
     */
    VisionModel_Y.R_forward_out[i] = ((((VisionModel_B.DrawShapes_o1[i] +
      VisionModel_B.IfActionSubsystem_h.DrawTarget_o1[i]) +
      VisionModel_B.IfActionSubsystem_l.DrawTarget_o1[i]) +
      VisionModel_B.IfActionSubsystem_m.DrawTarget_o1[i]) + 0.0) + 0.0;

    /* Outport: '<Root>/G_forward_out' incorporates:
     *  Sum: '<Root>/Add23'
     */
    VisionModel_Y.G_forward_out[i] = ((((VisionModel_B.DrawShapes_o2[i] +
      VisionModel_B.IfActionSubsystem_h.DrawTarget_o2[i]) +
      VisionModel_B.IfActionSubsystem_l.DrawTarget_o2[i]) +
      VisionModel_B.IfActionSubsystem_m.DrawTarget_o2[i]) + 0.0) + 0.0;

    /* Outport: '<Root>/B_forward_out' incorporates:
     *  Sum: '<Root>/Add24'
     */
    VisionModel_Y.B_forward_out[i] = ((((VisionModel_B.DrawShapes_o3[i] +
      VisionModel_B.IfActionSubsystem_h.DrawTarget_o3[i]) +
      VisionModel_B.IfActionSubsystem_l.DrawTarget_o3[i]) +
      VisionModel_B.IfActionSubsystem_m.DrawTarget_o3[i]) + 0.0) + 0.0;
  }

  /* Outport: '<Root>/TargetSelect' incorporates:
   *  Sum: '<Root>/Add'
   */
  VisionModel_Y.TargetSelect = ((((VisionModel_B.Constant3 + 0.0) +
    VisionModel_B.target_select_f) + VisionModel_B.target_select_j) +
    VisionModel_B.target_select) + 0.0;

  /* Outport: '<Root>/TargetY' incorporates:
   *  Sum: '<Root>/Add4'
   */
  VisionModel_Y.TargetY = ((((VisionModel_B.target_y_c + 0.0) +
    VisionModel_B.targetY) + VisionModel_B.target_y_m) + VisionModel_B.target_y)
    + 0.0;

  /* Outport: '<Root>/TargetZ' incorporates:
   *  Sum: '<Root>/Add5'
   */
  VisionModel_Y.TargetZ = ((((VisionModel_B.target_z_o + VisionModel_B.targetZ)
    + VisionModel_B.target_z_d) + VisionModel_B.target_z) + 0.0) + 0.0;

  /* Outport: '<Root>/TargetYaw' incorporates:
   *  Sum: '<Root>/Add6'
   */
  VisionModel_Y.TargetYaw = ((((VisionModel_B.target_yaw_o + 0.0) +
    VisionModel_B.targetYaw) + VisionModel_B.target_yaw_k) +
    VisionModel_B.target_yaw) + 0.0;

  /* Outport: '<Root>/TargetDetected' incorporates:
   *  Sum: '<Root>/Add18'
   */
  VisionModel_Y.TargetDetected = ((((VisionModel_B.gate_found + 0.0) +
    VisionModel_B.target_detected_d) + VisionModel_B.target_detected_e) +
    VisionModel_B.target_detected) + 0.0;

  /* Outport: '<Root>/BuoyColors' */
  memcpy((void *)(&VisionModel_Y.BuoyColors[0]), (void *)
         (&VisionModel_B.buoy_centroids[0]), 100U * sizeof(real_T));

  /* Outport: '<Root>/FireAuthorization' incorporates:
   *  Sum: '<Root>/Add21'
   */
  VisionModel_Y.FireAuthorization = ((((VisionModel_B.fire_authorization + 0.0)
    + 0.0) + 0.0) + 0.0) + 0.0;

  /* Outport: '<Root>/R_down_out' */
  VisionModel_Y.R_down_out = 0.0;

  /* Outport: '<Root>/G_down_out' */
  VisionModel_Y.G_down_out = 0.0;

  /* Outport: '<Root>/B_down_out' */
  VisionModel_Y.B_down_out = 0.0;

  /* Outport: '<Root>/TargetX' incorporates:
   *  Sum: '<Root>/Add3'
   */
  VisionModel_Y.TargetX = ((((0.0 + 0.0) + 0.0) + 0.0) + 0.0) + 0.0;

  /* Outport: '<Root>/DesiredTargetX' incorporates:
   *  Constant: '<Root>/Constant'
   */
  VisionModel_Y.DesiredTargetX = VisionModel_P.Constant_Value_o;

  /* Outport: '<Root>/DesiredTargetY' incorporates:
   *  Constant: '<Root>/Constant1'
   */
  VisionModel_Y.DesiredTargetY = VisionModel_P.Constant1_Value_k;

  /* Outport: '<Root>/DesiredTargetZ' incorporates:
   *  Constant: '<Root>/Constant2'
   */
  VisionModel_Y.DesiredTargetZ = VisionModel_P.Constant2_Value_fh;

  /* Outport: '<Root>/DesiredTargetYaw' incorporates:
   *  Constant: '<Root>/Constant3'
   */
  VisionModel_Y.DesiredTargetYaw = VisionModel_P.Constant3_Value_iy;

  /* Outport: '<Root>/PathState' incorporates:
   *  Sum: '<Root>/Add19'
   */
  VisionModel_Y.PathState = ((((0.0 + 0.0) + 0.0) + 0.0) + 0.0) + 0.0;

  /* Outport: '<Root>/TargetType' */
  VisionModel_Y.TargetType = 0.0;

  /* Outport: '<Root>/TargetSize' */
  VisionModel_Y.TargetSize = 0.0;
}

/* Model initialize function */
void VisionModel_initialize(void)
{
  /* Registration code */

  /* initialize non-finites */
  rt_InitInfAndNaN(sizeof(real_T));

  /* initialize error status */
  rtmSetErrorStatus(VisionModel_M, (NULL));

  /* block I/O */
  (void) memset(((void *) &VisionModel_B), 0,
                sizeof(BlockIO_VisionModel));

  {
    VisionModel_B.HoughTransform2_o2[0] = -1.5707963267948966;
    VisionModel_B.HoughTransform2_o2[1] = -1.5533430342749532;
    VisionModel_B.HoughTransform2_o2[2] = -1.53588974175501;
    VisionModel_B.HoughTransform2_o2[3] = -1.5184364492350666;
    VisionModel_B.HoughTransform2_o2[4] = -1.5009831567151235;
    VisionModel_B.HoughTransform2_o2[5] = -1.4835298641951802;
    VisionModel_B.HoughTransform2_o2[6] = -1.4660765716752369;
    VisionModel_B.HoughTransform2_o2[7] = -1.4486232791552935;
    VisionModel_B.HoughTransform2_o2[8] = -1.4311699866353502;
    VisionModel_B.HoughTransform2_o2[9] = -1.4137166941154069;
    VisionModel_B.HoughTransform2_o2[10] = -1.3962634015954636;
    VisionModel_B.HoughTransform2_o2[11] = -1.3788101090755203;
    VisionModel_B.HoughTransform2_o2[12] = -1.3613568165555769;
    VisionModel_B.HoughTransform2_o2[13] = -1.3439035240356338;
    VisionModel_B.HoughTransform2_o2[14] = -1.3264502315156905;
    VisionModel_B.HoughTransform2_o2[15] = -1.3089969389957472;
    VisionModel_B.HoughTransform2_o2[16] = -1.2915436464758039;
    VisionModel_B.HoughTransform2_o2[17] = -1.2740903539558606;
    VisionModel_B.HoughTransform2_o2[18] = -1.2566370614359172;
    VisionModel_B.HoughTransform2_o2[19] = -1.2391837689159739;
    VisionModel_B.HoughTransform2_o2[20] = -1.2217304763960306;
    VisionModel_B.HoughTransform2_o2[21] = -1.2042771838760873;
    VisionModel_B.HoughTransform2_o2[22] = -1.1868238913561442;
    VisionModel_B.HoughTransform2_o2[23] = -1.1693705988362009;
    VisionModel_B.HoughTransform2_o2[24] = -1.1519173063162575;
    VisionModel_B.HoughTransform2_o2[25] = -1.1344640137963142;
    VisionModel_B.HoughTransform2_o2[26] = -1.1170107212763709;
    VisionModel_B.HoughTransform2_o2[27] = -1.0995574287564276;
    VisionModel_B.HoughTransform2_o2[28] = -1.0821041362364843;
    VisionModel_B.HoughTransform2_o2[29] = -1.064650843716541;
    VisionModel_B.HoughTransform2_o2[30] = -1.0471975511965976;
    VisionModel_B.HoughTransform2_o2[31] = -1.0297442586766545;
    VisionModel_B.HoughTransform2_o2[32] = -1.0122909661567112;
    VisionModel_B.HoughTransform2_o2[33] = -0.99483767363676789;
    VisionModel_B.HoughTransform2_o2[34] = -0.97738438111682457;
    VisionModel_B.HoughTransform2_o2[35] = -0.95993108859688125;
    VisionModel_B.HoughTransform2_o2[36] = -0.94247779607693793;
    VisionModel_B.HoughTransform2_o2[37] = -0.92502450355699462;
    VisionModel_B.HoughTransform2_o2[38] = -0.90757121103705141;
    VisionModel_B.HoughTransform2_o2[39] = -0.89011791851710809;
    VisionModel_B.HoughTransform2_o2[40] = -0.87266462599716477;
    VisionModel_B.HoughTransform2_o2[41] = -0.85521133347722145;
    VisionModel_B.HoughTransform2_o2[42] = -0.83775804095727824;
    VisionModel_B.HoughTransform2_o2[43] = -0.82030474843733492;
    VisionModel_B.HoughTransform2_o2[44] = -0.8028514559173916;
    VisionModel_B.HoughTransform2_o2[45] = -0.78539816339744828;
    VisionModel_B.HoughTransform2_o2[46] = -0.767944870877505;
    VisionModel_B.HoughTransform2_o2[47] = -0.75049157835756175;
    VisionModel_B.HoughTransform2_o2[48] = -0.73303828583761843;
    VisionModel_B.HoughTransform2_o2[49] = -0.71558499331767511;
    VisionModel_B.HoughTransform2_o2[50] = -0.69813170079773179;
    VisionModel_B.HoughTransform2_o2[51] = -0.68067840827778847;
    VisionModel_B.HoughTransform2_o2[52] = -0.66322511575784526;
    VisionModel_B.HoughTransform2_o2[53] = -0.64577182323790194;
    VisionModel_B.HoughTransform2_o2[54] = -0.62831853071795862;
    VisionModel_B.HoughTransform2_o2[55] = -0.6108652381980153;
    VisionModel_B.HoughTransform2_o2[56] = -0.59341194567807209;
    VisionModel_B.HoughTransform2_o2[57] = -0.57595865315812877;
    VisionModel_B.HoughTransform2_o2[58] = -0.55850536063818546;
    VisionModel_B.HoughTransform2_o2[59] = -0.54105206811824214;
    VisionModel_B.HoughTransform2_o2[60] = -0.52359877559829882;
    VisionModel_B.HoughTransform2_o2[61] = -0.50614548307835561;
    VisionModel_B.HoughTransform2_o2[62] = -0.48869219055841229;
    VisionModel_B.HoughTransform2_o2[63] = -0.47123889803846897;
    VisionModel_B.HoughTransform2_o2[64] = -0.4537856055185257;
    VisionModel_B.HoughTransform2_o2[65] = -0.43633231299858238;
    VisionModel_B.HoughTransform2_o2[66] = -0.41887902047863912;
    VisionModel_B.HoughTransform2_o2[67] = -0.4014257279586958;
    VisionModel_B.HoughTransform2_o2[68] = -0.38397243543875248;
    VisionModel_B.HoughTransform2_o2[69] = -0.36651914291880922;
    VisionModel_B.HoughTransform2_o2[70] = -0.3490658503988659;
    VisionModel_B.HoughTransform2_o2[71] = -0.33161255787892263;
    VisionModel_B.HoughTransform2_o2[72] = -0.31415926535897931;
    VisionModel_B.HoughTransform2_o2[73] = -0.29670597283903605;
    VisionModel_B.HoughTransform2_o2[74] = -0.27925268031909273;
    VisionModel_B.HoughTransform2_o2[75] = -0.26179938779914941;
    VisionModel_B.HoughTransform2_o2[76] = -0.24434609527920614;
    VisionModel_B.HoughTransform2_o2[77] = -0.22689280275926285;
    VisionModel_B.HoughTransform2_o2[78] = -0.20943951023931956;
    VisionModel_B.HoughTransform2_o2[79] = -0.19198621771937624;
    VisionModel_B.HoughTransform2_o2[80] = -0.17453292519943295;
    VisionModel_B.HoughTransform2_o2[81] = -0.15707963267948966;
    VisionModel_B.HoughTransform2_o2[82] = -0.13962634015954636;
    VisionModel_B.HoughTransform2_o2[83] = -0.12217304763960307;
    VisionModel_B.HoughTransform2_o2[84] = -0.10471975511965978;
    VisionModel_B.HoughTransform2_o2[85] = -0.087266462599716474;
    VisionModel_B.HoughTransform2_o2[86] = -0.069813170079773182;
    VisionModel_B.HoughTransform2_o2[87] = -0.05235987755982989;
    VisionModel_B.HoughTransform2_o2[88] = -0.034906585039886591;
    VisionModel_B.HoughTransform2_o2[89] = -0.017453292519943295;
    VisionModel_B.HoughTransform2_o2[90] = 0.0;
    VisionModel_B.HoughTransform2_o2[91] = 0.017453292519943295;
    VisionModel_B.HoughTransform2_o2[92] = 0.034906585039886591;
    VisionModel_B.HoughTransform2_o2[93] = 0.05235987755982989;
    VisionModel_B.HoughTransform2_o2[94] = 0.069813170079773182;
    VisionModel_B.HoughTransform2_o2[95] = 0.087266462599716474;
    VisionModel_B.HoughTransform2_o2[96] = 0.10471975511965978;
    VisionModel_B.HoughTransform2_o2[97] = 0.12217304763960307;
    VisionModel_B.HoughTransform2_o2[98] = 0.13962634015954636;
    VisionModel_B.HoughTransform2_o2[99] = 0.15707963267948966;
    VisionModel_B.HoughTransform2_o2[100] = 0.17453292519943295;
    VisionModel_B.HoughTransform2_o2[101] = 0.19198621771937624;
    VisionModel_B.HoughTransform2_o2[102] = 0.20943951023931956;
    VisionModel_B.HoughTransform2_o2[103] = 0.22689280275926285;
    VisionModel_B.HoughTransform2_o2[104] = 0.24434609527920614;
    VisionModel_B.HoughTransform2_o2[105] = 0.26179938779914941;
    VisionModel_B.HoughTransform2_o2[106] = 0.27925268031909273;
    VisionModel_B.HoughTransform2_o2[107] = 0.29670597283903605;
    VisionModel_B.HoughTransform2_o2[108] = 0.31415926535897931;
    VisionModel_B.HoughTransform2_o2[109] = 0.33161255787892263;
    VisionModel_B.HoughTransform2_o2[110] = 0.3490658503988659;
    VisionModel_B.HoughTransform2_o2[111] = 0.36651914291880922;
    VisionModel_B.HoughTransform2_o2[112] = 0.38397243543875248;
    VisionModel_B.HoughTransform2_o2[113] = 0.4014257279586958;
    VisionModel_B.HoughTransform2_o2[114] = 0.41887902047863912;
    VisionModel_B.HoughTransform2_o2[115] = 0.43633231299858238;
    VisionModel_B.HoughTransform2_o2[116] = 0.4537856055185257;
    VisionModel_B.HoughTransform2_o2[117] = 0.47123889803846897;
    VisionModel_B.HoughTransform2_o2[118] = 0.48869219055841229;
    VisionModel_B.HoughTransform2_o2[119] = 0.50614548307835561;
    VisionModel_B.HoughTransform2_o2[120] = 0.52359877559829882;
    VisionModel_B.HoughTransform2_o2[121] = 0.54105206811824214;
    VisionModel_B.HoughTransform2_o2[122] = 0.55850536063818546;
    VisionModel_B.HoughTransform2_o2[123] = 0.57595865315812877;
    VisionModel_B.HoughTransform2_o2[124] = 0.59341194567807209;
    VisionModel_B.HoughTransform2_o2[125] = 0.6108652381980153;
    VisionModel_B.HoughTransform2_o2[126] = 0.62831853071795862;
    VisionModel_B.HoughTransform2_o2[127] = 0.64577182323790194;
    VisionModel_B.HoughTransform2_o2[128] = 0.66322511575784526;
    VisionModel_B.HoughTransform2_o2[129] = 0.68067840827778847;
    VisionModel_B.HoughTransform2_o2[130] = 0.69813170079773179;
    VisionModel_B.HoughTransform2_o2[131] = 0.71558499331767511;
    VisionModel_B.HoughTransform2_o2[132] = 0.73303828583761843;
    VisionModel_B.HoughTransform2_o2[133] = 0.75049157835756175;
    VisionModel_B.HoughTransform2_o2[134] = 0.767944870877505;
    VisionModel_B.HoughTransform2_o2[135] = 0.78539816339744828;
    VisionModel_B.HoughTransform2_o2[136] = 0.8028514559173916;
    VisionModel_B.HoughTransform2_o2[137] = 0.82030474843733492;
    VisionModel_B.HoughTransform2_o2[138] = 0.83775804095727824;
    VisionModel_B.HoughTransform2_o2[139] = 0.85521133347722145;
    VisionModel_B.HoughTransform2_o2[140] = 0.87266462599716477;
    VisionModel_B.HoughTransform2_o2[141] = 0.89011791851710809;
    VisionModel_B.HoughTransform2_o2[142] = 0.90757121103705141;
    VisionModel_B.HoughTransform2_o2[143] = 0.92502450355699462;
    VisionModel_B.HoughTransform2_o2[144] = 0.94247779607693793;
    VisionModel_B.HoughTransform2_o2[145] = 0.95993108859688125;
    VisionModel_B.HoughTransform2_o2[146] = 0.97738438111682457;
    VisionModel_B.HoughTransform2_o2[147] = 0.99483767363676789;
    VisionModel_B.HoughTransform2_o2[148] = 1.0122909661567112;
    VisionModel_B.HoughTransform2_o2[149] = 1.0297442586766545;
    VisionModel_B.HoughTransform2_o2[150] = 1.0471975511965976;
    VisionModel_B.HoughTransform2_o2[151] = 1.064650843716541;
    VisionModel_B.HoughTransform2_o2[152] = 1.0821041362364843;
    VisionModel_B.HoughTransform2_o2[153] = 1.0995574287564276;
    VisionModel_B.HoughTransform2_o2[154] = 1.1170107212763709;
    VisionModel_B.HoughTransform2_o2[155] = 1.1344640137963142;
    VisionModel_B.HoughTransform2_o2[156] = 1.1519173063162575;
    VisionModel_B.HoughTransform2_o2[157] = 1.1693705988362009;
    VisionModel_B.HoughTransform2_o2[158] = 1.1868238913561442;
    VisionModel_B.HoughTransform2_o2[159] = 1.2042771838760873;
    VisionModel_B.HoughTransform2_o2[160] = 1.2217304763960306;
    VisionModel_B.HoughTransform2_o2[161] = 1.2391837689159739;
    VisionModel_B.HoughTransform2_o2[162] = 1.2566370614359172;
    VisionModel_B.HoughTransform2_o2[163] = 1.2740903539558606;
    VisionModel_B.HoughTransform2_o2[164] = 1.2915436464758039;
    VisionModel_B.HoughTransform2_o2[165] = 1.3089969389957472;
    VisionModel_B.HoughTransform2_o2[166] = 1.3264502315156905;
    VisionModel_B.HoughTransform2_o2[167] = 1.3439035240356338;
    VisionModel_B.HoughTransform2_o2[168] = 1.3613568165555769;
    VisionModel_B.HoughTransform2_o2[169] = 1.3788101090755203;
    VisionModel_B.HoughTransform2_o2[170] = 1.3962634015954636;
    VisionModel_B.HoughTransform2_o2[171] = 1.4137166941154069;
    VisionModel_B.HoughTransform2_o2[172] = 1.4311699866353502;
    VisionModel_B.HoughTransform2_o2[173] = 1.4486232791552935;
    VisionModel_B.HoughTransform2_o2[174] = 1.4660765716752369;
    VisionModel_B.HoughTransform2_o2[175] = 1.4835298641951802;
    VisionModel_B.HoughTransform2_o2[176] = 1.5009831567151235;
    VisionModel_B.HoughTransform2_o2[177] = 1.5184364492350666;
    VisionModel_B.HoughTransform2_o2[178] = 1.53588974175501;
    VisionModel_B.HoughTransform2_o2[179] = 1.5533430342749532;
    VisionModel_B.HoughTransform2_o3[0] = -199.0;
    VisionModel_B.HoughTransform2_o3[1] = -198.0;
    VisionModel_B.HoughTransform2_o3[2] = -197.0;
    VisionModel_B.HoughTransform2_o3[3] = -196.0;
    VisionModel_B.HoughTransform2_o3[4] = -195.0;
    VisionModel_B.HoughTransform2_o3[5] = -194.0;
    VisionModel_B.HoughTransform2_o3[6] = -193.0;
    VisionModel_B.HoughTransform2_o3[7] = -192.0;
    VisionModel_B.HoughTransform2_o3[8] = -191.0;
    VisionModel_B.HoughTransform2_o3[9] = -190.0;
    VisionModel_B.HoughTransform2_o3[10] = -189.0;
    VisionModel_B.HoughTransform2_o3[11] = -188.0;
    VisionModel_B.HoughTransform2_o3[12] = -187.0;
    VisionModel_B.HoughTransform2_o3[13] = -186.0;
    VisionModel_B.HoughTransform2_o3[14] = -185.0;
    VisionModel_B.HoughTransform2_o3[15] = -184.0;
    VisionModel_B.HoughTransform2_o3[16] = -183.0;
    VisionModel_B.HoughTransform2_o3[17] = -182.0;
    VisionModel_B.HoughTransform2_o3[18] = -181.0;
    VisionModel_B.HoughTransform2_o3[19] = -180.0;
    VisionModel_B.HoughTransform2_o3[20] = -179.0;
    VisionModel_B.HoughTransform2_o3[21] = -178.0;
    VisionModel_B.HoughTransform2_o3[22] = -177.0;
    VisionModel_B.HoughTransform2_o3[23] = -176.0;
    VisionModel_B.HoughTransform2_o3[24] = -175.0;
    VisionModel_B.HoughTransform2_o3[25] = -174.0;
    VisionModel_B.HoughTransform2_o3[26] = -173.0;
    VisionModel_B.HoughTransform2_o3[27] = -172.0;
    VisionModel_B.HoughTransform2_o3[28] = -171.0;
    VisionModel_B.HoughTransform2_o3[29] = -170.0;
    VisionModel_B.HoughTransform2_o3[30] = -169.0;
    VisionModel_B.HoughTransform2_o3[31] = -168.0;
    VisionModel_B.HoughTransform2_o3[32] = -167.0;
    VisionModel_B.HoughTransform2_o3[33] = -166.0;
    VisionModel_B.HoughTransform2_o3[34] = -165.0;
    VisionModel_B.HoughTransform2_o3[35] = -164.0;
    VisionModel_B.HoughTransform2_o3[36] = -163.0;
    VisionModel_B.HoughTransform2_o3[37] = -162.0;
    VisionModel_B.HoughTransform2_o3[38] = -161.0;
    VisionModel_B.HoughTransform2_o3[39] = -160.0;
    VisionModel_B.HoughTransform2_o3[40] = -159.0;
    VisionModel_B.HoughTransform2_o3[41] = -158.0;
    VisionModel_B.HoughTransform2_o3[42] = -157.0;
    VisionModel_B.HoughTransform2_o3[43] = -156.0;
    VisionModel_B.HoughTransform2_o3[44] = -155.0;
    VisionModel_B.HoughTransform2_o3[45] = -154.0;
    VisionModel_B.HoughTransform2_o3[46] = -153.0;
    VisionModel_B.HoughTransform2_o3[47] = -152.0;
    VisionModel_B.HoughTransform2_o3[48] = -151.0;
    VisionModel_B.HoughTransform2_o3[49] = -150.0;
    VisionModel_B.HoughTransform2_o3[50] = -149.0;
    VisionModel_B.HoughTransform2_o3[51] = -148.0;
    VisionModel_B.HoughTransform2_o3[52] = -147.0;
    VisionModel_B.HoughTransform2_o3[53] = -146.0;
    VisionModel_B.HoughTransform2_o3[54] = -145.0;
    VisionModel_B.HoughTransform2_o3[55] = -144.0;
    VisionModel_B.HoughTransform2_o3[56] = -143.0;
    VisionModel_B.HoughTransform2_o3[57] = -142.0;
    VisionModel_B.HoughTransform2_o3[58] = -141.0;
    VisionModel_B.HoughTransform2_o3[59] = -140.0;
    VisionModel_B.HoughTransform2_o3[60] = -139.0;
    VisionModel_B.HoughTransform2_o3[61] = -138.0;
    VisionModel_B.HoughTransform2_o3[62] = -137.0;
    VisionModel_B.HoughTransform2_o3[63] = -136.0;
    VisionModel_B.HoughTransform2_o3[64] = -135.0;
    VisionModel_B.HoughTransform2_o3[65] = -134.0;
    VisionModel_B.HoughTransform2_o3[66] = -133.0;
    VisionModel_B.HoughTransform2_o3[67] = -132.0;
    VisionModel_B.HoughTransform2_o3[68] = -131.0;
    VisionModel_B.HoughTransform2_o3[69] = -130.0;
    VisionModel_B.HoughTransform2_o3[70] = -129.0;
    VisionModel_B.HoughTransform2_o3[71] = -128.0;
    VisionModel_B.HoughTransform2_o3[72] = -127.0;
    VisionModel_B.HoughTransform2_o3[73] = -126.0;
    VisionModel_B.HoughTransform2_o3[74] = -125.0;
    VisionModel_B.HoughTransform2_o3[75] = -124.0;
    VisionModel_B.HoughTransform2_o3[76] = -123.0;
    VisionModel_B.HoughTransform2_o3[77] = -122.0;
    VisionModel_B.HoughTransform2_o3[78] = -121.0;
    VisionModel_B.HoughTransform2_o3[79] = -120.0;
    VisionModel_B.HoughTransform2_o3[80] = -119.0;
    VisionModel_B.HoughTransform2_o3[81] = -118.0;
    VisionModel_B.HoughTransform2_o3[82] = -117.0;
    VisionModel_B.HoughTransform2_o3[83] = -116.0;
    VisionModel_B.HoughTransform2_o3[84] = -115.0;
    VisionModel_B.HoughTransform2_o3[85] = -114.0;
    VisionModel_B.HoughTransform2_o3[86] = -113.0;
    VisionModel_B.HoughTransform2_o3[87] = -112.0;
    VisionModel_B.HoughTransform2_o3[88] = -111.0;
    VisionModel_B.HoughTransform2_o3[89] = -110.0;
    VisionModel_B.HoughTransform2_o3[90] = -109.0;
    VisionModel_B.HoughTransform2_o3[91] = -108.0;
    VisionModel_B.HoughTransform2_o3[92] = -107.0;
    VisionModel_B.HoughTransform2_o3[93] = -106.0;
    VisionModel_B.HoughTransform2_o3[94] = -105.0;
    VisionModel_B.HoughTransform2_o3[95] = -104.0;
    VisionModel_B.HoughTransform2_o3[96] = -103.0;
    VisionModel_B.HoughTransform2_o3[97] = -102.0;
    VisionModel_B.HoughTransform2_o3[98] = -101.0;
    VisionModel_B.HoughTransform2_o3[99] = -100.0;
    VisionModel_B.HoughTransform2_o3[100] = -99.0;
    VisionModel_B.HoughTransform2_o3[101] = -98.0;
    VisionModel_B.HoughTransform2_o3[102] = -97.0;
    VisionModel_B.HoughTransform2_o3[103] = -96.0;
    VisionModel_B.HoughTransform2_o3[104] = -95.0;
    VisionModel_B.HoughTransform2_o3[105] = -94.0;
    VisionModel_B.HoughTransform2_o3[106] = -93.0;
    VisionModel_B.HoughTransform2_o3[107] = -92.0;
    VisionModel_B.HoughTransform2_o3[108] = -91.0;
    VisionModel_B.HoughTransform2_o3[109] = -90.0;
    VisionModel_B.HoughTransform2_o3[110] = -89.0;
    VisionModel_B.HoughTransform2_o3[111] = -88.0;
    VisionModel_B.HoughTransform2_o3[112] = -87.0;
    VisionModel_B.HoughTransform2_o3[113] = -86.0;
    VisionModel_B.HoughTransform2_o3[114] = -85.0;
    VisionModel_B.HoughTransform2_o3[115] = -84.0;
    VisionModel_B.HoughTransform2_o3[116] = -83.0;
    VisionModel_B.HoughTransform2_o3[117] = -82.0;
    VisionModel_B.HoughTransform2_o3[118] = -81.0;
    VisionModel_B.HoughTransform2_o3[119] = -80.0;
    VisionModel_B.HoughTransform2_o3[120] = -79.0;
    VisionModel_B.HoughTransform2_o3[121] = -78.0;
    VisionModel_B.HoughTransform2_o3[122] = -77.0;
    VisionModel_B.HoughTransform2_o3[123] = -76.0;
    VisionModel_B.HoughTransform2_o3[124] = -75.0;
    VisionModel_B.HoughTransform2_o3[125] = -74.0;
    VisionModel_B.HoughTransform2_o3[126] = -73.0;
    VisionModel_B.HoughTransform2_o3[127] = -72.0;
    VisionModel_B.HoughTransform2_o3[128] = -71.0;
    VisionModel_B.HoughTransform2_o3[129] = -70.0;
    VisionModel_B.HoughTransform2_o3[130] = -69.0;
    VisionModel_B.HoughTransform2_o3[131] = -68.0;
    VisionModel_B.HoughTransform2_o3[132] = -67.0;
    VisionModel_B.HoughTransform2_o3[133] = -66.0;
    VisionModel_B.HoughTransform2_o3[134] = -65.0;
    VisionModel_B.HoughTransform2_o3[135] = -64.0;
    VisionModel_B.HoughTransform2_o3[136] = -63.0;
    VisionModel_B.HoughTransform2_o3[137] = -62.0;
    VisionModel_B.HoughTransform2_o3[138] = -61.0;
    VisionModel_B.HoughTransform2_o3[139] = -60.0;
    VisionModel_B.HoughTransform2_o3[140] = -59.0;
    VisionModel_B.HoughTransform2_o3[141] = -58.0;
    VisionModel_B.HoughTransform2_o3[142] = -57.0;
    VisionModel_B.HoughTransform2_o3[143] = -56.0;
    VisionModel_B.HoughTransform2_o3[144] = -55.0;
    VisionModel_B.HoughTransform2_o3[145] = -54.0;
    VisionModel_B.HoughTransform2_o3[146] = -53.0;
    VisionModel_B.HoughTransform2_o3[147] = -52.0;
    VisionModel_B.HoughTransform2_o3[148] = -51.0;
    VisionModel_B.HoughTransform2_o3[149] = -50.0;
    VisionModel_B.HoughTransform2_o3[150] = -49.0;
    VisionModel_B.HoughTransform2_o3[151] = -48.0;
    VisionModel_B.HoughTransform2_o3[152] = -47.0;
    VisionModel_B.HoughTransform2_o3[153] = -46.0;
    VisionModel_B.HoughTransform2_o3[154] = -45.0;
    VisionModel_B.HoughTransform2_o3[155] = -44.0;
    VisionModel_B.HoughTransform2_o3[156] = -43.0;
    VisionModel_B.HoughTransform2_o3[157] = -42.0;
    VisionModel_B.HoughTransform2_o3[158] = -41.0;
    VisionModel_B.HoughTransform2_o3[159] = -40.0;
    VisionModel_B.HoughTransform2_o3[160] = -39.0;
    VisionModel_B.HoughTransform2_o3[161] = -38.0;
    VisionModel_B.HoughTransform2_o3[162] = -37.0;
    VisionModel_B.HoughTransform2_o3[163] = -36.0;
    VisionModel_B.HoughTransform2_o3[164] = -35.0;
    VisionModel_B.HoughTransform2_o3[165] = -34.0;
    VisionModel_B.HoughTransform2_o3[166] = -33.0;
    VisionModel_B.HoughTransform2_o3[167] = -32.0;
    VisionModel_B.HoughTransform2_o3[168] = -31.0;
    VisionModel_B.HoughTransform2_o3[169] = -30.0;
    VisionModel_B.HoughTransform2_o3[170] = -29.0;
    VisionModel_B.HoughTransform2_o3[171] = -28.0;
    VisionModel_B.HoughTransform2_o3[172] = -27.0;
    VisionModel_B.HoughTransform2_o3[173] = -26.0;
    VisionModel_B.HoughTransform2_o3[174] = -25.0;
    VisionModel_B.HoughTransform2_o3[175] = -24.0;
    VisionModel_B.HoughTransform2_o3[176] = -23.0;
    VisionModel_B.HoughTransform2_o3[177] = -22.0;
    VisionModel_B.HoughTransform2_o3[178] = -21.0;
    VisionModel_B.HoughTransform2_o3[179] = -20.0;
    VisionModel_B.HoughTransform2_o3[180] = -19.0;
    VisionModel_B.HoughTransform2_o3[181] = -18.0;
    VisionModel_B.HoughTransform2_o3[182] = -17.0;
    VisionModel_B.HoughTransform2_o3[183] = -16.0;
    VisionModel_B.HoughTransform2_o3[184] = -15.0;
    VisionModel_B.HoughTransform2_o3[185] = -14.0;
    VisionModel_B.HoughTransform2_o3[186] = -13.0;
    VisionModel_B.HoughTransform2_o3[187] = -12.0;
    VisionModel_B.HoughTransform2_o3[188] = -11.0;
    VisionModel_B.HoughTransform2_o3[189] = -10.0;
    VisionModel_B.HoughTransform2_o3[190] = -9.0;
    VisionModel_B.HoughTransform2_o3[191] = -8.0;
    VisionModel_B.HoughTransform2_o3[192] = -7.0;
    VisionModel_B.HoughTransform2_o3[193] = -6.0;
    VisionModel_B.HoughTransform2_o3[194] = -5.0;
    VisionModel_B.HoughTransform2_o3[195] = -4.0;
    VisionModel_B.HoughTransform2_o3[196] = -3.0;
    VisionModel_B.HoughTransform2_o3[197] = -2.0;
    VisionModel_B.HoughTransform2_o3[198] = -1.0;
    VisionModel_B.HoughTransform2_o3[199] = 0.0;
    VisionModel_B.HoughTransform2_o3[200] = 1.0;
    VisionModel_B.HoughTransform2_o3[201] = 2.0;
    VisionModel_B.HoughTransform2_o3[202] = 3.0;
    VisionModel_B.HoughTransform2_o3[203] = 4.0;
    VisionModel_B.HoughTransform2_o3[204] = 5.0;
    VisionModel_B.HoughTransform2_o3[205] = 6.0;
    VisionModel_B.HoughTransform2_o3[206] = 7.0;
    VisionModel_B.HoughTransform2_o3[207] = 8.0;
    VisionModel_B.HoughTransform2_o3[208] = 9.0;
    VisionModel_B.HoughTransform2_o3[209] = 10.0;
    VisionModel_B.HoughTransform2_o3[210] = 11.0;
    VisionModel_B.HoughTransform2_o3[211] = 12.0;
    VisionModel_B.HoughTransform2_o3[212] = 13.0;
    VisionModel_B.HoughTransform2_o3[213] = 14.0;
    VisionModel_B.HoughTransform2_o3[214] = 15.0;
    VisionModel_B.HoughTransform2_o3[215] = 16.0;
    VisionModel_B.HoughTransform2_o3[216] = 17.0;
    VisionModel_B.HoughTransform2_o3[217] = 18.0;
    VisionModel_B.HoughTransform2_o3[218] = 19.0;
    VisionModel_B.HoughTransform2_o3[219] = 20.0;
    VisionModel_B.HoughTransform2_o3[220] = 21.0;
    VisionModel_B.HoughTransform2_o3[221] = 22.0;
    VisionModel_B.HoughTransform2_o3[222] = 23.0;
    VisionModel_B.HoughTransform2_o3[223] = 24.0;
    VisionModel_B.HoughTransform2_o3[224] = 25.0;
    VisionModel_B.HoughTransform2_o3[225] = 26.0;
    VisionModel_B.HoughTransform2_o3[226] = 27.0;
    VisionModel_B.HoughTransform2_o3[227] = 28.0;
    VisionModel_B.HoughTransform2_o3[228] = 29.0;
    VisionModel_B.HoughTransform2_o3[229] = 30.0;
    VisionModel_B.HoughTransform2_o3[230] = 31.0;
    VisionModel_B.HoughTransform2_o3[231] = 32.0;
    VisionModel_B.HoughTransform2_o3[232] = 33.0;
    VisionModel_B.HoughTransform2_o3[233] = 34.0;
    VisionModel_B.HoughTransform2_o3[234] = 35.0;
    VisionModel_B.HoughTransform2_o3[235] = 36.0;
    VisionModel_B.HoughTransform2_o3[236] = 37.0;
    VisionModel_B.HoughTransform2_o3[237] = 38.0;
    VisionModel_B.HoughTransform2_o3[238] = 39.0;
    VisionModel_B.HoughTransform2_o3[239] = 40.0;
    VisionModel_B.HoughTransform2_o3[240] = 41.0;
    VisionModel_B.HoughTransform2_o3[241] = 42.0;
    VisionModel_B.HoughTransform2_o3[242] = 43.0;
    VisionModel_B.HoughTransform2_o3[243] = 44.0;
    VisionModel_B.HoughTransform2_o3[244] = 45.0;
    VisionModel_B.HoughTransform2_o3[245] = 46.0;
    VisionModel_B.HoughTransform2_o3[246] = 47.0;
    VisionModel_B.HoughTransform2_o3[247] = 48.0;
    VisionModel_B.HoughTransform2_o3[248] = 49.0;
    VisionModel_B.HoughTransform2_o3[249] = 50.0;
    VisionModel_B.HoughTransform2_o3[250] = 51.0;
    VisionModel_B.HoughTransform2_o3[251] = 52.0;
    VisionModel_B.HoughTransform2_o3[252] = 53.0;
    VisionModel_B.HoughTransform2_o3[253] = 54.0;
    VisionModel_B.HoughTransform2_o3[254] = 55.0;
    VisionModel_B.HoughTransform2_o3[255] = 56.0;
    VisionModel_B.HoughTransform2_o3[256] = 57.0;
    VisionModel_B.HoughTransform2_o3[257] = 58.0;
    VisionModel_B.HoughTransform2_o3[258] = 59.0;
    VisionModel_B.HoughTransform2_o3[259] = 60.0;
    VisionModel_B.HoughTransform2_o3[260] = 61.0;
    VisionModel_B.HoughTransform2_o3[261] = 62.0;
    VisionModel_B.HoughTransform2_o3[262] = 63.0;
    VisionModel_B.HoughTransform2_o3[263] = 64.0;
    VisionModel_B.HoughTransform2_o3[264] = 65.0;
    VisionModel_B.HoughTransform2_o3[265] = 66.0;
    VisionModel_B.HoughTransform2_o3[266] = 67.0;
    VisionModel_B.HoughTransform2_o3[267] = 68.0;
    VisionModel_B.HoughTransform2_o3[268] = 69.0;
    VisionModel_B.HoughTransform2_o3[269] = 70.0;
    VisionModel_B.HoughTransform2_o3[270] = 71.0;
    VisionModel_B.HoughTransform2_o3[271] = 72.0;
    VisionModel_B.HoughTransform2_o3[272] = 73.0;
    VisionModel_B.HoughTransform2_o3[273] = 74.0;
    VisionModel_B.HoughTransform2_o3[274] = 75.0;
    VisionModel_B.HoughTransform2_o3[275] = 76.0;
    VisionModel_B.HoughTransform2_o3[276] = 77.0;
    VisionModel_B.HoughTransform2_o3[277] = 78.0;
    VisionModel_B.HoughTransform2_o3[278] = 79.0;
    VisionModel_B.HoughTransform2_o3[279] = 80.0;
    VisionModel_B.HoughTransform2_o3[280] = 81.0;
    VisionModel_B.HoughTransform2_o3[281] = 82.0;
    VisionModel_B.HoughTransform2_o3[282] = 83.0;
    VisionModel_B.HoughTransform2_o3[283] = 84.0;
    VisionModel_B.HoughTransform2_o3[284] = 85.0;
    VisionModel_B.HoughTransform2_o3[285] = 86.0;
    VisionModel_B.HoughTransform2_o3[286] = 87.0;
    VisionModel_B.HoughTransform2_o3[287] = 88.0;
    VisionModel_B.HoughTransform2_o3[288] = 89.0;
    VisionModel_B.HoughTransform2_o3[289] = 90.0;
    VisionModel_B.HoughTransform2_o3[290] = 91.0;
    VisionModel_B.HoughTransform2_o3[291] = 92.0;
    VisionModel_B.HoughTransform2_o3[292] = 93.0;
    VisionModel_B.HoughTransform2_o3[293] = 94.0;
    VisionModel_B.HoughTransform2_o3[294] = 95.0;
    VisionModel_B.HoughTransform2_o3[295] = 96.0;
    VisionModel_B.HoughTransform2_o3[296] = 97.0;
    VisionModel_B.HoughTransform2_o3[297] = 98.0;
    VisionModel_B.HoughTransform2_o3[298] = 99.0;
    VisionModel_B.HoughTransform2_o3[299] = 100.0;
    VisionModel_B.HoughTransform2_o3[300] = 101.0;
    VisionModel_B.HoughTransform2_o3[301] = 102.0;
    VisionModel_B.HoughTransform2_o3[302] = 103.0;
    VisionModel_B.HoughTransform2_o3[303] = 104.0;
    VisionModel_B.HoughTransform2_o3[304] = 105.0;
    VisionModel_B.HoughTransform2_o3[305] = 106.0;
    VisionModel_B.HoughTransform2_o3[306] = 107.0;
    VisionModel_B.HoughTransform2_o3[307] = 108.0;
    VisionModel_B.HoughTransform2_o3[308] = 109.0;
    VisionModel_B.HoughTransform2_o3[309] = 110.0;
    VisionModel_B.HoughTransform2_o3[310] = 111.0;
    VisionModel_B.HoughTransform2_o3[311] = 112.0;
    VisionModel_B.HoughTransform2_o3[312] = 113.0;
    VisionModel_B.HoughTransform2_o3[313] = 114.0;
    VisionModel_B.HoughTransform2_o3[314] = 115.0;
    VisionModel_B.HoughTransform2_o3[315] = 116.0;
    VisionModel_B.HoughTransform2_o3[316] = 117.0;
    VisionModel_B.HoughTransform2_o3[317] = 118.0;
    VisionModel_B.HoughTransform2_o3[318] = 119.0;
    VisionModel_B.HoughTransform2_o3[319] = 120.0;
    VisionModel_B.HoughTransform2_o3[320] = 121.0;
    VisionModel_B.HoughTransform2_o3[321] = 122.0;
    VisionModel_B.HoughTransform2_o3[322] = 123.0;
    VisionModel_B.HoughTransform2_o3[323] = 124.0;
    VisionModel_B.HoughTransform2_o3[324] = 125.0;
    VisionModel_B.HoughTransform2_o3[325] = 126.0;
    VisionModel_B.HoughTransform2_o3[326] = 127.0;
    VisionModel_B.HoughTransform2_o3[327] = 128.0;
    VisionModel_B.HoughTransform2_o3[328] = 129.0;
    VisionModel_B.HoughTransform2_o3[329] = 130.0;
    VisionModel_B.HoughTransform2_o3[330] = 131.0;
    VisionModel_B.HoughTransform2_o3[331] = 132.0;
    VisionModel_B.HoughTransform2_o3[332] = 133.0;
    VisionModel_B.HoughTransform2_o3[333] = 134.0;
    VisionModel_B.HoughTransform2_o3[334] = 135.0;
    VisionModel_B.HoughTransform2_o3[335] = 136.0;
    VisionModel_B.HoughTransform2_o3[336] = 137.0;
    VisionModel_B.HoughTransform2_o3[337] = 138.0;
    VisionModel_B.HoughTransform2_o3[338] = 139.0;
    VisionModel_B.HoughTransform2_o3[339] = 140.0;
    VisionModel_B.HoughTransform2_o3[340] = 141.0;
    VisionModel_B.HoughTransform2_o3[341] = 142.0;
    VisionModel_B.HoughTransform2_o3[342] = 143.0;
    VisionModel_B.HoughTransform2_o3[343] = 144.0;
    VisionModel_B.HoughTransform2_o3[344] = 145.0;
    VisionModel_B.HoughTransform2_o3[345] = 146.0;
    VisionModel_B.HoughTransform2_o3[346] = 147.0;
    VisionModel_B.HoughTransform2_o3[347] = 148.0;
    VisionModel_B.HoughTransform2_o3[348] = 149.0;
    VisionModel_B.HoughTransform2_o3[349] = 150.0;
    VisionModel_B.HoughTransform2_o3[350] = 151.0;
    VisionModel_B.HoughTransform2_o3[351] = 152.0;
    VisionModel_B.HoughTransform2_o3[352] = 153.0;
    VisionModel_B.HoughTransform2_o3[353] = 154.0;
    VisionModel_B.HoughTransform2_o3[354] = 155.0;
    VisionModel_B.HoughTransform2_o3[355] = 156.0;
    VisionModel_B.HoughTransform2_o3[356] = 157.0;
    VisionModel_B.HoughTransform2_o3[357] = 158.0;
    VisionModel_B.HoughTransform2_o3[358] = 159.0;
    VisionModel_B.HoughTransform2_o3[359] = 160.0;
    VisionModel_B.HoughTransform2_o3[360] = 161.0;
    VisionModel_B.HoughTransform2_o3[361] = 162.0;
    VisionModel_B.HoughTransform2_o3[362] = 163.0;
    VisionModel_B.HoughTransform2_o3[363] = 164.0;
    VisionModel_B.HoughTransform2_o3[364] = 165.0;
    VisionModel_B.HoughTransform2_o3[365] = 166.0;
    VisionModel_B.HoughTransform2_o3[366] = 167.0;
    VisionModel_B.HoughTransform2_o3[367] = 168.0;
    VisionModel_B.HoughTransform2_o3[368] = 169.0;
    VisionModel_B.HoughTransform2_o3[369] = 170.0;
    VisionModel_B.HoughTransform2_o3[370] = 171.0;
    VisionModel_B.HoughTransform2_o3[371] = 172.0;
    VisionModel_B.HoughTransform2_o3[372] = 173.0;
    VisionModel_B.HoughTransform2_o3[373] = 174.0;
    VisionModel_B.HoughTransform2_o3[374] = 175.0;
    VisionModel_B.HoughTransform2_o3[375] = 176.0;
    VisionModel_B.HoughTransform2_o3[376] = 177.0;
    VisionModel_B.HoughTransform2_o3[377] = 178.0;
    VisionModel_B.HoughTransform2_o3[378] = 179.0;
    VisionModel_B.HoughTransform2_o3[379] = 180.0;
    VisionModel_B.HoughTransform2_o3[380] = 181.0;
    VisionModel_B.HoughTransform2_o3[381] = 182.0;
    VisionModel_B.HoughTransform2_o3[382] = 183.0;
    VisionModel_B.HoughTransform2_o3[383] = 184.0;
    VisionModel_B.HoughTransform2_o3[384] = 185.0;
    VisionModel_B.HoughTransform2_o3[385] = 186.0;
    VisionModel_B.HoughTransform2_o3[386] = 187.0;
    VisionModel_B.HoughTransform2_o3[387] = 188.0;
    VisionModel_B.HoughTransform2_o3[388] = 189.0;
    VisionModel_B.HoughTransform2_o3[389] = 190.0;
    VisionModel_B.HoughTransform2_o3[390] = 191.0;
    VisionModel_B.HoughTransform2_o3[391] = 192.0;
    VisionModel_B.HoughTransform2_o3[392] = 193.0;
    VisionModel_B.HoughTransform2_o3[393] = 194.0;
    VisionModel_B.HoughTransform2_o3[394] = 195.0;
    VisionModel_B.HoughTransform2_o3[395] = 196.0;
    VisionModel_B.HoughTransform2_o3[396] = 197.0;
    VisionModel_B.HoughTransform2_o3[397] = 198.0;
    VisionModel_B.HoughTransform2_o3[398] = 199.0;
    VisionModel_B.HoughTransform1_o2[0] = -1.5707963267948966;
    VisionModel_B.HoughTransform1_o2[1] = -1.5533430342749532;
    VisionModel_B.HoughTransform1_o2[2] = -1.53588974175501;
    VisionModel_B.HoughTransform1_o2[3] = -1.5184364492350666;
    VisionModel_B.HoughTransform1_o2[4] = -1.5009831567151235;
    VisionModel_B.HoughTransform1_o2[5] = -1.4835298641951802;
    VisionModel_B.HoughTransform1_o2[6] = -1.4660765716752369;
    VisionModel_B.HoughTransform1_o2[7] = -1.4486232791552935;
    VisionModel_B.HoughTransform1_o2[8] = -1.4311699866353502;
    VisionModel_B.HoughTransform1_o2[9] = -1.4137166941154069;
    VisionModel_B.HoughTransform1_o2[10] = -1.3962634015954636;
    VisionModel_B.HoughTransform1_o2[11] = -1.3788101090755203;
    VisionModel_B.HoughTransform1_o2[12] = -1.3613568165555769;
    VisionModel_B.HoughTransform1_o2[13] = -1.3439035240356338;
    VisionModel_B.HoughTransform1_o2[14] = -1.3264502315156905;
    VisionModel_B.HoughTransform1_o2[15] = -1.3089969389957472;
    VisionModel_B.HoughTransform1_o2[16] = -1.2915436464758039;
    VisionModel_B.HoughTransform1_o2[17] = -1.2740903539558606;
    VisionModel_B.HoughTransform1_o2[18] = -1.2566370614359172;
    VisionModel_B.HoughTransform1_o2[19] = -1.2391837689159739;
    VisionModel_B.HoughTransform1_o2[20] = -1.2217304763960306;
    VisionModel_B.HoughTransform1_o2[21] = -1.2042771838760873;
    VisionModel_B.HoughTransform1_o2[22] = -1.1868238913561442;
    VisionModel_B.HoughTransform1_o2[23] = -1.1693705988362009;
    VisionModel_B.HoughTransform1_o2[24] = -1.1519173063162575;
    VisionModel_B.HoughTransform1_o2[25] = -1.1344640137963142;
    VisionModel_B.HoughTransform1_o2[26] = -1.1170107212763709;
    VisionModel_B.HoughTransform1_o2[27] = -1.0995574287564276;
    VisionModel_B.HoughTransform1_o2[28] = -1.0821041362364843;
    VisionModel_B.HoughTransform1_o2[29] = -1.064650843716541;
    VisionModel_B.HoughTransform1_o2[30] = -1.0471975511965976;
    VisionModel_B.HoughTransform1_o2[31] = -1.0297442586766545;
    VisionModel_B.HoughTransform1_o2[32] = -1.0122909661567112;
    VisionModel_B.HoughTransform1_o2[33] = -0.99483767363676789;
    VisionModel_B.HoughTransform1_o2[34] = -0.97738438111682457;
    VisionModel_B.HoughTransform1_o2[35] = -0.95993108859688125;
    VisionModel_B.HoughTransform1_o2[36] = -0.94247779607693793;
    VisionModel_B.HoughTransform1_o2[37] = -0.92502450355699462;
    VisionModel_B.HoughTransform1_o2[38] = -0.90757121103705141;
    VisionModel_B.HoughTransform1_o2[39] = -0.89011791851710809;
    VisionModel_B.HoughTransform1_o2[40] = -0.87266462599716477;
    VisionModel_B.HoughTransform1_o2[41] = -0.85521133347722145;
    VisionModel_B.HoughTransform1_o2[42] = -0.83775804095727824;
    VisionModel_B.HoughTransform1_o2[43] = -0.82030474843733492;
    VisionModel_B.HoughTransform1_o2[44] = -0.8028514559173916;
    VisionModel_B.HoughTransform1_o2[45] = -0.78539816339744828;
    VisionModel_B.HoughTransform1_o2[46] = -0.767944870877505;
    VisionModel_B.HoughTransform1_o2[47] = -0.75049157835756175;
    VisionModel_B.HoughTransform1_o2[48] = -0.73303828583761843;
    VisionModel_B.HoughTransform1_o2[49] = -0.71558499331767511;
    VisionModel_B.HoughTransform1_o2[50] = -0.69813170079773179;
    VisionModel_B.HoughTransform1_o2[51] = -0.68067840827778847;
    VisionModel_B.HoughTransform1_o2[52] = -0.66322511575784526;
    VisionModel_B.HoughTransform1_o2[53] = -0.64577182323790194;
    VisionModel_B.HoughTransform1_o2[54] = -0.62831853071795862;
    VisionModel_B.HoughTransform1_o2[55] = -0.6108652381980153;
    VisionModel_B.HoughTransform1_o2[56] = -0.59341194567807209;
    VisionModel_B.HoughTransform1_o2[57] = -0.57595865315812877;
    VisionModel_B.HoughTransform1_o2[58] = -0.55850536063818546;
    VisionModel_B.HoughTransform1_o2[59] = -0.54105206811824214;
    VisionModel_B.HoughTransform1_o2[60] = -0.52359877559829882;
    VisionModel_B.HoughTransform1_o2[61] = -0.50614548307835561;
    VisionModel_B.HoughTransform1_o2[62] = -0.48869219055841229;
    VisionModel_B.HoughTransform1_o2[63] = -0.47123889803846897;
    VisionModel_B.HoughTransform1_o2[64] = -0.4537856055185257;
    VisionModel_B.HoughTransform1_o2[65] = -0.43633231299858238;
    VisionModel_B.HoughTransform1_o2[66] = -0.41887902047863912;
    VisionModel_B.HoughTransform1_o2[67] = -0.4014257279586958;
    VisionModel_B.HoughTransform1_o2[68] = -0.38397243543875248;
    VisionModel_B.HoughTransform1_o2[69] = -0.36651914291880922;
    VisionModel_B.HoughTransform1_o2[70] = -0.3490658503988659;
    VisionModel_B.HoughTransform1_o2[71] = -0.33161255787892263;
    VisionModel_B.HoughTransform1_o2[72] = -0.31415926535897931;
    VisionModel_B.HoughTransform1_o2[73] = -0.29670597283903605;
    VisionModel_B.HoughTransform1_o2[74] = -0.27925268031909273;
    VisionModel_B.HoughTransform1_o2[75] = -0.26179938779914941;
    VisionModel_B.HoughTransform1_o2[76] = -0.24434609527920614;
    VisionModel_B.HoughTransform1_o2[77] = -0.22689280275926285;
    VisionModel_B.HoughTransform1_o2[78] = -0.20943951023931956;
    VisionModel_B.HoughTransform1_o2[79] = -0.19198621771937624;
    VisionModel_B.HoughTransform1_o2[80] = -0.17453292519943295;
    VisionModel_B.HoughTransform1_o2[81] = -0.15707963267948966;
    VisionModel_B.HoughTransform1_o2[82] = -0.13962634015954636;
    VisionModel_B.HoughTransform1_o2[83] = -0.12217304763960307;
    VisionModel_B.HoughTransform1_o2[84] = -0.10471975511965978;
    VisionModel_B.HoughTransform1_o2[85] = -0.087266462599716474;
    VisionModel_B.HoughTransform1_o2[86] = -0.069813170079773182;
    VisionModel_B.HoughTransform1_o2[87] = -0.05235987755982989;
    VisionModel_B.HoughTransform1_o2[88] = -0.034906585039886591;
    VisionModel_B.HoughTransform1_o2[89] = -0.017453292519943295;
    VisionModel_B.HoughTransform1_o2[90] = 0.0;
    VisionModel_B.HoughTransform1_o2[91] = 0.017453292519943295;
    VisionModel_B.HoughTransform1_o2[92] = 0.034906585039886591;
    VisionModel_B.HoughTransform1_o2[93] = 0.05235987755982989;
    VisionModel_B.HoughTransform1_o2[94] = 0.069813170079773182;
    VisionModel_B.HoughTransform1_o2[95] = 0.087266462599716474;
    VisionModel_B.HoughTransform1_o2[96] = 0.10471975511965978;
    VisionModel_B.HoughTransform1_o2[97] = 0.12217304763960307;
    VisionModel_B.HoughTransform1_o2[98] = 0.13962634015954636;
    VisionModel_B.HoughTransform1_o2[99] = 0.15707963267948966;
    VisionModel_B.HoughTransform1_o2[100] = 0.17453292519943295;
    VisionModel_B.HoughTransform1_o2[101] = 0.19198621771937624;
    VisionModel_B.HoughTransform1_o2[102] = 0.20943951023931956;
    VisionModel_B.HoughTransform1_o2[103] = 0.22689280275926285;
    VisionModel_B.HoughTransform1_o2[104] = 0.24434609527920614;
    VisionModel_B.HoughTransform1_o2[105] = 0.26179938779914941;
    VisionModel_B.HoughTransform1_o2[106] = 0.27925268031909273;
    VisionModel_B.HoughTransform1_o2[107] = 0.29670597283903605;
    VisionModel_B.HoughTransform1_o2[108] = 0.31415926535897931;
    VisionModel_B.HoughTransform1_o2[109] = 0.33161255787892263;
    VisionModel_B.HoughTransform1_o2[110] = 0.3490658503988659;
    VisionModel_B.HoughTransform1_o2[111] = 0.36651914291880922;
    VisionModel_B.HoughTransform1_o2[112] = 0.38397243543875248;
    VisionModel_B.HoughTransform1_o2[113] = 0.4014257279586958;
    VisionModel_B.HoughTransform1_o2[114] = 0.41887902047863912;
    VisionModel_B.HoughTransform1_o2[115] = 0.43633231299858238;
    VisionModel_B.HoughTransform1_o2[116] = 0.4537856055185257;
    VisionModel_B.HoughTransform1_o2[117] = 0.47123889803846897;
    VisionModel_B.HoughTransform1_o2[118] = 0.48869219055841229;
    VisionModel_B.HoughTransform1_o2[119] = 0.50614548307835561;
    VisionModel_B.HoughTransform1_o2[120] = 0.52359877559829882;
    VisionModel_B.HoughTransform1_o2[121] = 0.54105206811824214;
    VisionModel_B.HoughTransform1_o2[122] = 0.55850536063818546;
    VisionModel_B.HoughTransform1_o2[123] = 0.57595865315812877;
    VisionModel_B.HoughTransform1_o2[124] = 0.59341194567807209;
    VisionModel_B.HoughTransform1_o2[125] = 0.6108652381980153;
    VisionModel_B.HoughTransform1_o2[126] = 0.62831853071795862;
    VisionModel_B.HoughTransform1_o2[127] = 0.64577182323790194;
    VisionModel_B.HoughTransform1_o2[128] = 0.66322511575784526;
    VisionModel_B.HoughTransform1_o2[129] = 0.68067840827778847;
    VisionModel_B.HoughTransform1_o2[130] = 0.69813170079773179;
    VisionModel_B.HoughTransform1_o2[131] = 0.71558499331767511;
    VisionModel_B.HoughTransform1_o2[132] = 0.73303828583761843;
    VisionModel_B.HoughTransform1_o2[133] = 0.75049157835756175;
    VisionModel_B.HoughTransform1_o2[134] = 0.767944870877505;
    VisionModel_B.HoughTransform1_o2[135] = 0.78539816339744828;
    VisionModel_B.HoughTransform1_o2[136] = 0.8028514559173916;
    VisionModel_B.HoughTransform1_o2[137] = 0.82030474843733492;
    VisionModel_B.HoughTransform1_o2[138] = 0.83775804095727824;
    VisionModel_B.HoughTransform1_o2[139] = 0.85521133347722145;
    VisionModel_B.HoughTransform1_o2[140] = 0.87266462599716477;
    VisionModel_B.HoughTransform1_o2[141] = 0.89011791851710809;
    VisionModel_B.HoughTransform1_o2[142] = 0.90757121103705141;
    VisionModel_B.HoughTransform1_o2[143] = 0.92502450355699462;
    VisionModel_B.HoughTransform1_o2[144] = 0.94247779607693793;
    VisionModel_B.HoughTransform1_o2[145] = 0.95993108859688125;
    VisionModel_B.HoughTransform1_o2[146] = 0.97738438111682457;
    VisionModel_B.HoughTransform1_o2[147] = 0.99483767363676789;
    VisionModel_B.HoughTransform1_o2[148] = 1.0122909661567112;
    VisionModel_B.HoughTransform1_o2[149] = 1.0297442586766545;
    VisionModel_B.HoughTransform1_o2[150] = 1.0471975511965976;
    VisionModel_B.HoughTransform1_o2[151] = 1.064650843716541;
    VisionModel_B.HoughTransform1_o2[152] = 1.0821041362364843;
    VisionModel_B.HoughTransform1_o2[153] = 1.0995574287564276;
    VisionModel_B.HoughTransform1_o2[154] = 1.1170107212763709;
    VisionModel_B.HoughTransform1_o2[155] = 1.1344640137963142;
    VisionModel_B.HoughTransform1_o2[156] = 1.1519173063162575;
    VisionModel_B.HoughTransform1_o2[157] = 1.1693705988362009;
    VisionModel_B.HoughTransform1_o2[158] = 1.1868238913561442;
    VisionModel_B.HoughTransform1_o2[159] = 1.2042771838760873;
    VisionModel_B.HoughTransform1_o2[160] = 1.2217304763960306;
    VisionModel_B.HoughTransform1_o2[161] = 1.2391837689159739;
    VisionModel_B.HoughTransform1_o2[162] = 1.2566370614359172;
    VisionModel_B.HoughTransform1_o2[163] = 1.2740903539558606;
    VisionModel_B.HoughTransform1_o2[164] = 1.2915436464758039;
    VisionModel_B.HoughTransform1_o2[165] = 1.3089969389957472;
    VisionModel_B.HoughTransform1_o2[166] = 1.3264502315156905;
    VisionModel_B.HoughTransform1_o2[167] = 1.3439035240356338;
    VisionModel_B.HoughTransform1_o2[168] = 1.3613568165555769;
    VisionModel_B.HoughTransform1_o2[169] = 1.3788101090755203;
    VisionModel_B.HoughTransform1_o2[170] = 1.3962634015954636;
    VisionModel_B.HoughTransform1_o2[171] = 1.4137166941154069;
    VisionModel_B.HoughTransform1_o2[172] = 1.4311699866353502;
    VisionModel_B.HoughTransform1_o2[173] = 1.4486232791552935;
    VisionModel_B.HoughTransform1_o2[174] = 1.4660765716752369;
    VisionModel_B.HoughTransform1_o2[175] = 1.4835298641951802;
    VisionModel_B.HoughTransform1_o2[176] = 1.5009831567151235;
    VisionModel_B.HoughTransform1_o2[177] = 1.5184364492350666;
    VisionModel_B.HoughTransform1_o2[178] = 1.53588974175501;
    VisionModel_B.HoughTransform1_o2[179] = 1.5533430342749532;
    VisionModel_B.HoughTransform1_o3[0] = -199.0;
    VisionModel_B.HoughTransform1_o3[1] = -198.0;
    VisionModel_B.HoughTransform1_o3[2] = -197.0;
    VisionModel_B.HoughTransform1_o3[3] = -196.0;
    VisionModel_B.HoughTransform1_o3[4] = -195.0;
    VisionModel_B.HoughTransform1_o3[5] = -194.0;
    VisionModel_B.HoughTransform1_o3[6] = -193.0;
    VisionModel_B.HoughTransform1_o3[7] = -192.0;
    VisionModel_B.HoughTransform1_o3[8] = -191.0;
    VisionModel_B.HoughTransform1_o3[9] = -190.0;
    VisionModel_B.HoughTransform1_o3[10] = -189.0;
    VisionModel_B.HoughTransform1_o3[11] = -188.0;
    VisionModel_B.HoughTransform1_o3[12] = -187.0;
    VisionModel_B.HoughTransform1_o3[13] = -186.0;
    VisionModel_B.HoughTransform1_o3[14] = -185.0;
    VisionModel_B.HoughTransform1_o3[15] = -184.0;
    VisionModel_B.HoughTransform1_o3[16] = -183.0;
    VisionModel_B.HoughTransform1_o3[17] = -182.0;
    VisionModel_B.HoughTransform1_o3[18] = -181.0;
    VisionModel_B.HoughTransform1_o3[19] = -180.0;
    VisionModel_B.HoughTransform1_o3[20] = -179.0;
    VisionModel_B.HoughTransform1_o3[21] = -178.0;
    VisionModel_B.HoughTransform1_o3[22] = -177.0;
    VisionModel_B.HoughTransform1_o3[23] = -176.0;
    VisionModel_B.HoughTransform1_o3[24] = -175.0;
    VisionModel_B.HoughTransform1_o3[25] = -174.0;
    VisionModel_B.HoughTransform1_o3[26] = -173.0;
    VisionModel_B.HoughTransform1_o3[27] = -172.0;
    VisionModel_B.HoughTransform1_o3[28] = -171.0;
    VisionModel_B.HoughTransform1_o3[29] = -170.0;
    VisionModel_B.HoughTransform1_o3[30] = -169.0;
    VisionModel_B.HoughTransform1_o3[31] = -168.0;
    VisionModel_B.HoughTransform1_o3[32] = -167.0;
    VisionModel_B.HoughTransform1_o3[33] = -166.0;
    VisionModel_B.HoughTransform1_o3[34] = -165.0;
    VisionModel_B.HoughTransform1_o3[35] = -164.0;
    VisionModel_B.HoughTransform1_o3[36] = -163.0;
    VisionModel_B.HoughTransform1_o3[37] = -162.0;
    VisionModel_B.HoughTransform1_o3[38] = -161.0;
    VisionModel_B.HoughTransform1_o3[39] = -160.0;
    VisionModel_B.HoughTransform1_o3[40] = -159.0;
    VisionModel_B.HoughTransform1_o3[41] = -158.0;
    VisionModel_B.HoughTransform1_o3[42] = -157.0;
    VisionModel_B.HoughTransform1_o3[43] = -156.0;
    VisionModel_B.HoughTransform1_o3[44] = -155.0;
    VisionModel_B.HoughTransform1_o3[45] = -154.0;
    VisionModel_B.HoughTransform1_o3[46] = -153.0;
    VisionModel_B.HoughTransform1_o3[47] = -152.0;
    VisionModel_B.HoughTransform1_o3[48] = -151.0;
    VisionModel_B.HoughTransform1_o3[49] = -150.0;
    VisionModel_B.HoughTransform1_o3[50] = -149.0;
    VisionModel_B.HoughTransform1_o3[51] = -148.0;
    VisionModel_B.HoughTransform1_o3[52] = -147.0;
    VisionModel_B.HoughTransform1_o3[53] = -146.0;
    VisionModel_B.HoughTransform1_o3[54] = -145.0;
    VisionModel_B.HoughTransform1_o3[55] = -144.0;
    VisionModel_B.HoughTransform1_o3[56] = -143.0;
    VisionModel_B.HoughTransform1_o3[57] = -142.0;
    VisionModel_B.HoughTransform1_o3[58] = -141.0;
    VisionModel_B.HoughTransform1_o3[59] = -140.0;
    VisionModel_B.HoughTransform1_o3[60] = -139.0;
    VisionModel_B.HoughTransform1_o3[61] = -138.0;
    VisionModel_B.HoughTransform1_o3[62] = -137.0;
    VisionModel_B.HoughTransform1_o3[63] = -136.0;
    VisionModel_B.HoughTransform1_o3[64] = -135.0;
    VisionModel_B.HoughTransform1_o3[65] = -134.0;
    VisionModel_B.HoughTransform1_o3[66] = -133.0;
    VisionModel_B.HoughTransform1_o3[67] = -132.0;
    VisionModel_B.HoughTransform1_o3[68] = -131.0;
    VisionModel_B.HoughTransform1_o3[69] = -130.0;
    VisionModel_B.HoughTransform1_o3[70] = -129.0;
    VisionModel_B.HoughTransform1_o3[71] = -128.0;
    VisionModel_B.HoughTransform1_o3[72] = -127.0;
    VisionModel_B.HoughTransform1_o3[73] = -126.0;
    VisionModel_B.HoughTransform1_o3[74] = -125.0;
    VisionModel_B.HoughTransform1_o3[75] = -124.0;
    VisionModel_B.HoughTransform1_o3[76] = -123.0;
    VisionModel_B.HoughTransform1_o3[77] = -122.0;
    VisionModel_B.HoughTransform1_o3[78] = -121.0;
    VisionModel_B.HoughTransform1_o3[79] = -120.0;
    VisionModel_B.HoughTransform1_o3[80] = -119.0;
    VisionModel_B.HoughTransform1_o3[81] = -118.0;
    VisionModel_B.HoughTransform1_o3[82] = -117.0;
    VisionModel_B.HoughTransform1_o3[83] = -116.0;
    VisionModel_B.HoughTransform1_o3[84] = -115.0;
    VisionModel_B.HoughTransform1_o3[85] = -114.0;
    VisionModel_B.HoughTransform1_o3[86] = -113.0;
    VisionModel_B.HoughTransform1_o3[87] = -112.0;
    VisionModel_B.HoughTransform1_o3[88] = -111.0;
    VisionModel_B.HoughTransform1_o3[89] = -110.0;
    VisionModel_B.HoughTransform1_o3[90] = -109.0;
    VisionModel_B.HoughTransform1_o3[91] = -108.0;
    VisionModel_B.HoughTransform1_o3[92] = -107.0;
    VisionModel_B.HoughTransform1_o3[93] = -106.0;
    VisionModel_B.HoughTransform1_o3[94] = -105.0;
    VisionModel_B.HoughTransform1_o3[95] = -104.0;
    VisionModel_B.HoughTransform1_o3[96] = -103.0;
    VisionModel_B.HoughTransform1_o3[97] = -102.0;
    VisionModel_B.HoughTransform1_o3[98] = -101.0;
    VisionModel_B.HoughTransform1_o3[99] = -100.0;
    VisionModel_B.HoughTransform1_o3[100] = -99.0;
    VisionModel_B.HoughTransform1_o3[101] = -98.0;
    VisionModel_B.HoughTransform1_o3[102] = -97.0;
    VisionModel_B.HoughTransform1_o3[103] = -96.0;
    VisionModel_B.HoughTransform1_o3[104] = -95.0;
    VisionModel_B.HoughTransform1_o3[105] = -94.0;
    VisionModel_B.HoughTransform1_o3[106] = -93.0;
    VisionModel_B.HoughTransform1_o3[107] = -92.0;
    VisionModel_B.HoughTransform1_o3[108] = -91.0;
    VisionModel_B.HoughTransform1_o3[109] = -90.0;
    VisionModel_B.HoughTransform1_o3[110] = -89.0;
    VisionModel_B.HoughTransform1_o3[111] = -88.0;
    VisionModel_B.HoughTransform1_o3[112] = -87.0;
    VisionModel_B.HoughTransform1_o3[113] = -86.0;
    VisionModel_B.HoughTransform1_o3[114] = -85.0;
    VisionModel_B.HoughTransform1_o3[115] = -84.0;
    VisionModel_B.HoughTransform1_o3[116] = -83.0;
    VisionModel_B.HoughTransform1_o3[117] = -82.0;
    VisionModel_B.HoughTransform1_o3[118] = -81.0;
    VisionModel_B.HoughTransform1_o3[119] = -80.0;
    VisionModel_B.HoughTransform1_o3[120] = -79.0;
    VisionModel_B.HoughTransform1_o3[121] = -78.0;
    VisionModel_B.HoughTransform1_o3[122] = -77.0;
    VisionModel_B.HoughTransform1_o3[123] = -76.0;
    VisionModel_B.HoughTransform1_o3[124] = -75.0;
    VisionModel_B.HoughTransform1_o3[125] = -74.0;
    VisionModel_B.HoughTransform1_o3[126] = -73.0;
    VisionModel_B.HoughTransform1_o3[127] = -72.0;
    VisionModel_B.HoughTransform1_o3[128] = -71.0;
    VisionModel_B.HoughTransform1_o3[129] = -70.0;
    VisionModel_B.HoughTransform1_o3[130] = -69.0;
    VisionModel_B.HoughTransform1_o3[131] = -68.0;
    VisionModel_B.HoughTransform1_o3[132] = -67.0;
    VisionModel_B.HoughTransform1_o3[133] = -66.0;
    VisionModel_B.HoughTransform1_o3[134] = -65.0;
    VisionModel_B.HoughTransform1_o3[135] = -64.0;
    VisionModel_B.HoughTransform1_o3[136] = -63.0;
    VisionModel_B.HoughTransform1_o3[137] = -62.0;
    VisionModel_B.HoughTransform1_o3[138] = -61.0;
    VisionModel_B.HoughTransform1_o3[139] = -60.0;
    VisionModel_B.HoughTransform1_o3[140] = -59.0;
    VisionModel_B.HoughTransform1_o3[141] = -58.0;
    VisionModel_B.HoughTransform1_o3[142] = -57.0;
    VisionModel_B.HoughTransform1_o3[143] = -56.0;
    VisionModel_B.HoughTransform1_o3[144] = -55.0;
    VisionModel_B.HoughTransform1_o3[145] = -54.0;
    VisionModel_B.HoughTransform1_o3[146] = -53.0;
    VisionModel_B.HoughTransform1_o3[147] = -52.0;
    VisionModel_B.HoughTransform1_o3[148] = -51.0;
    VisionModel_B.HoughTransform1_o3[149] = -50.0;
    VisionModel_B.HoughTransform1_o3[150] = -49.0;
    VisionModel_B.HoughTransform1_o3[151] = -48.0;
    VisionModel_B.HoughTransform1_o3[152] = -47.0;
    VisionModel_B.HoughTransform1_o3[153] = -46.0;
    VisionModel_B.HoughTransform1_o3[154] = -45.0;
    VisionModel_B.HoughTransform1_o3[155] = -44.0;
    VisionModel_B.HoughTransform1_o3[156] = -43.0;
    VisionModel_B.HoughTransform1_o3[157] = -42.0;
    VisionModel_B.HoughTransform1_o3[158] = -41.0;
    VisionModel_B.HoughTransform1_o3[159] = -40.0;
    VisionModel_B.HoughTransform1_o3[160] = -39.0;
    VisionModel_B.HoughTransform1_o3[161] = -38.0;
    VisionModel_B.HoughTransform1_o3[162] = -37.0;
    VisionModel_B.HoughTransform1_o3[163] = -36.0;
    VisionModel_B.HoughTransform1_o3[164] = -35.0;
    VisionModel_B.HoughTransform1_o3[165] = -34.0;
    VisionModel_B.HoughTransform1_o3[166] = -33.0;
    VisionModel_B.HoughTransform1_o3[167] = -32.0;
    VisionModel_B.HoughTransform1_o3[168] = -31.0;
    VisionModel_B.HoughTransform1_o3[169] = -30.0;
    VisionModel_B.HoughTransform1_o3[170] = -29.0;
    VisionModel_B.HoughTransform1_o3[171] = -28.0;
    VisionModel_B.HoughTransform1_o3[172] = -27.0;
    VisionModel_B.HoughTransform1_o3[173] = -26.0;
    VisionModel_B.HoughTransform1_o3[174] = -25.0;
    VisionModel_B.HoughTransform1_o3[175] = -24.0;
    VisionModel_B.HoughTransform1_o3[176] = -23.0;
    VisionModel_B.HoughTransform1_o3[177] = -22.0;
    VisionModel_B.HoughTransform1_o3[178] = -21.0;
    VisionModel_B.HoughTransform1_o3[179] = -20.0;
    VisionModel_B.HoughTransform1_o3[180] = -19.0;
    VisionModel_B.HoughTransform1_o3[181] = -18.0;
    VisionModel_B.HoughTransform1_o3[182] = -17.0;
    VisionModel_B.HoughTransform1_o3[183] = -16.0;
    VisionModel_B.HoughTransform1_o3[184] = -15.0;
    VisionModel_B.HoughTransform1_o3[185] = -14.0;
    VisionModel_B.HoughTransform1_o3[186] = -13.0;
    VisionModel_B.HoughTransform1_o3[187] = -12.0;
    VisionModel_B.HoughTransform1_o3[188] = -11.0;
    VisionModel_B.HoughTransform1_o3[189] = -10.0;
    VisionModel_B.HoughTransform1_o3[190] = -9.0;
    VisionModel_B.HoughTransform1_o3[191] = -8.0;
    VisionModel_B.HoughTransform1_o3[192] = -7.0;
    VisionModel_B.HoughTransform1_o3[193] = -6.0;
    VisionModel_B.HoughTransform1_o3[194] = -5.0;
    VisionModel_B.HoughTransform1_o3[195] = -4.0;
    VisionModel_B.HoughTransform1_o3[196] = -3.0;
    VisionModel_B.HoughTransform1_o3[197] = -2.0;
    VisionModel_B.HoughTransform1_o3[198] = -1.0;
    VisionModel_B.HoughTransform1_o3[199] = 0.0;
    VisionModel_B.HoughTransform1_o3[200] = 1.0;
    VisionModel_B.HoughTransform1_o3[201] = 2.0;
    VisionModel_B.HoughTransform1_o3[202] = 3.0;
    VisionModel_B.HoughTransform1_o3[203] = 4.0;
    VisionModel_B.HoughTransform1_o3[204] = 5.0;
    VisionModel_B.HoughTransform1_o3[205] = 6.0;
    VisionModel_B.HoughTransform1_o3[206] = 7.0;
    VisionModel_B.HoughTransform1_o3[207] = 8.0;
    VisionModel_B.HoughTransform1_o3[208] = 9.0;
    VisionModel_B.HoughTransform1_o3[209] = 10.0;
    VisionModel_B.HoughTransform1_o3[210] = 11.0;
    VisionModel_B.HoughTransform1_o3[211] = 12.0;
    VisionModel_B.HoughTransform1_o3[212] = 13.0;
    VisionModel_B.HoughTransform1_o3[213] = 14.0;
    VisionModel_B.HoughTransform1_o3[214] = 15.0;
    VisionModel_B.HoughTransform1_o3[215] = 16.0;
    VisionModel_B.HoughTransform1_o3[216] = 17.0;
    VisionModel_B.HoughTransform1_o3[217] = 18.0;
    VisionModel_B.HoughTransform1_o3[218] = 19.0;
    VisionModel_B.HoughTransform1_o3[219] = 20.0;
    VisionModel_B.HoughTransform1_o3[220] = 21.0;
    VisionModel_B.HoughTransform1_o3[221] = 22.0;
    VisionModel_B.HoughTransform1_o3[222] = 23.0;
    VisionModel_B.HoughTransform1_o3[223] = 24.0;
    VisionModel_B.HoughTransform1_o3[224] = 25.0;
    VisionModel_B.HoughTransform1_o3[225] = 26.0;
    VisionModel_B.HoughTransform1_o3[226] = 27.0;
    VisionModel_B.HoughTransform1_o3[227] = 28.0;
    VisionModel_B.HoughTransform1_o3[228] = 29.0;
    VisionModel_B.HoughTransform1_o3[229] = 30.0;
    VisionModel_B.HoughTransform1_o3[230] = 31.0;
    VisionModel_B.HoughTransform1_o3[231] = 32.0;
    VisionModel_B.HoughTransform1_o3[232] = 33.0;
    VisionModel_B.HoughTransform1_o3[233] = 34.0;
    VisionModel_B.HoughTransform1_o3[234] = 35.0;
    VisionModel_B.HoughTransform1_o3[235] = 36.0;
    VisionModel_B.HoughTransform1_o3[236] = 37.0;
    VisionModel_B.HoughTransform1_o3[237] = 38.0;
    VisionModel_B.HoughTransform1_o3[238] = 39.0;
    VisionModel_B.HoughTransform1_o3[239] = 40.0;
    VisionModel_B.HoughTransform1_o3[240] = 41.0;
    VisionModel_B.HoughTransform1_o3[241] = 42.0;
    VisionModel_B.HoughTransform1_o3[242] = 43.0;
    VisionModel_B.HoughTransform1_o3[243] = 44.0;
    VisionModel_B.HoughTransform1_o3[244] = 45.0;
    VisionModel_B.HoughTransform1_o3[245] = 46.0;
    VisionModel_B.HoughTransform1_o3[246] = 47.0;
    VisionModel_B.HoughTransform1_o3[247] = 48.0;
    VisionModel_B.HoughTransform1_o3[248] = 49.0;
    VisionModel_B.HoughTransform1_o3[249] = 50.0;
    VisionModel_B.HoughTransform1_o3[250] = 51.0;
    VisionModel_B.HoughTransform1_o3[251] = 52.0;
    VisionModel_B.HoughTransform1_o3[252] = 53.0;
    VisionModel_B.HoughTransform1_o3[253] = 54.0;
    VisionModel_B.HoughTransform1_o3[254] = 55.0;
    VisionModel_B.HoughTransform1_o3[255] = 56.0;
    VisionModel_B.HoughTransform1_o3[256] = 57.0;
    VisionModel_B.HoughTransform1_o3[257] = 58.0;
    VisionModel_B.HoughTransform1_o3[258] = 59.0;
    VisionModel_B.HoughTransform1_o3[259] = 60.0;
    VisionModel_B.HoughTransform1_o3[260] = 61.0;
    VisionModel_B.HoughTransform1_o3[261] = 62.0;
    VisionModel_B.HoughTransform1_o3[262] = 63.0;
    VisionModel_B.HoughTransform1_o3[263] = 64.0;
    VisionModel_B.HoughTransform1_o3[264] = 65.0;
    VisionModel_B.HoughTransform1_o3[265] = 66.0;
    VisionModel_B.HoughTransform1_o3[266] = 67.0;
    VisionModel_B.HoughTransform1_o3[267] = 68.0;
    VisionModel_B.HoughTransform1_o3[268] = 69.0;
    VisionModel_B.HoughTransform1_o3[269] = 70.0;
    VisionModel_B.HoughTransform1_o3[270] = 71.0;
    VisionModel_B.HoughTransform1_o3[271] = 72.0;
    VisionModel_B.HoughTransform1_o3[272] = 73.0;
    VisionModel_B.HoughTransform1_o3[273] = 74.0;
    VisionModel_B.HoughTransform1_o3[274] = 75.0;
    VisionModel_B.HoughTransform1_o3[275] = 76.0;
    VisionModel_B.HoughTransform1_o3[276] = 77.0;
    VisionModel_B.HoughTransform1_o3[277] = 78.0;
    VisionModel_B.HoughTransform1_o3[278] = 79.0;
    VisionModel_B.HoughTransform1_o3[279] = 80.0;
    VisionModel_B.HoughTransform1_o3[280] = 81.0;
    VisionModel_B.HoughTransform1_o3[281] = 82.0;
    VisionModel_B.HoughTransform1_o3[282] = 83.0;
    VisionModel_B.HoughTransform1_o3[283] = 84.0;
    VisionModel_B.HoughTransform1_o3[284] = 85.0;
    VisionModel_B.HoughTransform1_o3[285] = 86.0;
    VisionModel_B.HoughTransform1_o3[286] = 87.0;
    VisionModel_B.HoughTransform1_o3[287] = 88.0;
    VisionModel_B.HoughTransform1_o3[288] = 89.0;
    VisionModel_B.HoughTransform1_o3[289] = 90.0;
    VisionModel_B.HoughTransform1_o3[290] = 91.0;
    VisionModel_B.HoughTransform1_o3[291] = 92.0;
    VisionModel_B.HoughTransform1_o3[292] = 93.0;
    VisionModel_B.HoughTransform1_o3[293] = 94.0;
    VisionModel_B.HoughTransform1_o3[294] = 95.0;
    VisionModel_B.HoughTransform1_o3[295] = 96.0;
    VisionModel_B.HoughTransform1_o3[296] = 97.0;
    VisionModel_B.HoughTransform1_o3[297] = 98.0;
    VisionModel_B.HoughTransform1_o3[298] = 99.0;
    VisionModel_B.HoughTransform1_o3[299] = 100.0;
    VisionModel_B.HoughTransform1_o3[300] = 101.0;
    VisionModel_B.HoughTransform1_o3[301] = 102.0;
    VisionModel_B.HoughTransform1_o3[302] = 103.0;
    VisionModel_B.HoughTransform1_o3[303] = 104.0;
    VisionModel_B.HoughTransform1_o3[304] = 105.0;
    VisionModel_B.HoughTransform1_o3[305] = 106.0;
    VisionModel_B.HoughTransform1_o3[306] = 107.0;
    VisionModel_B.HoughTransform1_o3[307] = 108.0;
    VisionModel_B.HoughTransform1_o3[308] = 109.0;
    VisionModel_B.HoughTransform1_o3[309] = 110.0;
    VisionModel_B.HoughTransform1_o3[310] = 111.0;
    VisionModel_B.HoughTransform1_o3[311] = 112.0;
    VisionModel_B.HoughTransform1_o3[312] = 113.0;
    VisionModel_B.HoughTransform1_o3[313] = 114.0;
    VisionModel_B.HoughTransform1_o3[314] = 115.0;
    VisionModel_B.HoughTransform1_o3[315] = 116.0;
    VisionModel_B.HoughTransform1_o3[316] = 117.0;
    VisionModel_B.HoughTransform1_o3[317] = 118.0;
    VisionModel_B.HoughTransform1_o3[318] = 119.0;
    VisionModel_B.HoughTransform1_o3[319] = 120.0;
    VisionModel_B.HoughTransform1_o3[320] = 121.0;
    VisionModel_B.HoughTransform1_o3[321] = 122.0;
    VisionModel_B.HoughTransform1_o3[322] = 123.0;
    VisionModel_B.HoughTransform1_o3[323] = 124.0;
    VisionModel_B.HoughTransform1_o3[324] = 125.0;
    VisionModel_B.HoughTransform1_o3[325] = 126.0;
    VisionModel_B.HoughTransform1_o3[326] = 127.0;
    VisionModel_B.HoughTransform1_o3[327] = 128.0;
    VisionModel_B.HoughTransform1_o3[328] = 129.0;
    VisionModel_B.HoughTransform1_o3[329] = 130.0;
    VisionModel_B.HoughTransform1_o3[330] = 131.0;
    VisionModel_B.HoughTransform1_o3[331] = 132.0;
    VisionModel_B.HoughTransform1_o3[332] = 133.0;
    VisionModel_B.HoughTransform1_o3[333] = 134.0;
    VisionModel_B.HoughTransform1_o3[334] = 135.0;
    VisionModel_B.HoughTransform1_o3[335] = 136.0;
    VisionModel_B.HoughTransform1_o3[336] = 137.0;
    VisionModel_B.HoughTransform1_o3[337] = 138.0;
    VisionModel_B.HoughTransform1_o3[338] = 139.0;
    VisionModel_B.HoughTransform1_o3[339] = 140.0;
    VisionModel_B.HoughTransform1_o3[340] = 141.0;
    VisionModel_B.HoughTransform1_o3[341] = 142.0;
    VisionModel_B.HoughTransform1_o3[342] = 143.0;
    VisionModel_B.HoughTransform1_o3[343] = 144.0;
    VisionModel_B.HoughTransform1_o3[344] = 145.0;
    VisionModel_B.HoughTransform1_o3[345] = 146.0;
    VisionModel_B.HoughTransform1_o3[346] = 147.0;
    VisionModel_B.HoughTransform1_o3[347] = 148.0;
    VisionModel_B.HoughTransform1_o3[348] = 149.0;
    VisionModel_B.HoughTransform1_o3[349] = 150.0;
    VisionModel_B.HoughTransform1_o3[350] = 151.0;
    VisionModel_B.HoughTransform1_o3[351] = 152.0;
    VisionModel_B.HoughTransform1_o3[352] = 153.0;
    VisionModel_B.HoughTransform1_o3[353] = 154.0;
    VisionModel_B.HoughTransform1_o3[354] = 155.0;
    VisionModel_B.HoughTransform1_o3[355] = 156.0;
    VisionModel_B.HoughTransform1_o3[356] = 157.0;
    VisionModel_B.HoughTransform1_o3[357] = 158.0;
    VisionModel_B.HoughTransform1_o3[358] = 159.0;
    VisionModel_B.HoughTransform1_o3[359] = 160.0;
    VisionModel_B.HoughTransform1_o3[360] = 161.0;
    VisionModel_B.HoughTransform1_o3[361] = 162.0;
    VisionModel_B.HoughTransform1_o3[362] = 163.0;
    VisionModel_B.HoughTransform1_o3[363] = 164.0;
    VisionModel_B.HoughTransform1_o3[364] = 165.0;
    VisionModel_B.HoughTransform1_o3[365] = 166.0;
    VisionModel_B.HoughTransform1_o3[366] = 167.0;
    VisionModel_B.HoughTransform1_o3[367] = 168.0;
    VisionModel_B.HoughTransform1_o3[368] = 169.0;
    VisionModel_B.HoughTransform1_o3[369] = 170.0;
    VisionModel_B.HoughTransform1_o3[370] = 171.0;
    VisionModel_B.HoughTransform1_o3[371] = 172.0;
    VisionModel_B.HoughTransform1_o3[372] = 173.0;
    VisionModel_B.HoughTransform1_o3[373] = 174.0;
    VisionModel_B.HoughTransform1_o3[374] = 175.0;
    VisionModel_B.HoughTransform1_o3[375] = 176.0;
    VisionModel_B.HoughTransform1_o3[376] = 177.0;
    VisionModel_B.HoughTransform1_o3[377] = 178.0;
    VisionModel_B.HoughTransform1_o3[378] = 179.0;
    VisionModel_B.HoughTransform1_o3[379] = 180.0;
    VisionModel_B.HoughTransform1_o3[380] = 181.0;
    VisionModel_B.HoughTransform1_o3[381] = 182.0;
    VisionModel_B.HoughTransform1_o3[382] = 183.0;
    VisionModel_B.HoughTransform1_o3[383] = 184.0;
    VisionModel_B.HoughTransform1_o3[384] = 185.0;
    VisionModel_B.HoughTransform1_o3[385] = 186.0;
    VisionModel_B.HoughTransform1_o3[386] = 187.0;
    VisionModel_B.HoughTransform1_o3[387] = 188.0;
    VisionModel_B.HoughTransform1_o3[388] = 189.0;
    VisionModel_B.HoughTransform1_o3[389] = 190.0;
    VisionModel_B.HoughTransform1_o3[390] = 191.0;
    VisionModel_B.HoughTransform1_o3[391] = 192.0;
    VisionModel_B.HoughTransform1_o3[392] = 193.0;
    VisionModel_B.HoughTransform1_o3[393] = 194.0;
    VisionModel_B.HoughTransform1_o3[394] = 195.0;
    VisionModel_B.HoughTransform1_o3[395] = 196.0;
    VisionModel_B.HoughTransform1_o3[396] = 197.0;
    VisionModel_B.HoughTransform1_o3[397] = 198.0;
    VisionModel_B.HoughTransform1_o3[398] = 199.0;
  }

  /* states (dwork) */
  (void) memset((void *)&VisionModel_DWork, 0,
                sizeof(D_Work_VisionModel));

  /* external inputs */
  (void) memset((void *)&VisionModel_U, 0,
                sizeof(ExternalInputs_VisionModel));

  /* external outputs */
  (void) memset((void *)&VisionModel_Y, 0,
                sizeof(ExternalOutputs_VisionModel));

  {
    int32_T i;
    static int16_T tmp[8] = { -1, 161, 162, 163, 1, -161, -162, -163 };

    /* Start for ifaction SubSystem: '<Root>/Blob_Analysis' */

    /* InitializeConditions for Embedded MATLAB: '<S1>/Blob Extraction' */
    for (i = 0; i < 8; i++) {
      VisionModel_DWork.WALKER_RTP[i] = tmp[i];
    }

    VisionModel_DWork.F0_RTP = -1;
    VisionModel_DWork.F1_RTP = -1.0;
    VisionModel_DWork.F2_RTP = -1;
    VisionModel_DWork.F3_RTP = -1.0;
    VisionModel_DWork.F4_RTP = -1.0;
    VisionModel_DWork.F5_RTP = -1.0;
    VisionModel_DWork.F6_RTP = -1.0;
    VisionModel_DWork.F7_RTP = -1.0;
    VisionModel_DWork.MINAREA_RTP = 5U;

    /* end of Start for SubSystem: '<Root>/Blob_Analysis' */

    /* Start for ifaction SubSystem: '<Root>/validation_gate' */

    /* InitializeConditions for S-Function (svipedge): '<S8>/Edge Detection' */
    VisionModel_DWork.EdgeDetection_MEAN_FACTOR_DW = 5.2083333333333337E-5;

    /* end of Start for SubSystem: '<Root>/validation_gate' */

    /* Start for ifaction SubSystem: '<Root>/L_detector' */

    /* InitializeConditions for S-Function (svipedge): '<S4>/Edge Detection1' */
    VisionModel_DWork.EdgeDetection1_MEAN_FACTOR_DW = 5.2083333333333337E-5;
    for (i = 0; i < 6; i++) {
      VisionModel_DWork.EdgeDetection_VO_DW[i] = VisionModel_ConstP.pooled9[i] *
        160 + VisionModel_ConstP.pooled10[i];
      if (VisionModel_ConstP.pooled10[i] > 0) {
        VisionModel_DWork.EdgeDetection_VOU_DW[i] = VisionModel_ConstP.pooled9[i]
          * 160 + VisionModel_ConstP.pooled10[i];
        VisionModel_DWork.EdgeDetection_VOD_DW[i] = VisionModel_ConstP.pooled9[i]
          * 160;
      } else {
        VisionModel_DWork.EdgeDetection_VOU_DW[i] = VisionModel_ConstP.pooled9[i]
          * 160;
        VisionModel_DWork.EdgeDetection_VOD_DW[i] = VisionModel_ConstP.pooled9[i]
          * 160 + VisionModel_ConstP.pooled10[i];
      }

      if (VisionModel_ConstP.pooled9[i] > 0) {
        VisionModel_DWork.EdgeDetection_VOL_DW[i] = VisionModel_ConstP.pooled9[i]
          * 160 + VisionModel_ConstP.pooled10[i];
        VisionModel_DWork.EdgeDetection_VOR_DW[i] =
          VisionModel_ConstP.pooled10[i];
      } else {
        VisionModel_DWork.EdgeDetection_VOL_DW[i] =
          VisionModel_ConstP.pooled10[i];
        VisionModel_DWork.EdgeDetection_VOR_DW[i] = VisionModel_ConstP.pooled9[i]
          * 160 + VisionModel_ConstP.pooled10[i];
      }

      if ((VisionModel_ConstP.pooled10[i] < 0) && (VisionModel_ConstP.pooled9[i]
           < 0)) {
        VisionModel_DWork.EdgeDetection_VOUL_DW[i] = 0;
        VisionModel_DWork.EdgeDetection_VOLR_DW[i] =
          VisionModel_ConstP.pooled9[i] * 160 + VisionModel_ConstP.pooled10[i];
        VisionModel_DWork.EdgeDetection_VOLL_DW[i] =
          VisionModel_ConstP.pooled10[i];
        VisionModel_DWork.EdgeDetection_VOUR_DW[i] =
          VisionModel_ConstP.pooled9[i] * 160;
      }

      if ((VisionModel_ConstP.pooled10[i] >= 0) && (VisionModel_ConstP.pooled9[i]
           < 0)) {
        VisionModel_DWork.EdgeDetection_VOLL_DW[i] = 0;
        VisionModel_DWork.EdgeDetection_VOUR_DW[i] =
          VisionModel_ConstP.pooled9[i] * 160 + VisionModel_ConstP.pooled10[i];
        VisionModel_DWork.EdgeDetection_VOUL_DW[i] =
          VisionModel_ConstP.pooled10[i];
        VisionModel_DWork.EdgeDetection_VOLR_DW[i] =
          VisionModel_ConstP.pooled9[i] * 160;
      }

      if ((VisionModel_ConstP.pooled10[i] < 0) && (VisionModel_ConstP.pooled9[i]
           >= 0)) {
        VisionModel_DWork.EdgeDetection_VOUR_DW[i] = 0;
        VisionModel_DWork.EdgeDetection_VOLL_DW[i] =
          VisionModel_ConstP.pooled9[i] * 160 + VisionModel_ConstP.pooled10[i];
        VisionModel_DWork.EdgeDetection_VOUL_DW[i] =
          VisionModel_ConstP.pooled9[i] * 160;
        VisionModel_DWork.EdgeDetection_VOLR_DW[i] =
          VisionModel_ConstP.pooled10[i];
      }

      if ((VisionModel_ConstP.pooled10[i] >= 0) && (VisionModel_ConstP.pooled9[i]
           >= 0)) {
        VisionModel_DWork.EdgeDetection_VOLR_DW[i] = 0;
        VisionModel_DWork.EdgeDetection_VOUL_DW[i] =
          VisionModel_ConstP.pooled9[i] * 160 + VisionModel_ConstP.pooled10[i];
        VisionModel_DWork.EdgeDetection_VOLL_DW[i] =
          VisionModel_ConstP.pooled9[i] * 160;
        VisionModel_DWork.EdgeDetection_VOUR_DW[i] =
          VisionModel_ConstP.pooled10[i];
      }

      VisionModel_DWork.EdgeDetection_HO_DW[i] = VisionModel_ConstP.pooled11[i] *
        160 + VisionModel_ConstP.pooled12[i];
      if (VisionModel_ConstP.pooled12[i] > 0) {
        VisionModel_DWork.EdgeDetection_HOU_DW[i] =
          VisionModel_ConstP.pooled11[i] * 160 + VisionModel_ConstP.pooled12[i];
        VisionModel_DWork.EdgeDetection_HOD_DW[i] =
          VisionModel_ConstP.pooled11[i] * 160;
      } else {
        VisionModel_DWork.EdgeDetection_HOU_DW[i] =
          VisionModel_ConstP.pooled11[i] * 160;
        VisionModel_DWork.EdgeDetection_HOD_DW[i] =
          VisionModel_ConstP.pooled11[i] * 160 + VisionModel_ConstP.pooled12[i];
      }

      if (VisionModel_ConstP.pooled11[i] > 0) {
        VisionModel_DWork.EdgeDetection_HOL_DW[i] =
          VisionModel_ConstP.pooled11[i] * 160 + VisionModel_ConstP.pooled12[i];
        VisionModel_DWork.EdgeDetection_HOR_DW[i] =
          VisionModel_ConstP.pooled12[i];
      } else {
        VisionModel_DWork.EdgeDetection_HOL_DW[i] =
          VisionModel_ConstP.pooled12[i];
        VisionModel_DWork.EdgeDetection_HOR_DW[i] =
          VisionModel_ConstP.pooled11[i] * 160 + VisionModel_ConstP.pooled12[i];
      }

      if ((VisionModel_ConstP.pooled12[i] < 0) && (VisionModel_ConstP.pooled11[i]
           < 0)) {
        VisionModel_DWork.EdgeDetection_HOUL_DW[i] = 0;
        VisionModel_DWork.EdgeDetection_HOLR_DW[i] =
          VisionModel_ConstP.pooled11[i] * 160 + VisionModel_ConstP.pooled12[i];
        VisionModel_DWork.EdgeDetection_HOLL_DW[i] =
          VisionModel_ConstP.pooled12[i];
        VisionModel_DWork.EdgeDetection_HOUR_DW[i] =
          VisionModel_ConstP.pooled11[i] * 160;
      }

      if ((VisionModel_ConstP.pooled12[i] >= 0) &&
          (VisionModel_ConstP.pooled11[i] < 0)) {
        VisionModel_DWork.EdgeDetection_HOLL_DW[i] = 0;
        VisionModel_DWork.EdgeDetection_HOUR_DW[i] =
          VisionModel_ConstP.pooled11[i] * 160 + VisionModel_ConstP.pooled12[i];
        VisionModel_DWork.EdgeDetection_HOUL_DW[i] =
          VisionModel_ConstP.pooled12[i];
        VisionModel_DWork.EdgeDetection_HOLR_DW[i] =
          VisionModel_ConstP.pooled11[i] * 160;
      }

      if ((VisionModel_ConstP.pooled12[i] < 0) && (VisionModel_ConstP.pooled11[i]
           >= 0)) {
        VisionModel_DWork.EdgeDetection_HOUR_DW[i] = 0;
        VisionModel_DWork.EdgeDetection_HOLL_DW[i] =
          VisionModel_ConstP.pooled11[i] * 160 + VisionModel_ConstP.pooled12[i];
        VisionModel_DWork.EdgeDetection_HOUL_DW[i] =
          VisionModel_ConstP.pooled11[i] * 160;
        VisionModel_DWork.EdgeDetection_HOLR_DW[i] =
          VisionModel_ConstP.pooled12[i];
      }

      if ((VisionModel_ConstP.pooled12[i] >= 0) &&
          (VisionModel_ConstP.pooled11[i] >= 0)) {
        VisionModel_DWork.EdgeDetection_HOLR_DW[i] = 0;
        VisionModel_DWork.EdgeDetection_HOUL_DW[i] =
          VisionModel_ConstP.pooled11[i] * 160 + VisionModel_ConstP.pooled12[i];
        VisionModel_DWork.EdgeDetection_HOLL_DW[i] =
          VisionModel_ConstP.pooled11[i] * 160;
        VisionModel_DWork.EdgeDetection_HOUR_DW[i] =
          VisionModel_ConstP.pooled12[i];
      }

      VisionModel_DWork.EdgeDetection1_VO_DW[i] = VisionModel_ConstP.pooled9[i] *
        160 + VisionModel_ConstP.pooled10[i];
      if (VisionModel_ConstP.pooled10[i] > 0) {
        VisionModel_DWork.EdgeDetection1_VOU_DW[i] =
          VisionModel_ConstP.pooled9[i] * 160 + VisionModel_ConstP.pooled10[i];
        VisionModel_DWork.EdgeDetection1_VOD_DW[i] =
          VisionModel_ConstP.pooled9[i] * 160;
      } else {
        VisionModel_DWork.EdgeDetection1_VOU_DW[i] =
          VisionModel_ConstP.pooled9[i] * 160;
        VisionModel_DWork.EdgeDetection1_VOD_DW[i] =
          VisionModel_ConstP.pooled9[i] * 160 + VisionModel_ConstP.pooled10[i];
      }

      if (VisionModel_ConstP.pooled9[i] > 0) {
        VisionModel_DWork.EdgeDetection1_VOL_DW[i] =
          VisionModel_ConstP.pooled9[i] * 160 + VisionModel_ConstP.pooled10[i];
        VisionModel_DWork.EdgeDetection1_VOR_DW[i] =
          VisionModel_ConstP.pooled10[i];
      } else {
        VisionModel_DWork.EdgeDetection1_VOL_DW[i] =
          VisionModel_ConstP.pooled10[i];
        VisionModel_DWork.EdgeDetection1_VOR_DW[i] =
          VisionModel_ConstP.pooled9[i] * 160 + VisionModel_ConstP.pooled10[i];
      }

      if ((VisionModel_ConstP.pooled10[i] < 0) && (VisionModel_ConstP.pooled9[i]
           < 0)) {
        VisionModel_DWork.EdgeDetection1_VOUL_DW[i] = 0;
        VisionModel_DWork.EdgeDetection1_VOLR_DW[i] =
          VisionModel_ConstP.pooled9[i] * 160 + VisionModel_ConstP.pooled10[i];
        VisionModel_DWork.EdgeDetection1_VOLL_DW[i] =
          VisionModel_ConstP.pooled10[i];
        VisionModel_DWork.EdgeDetection1_VOUR_DW[i] =
          VisionModel_ConstP.pooled9[i] * 160;
      }

      if ((VisionModel_ConstP.pooled10[i] >= 0) && (VisionModel_ConstP.pooled9[i]
           < 0)) {
        VisionModel_DWork.EdgeDetection1_VOLL_DW[i] = 0;
        VisionModel_DWork.EdgeDetection1_VOUR_DW[i] =
          VisionModel_ConstP.pooled9[i] * 160 + VisionModel_ConstP.pooled10[i];
        VisionModel_DWork.EdgeDetection1_VOUL_DW[i] =
          VisionModel_ConstP.pooled10[i];
        VisionModel_DWork.EdgeDetection1_VOLR_DW[i] =
          VisionModel_ConstP.pooled9[i] * 160;
      }

      if ((VisionModel_ConstP.pooled10[i] < 0) && (VisionModel_ConstP.pooled9[i]
           >= 0)) {
        VisionModel_DWork.EdgeDetection1_VOUR_DW[i] = 0;
        VisionModel_DWork.EdgeDetection1_VOLL_DW[i] =
          VisionModel_ConstP.pooled9[i] * 160 + VisionModel_ConstP.pooled10[i];
        VisionModel_DWork.EdgeDetection1_VOUL_DW[i] =
          VisionModel_ConstP.pooled9[i] * 160;
        VisionModel_DWork.EdgeDetection1_VOLR_DW[i] =
          VisionModel_ConstP.pooled10[i];
      }

      if ((VisionModel_ConstP.pooled10[i] >= 0) && (VisionModel_ConstP.pooled9[i]
           >= 0)) {
        VisionModel_DWork.EdgeDetection1_VOLR_DW[i] = 0;
        VisionModel_DWork.EdgeDetection1_VOUL_DW[i] =
          VisionModel_ConstP.pooled9[i] * 160 + VisionModel_ConstP.pooled10[i];
        VisionModel_DWork.EdgeDetection1_VOLL_DW[i] =
          VisionModel_ConstP.pooled9[i] * 160;
        VisionModel_DWork.EdgeDetection1_VOUR_DW[i] =
          VisionModel_ConstP.pooled10[i];
      }

      VisionModel_DWork.EdgeDetection1_HO_DW[i] = VisionModel_ConstP.pooled11[i]
        * 160 + VisionModel_ConstP.pooled12[i];
      if (VisionModel_ConstP.pooled12[i] > 0) {
        VisionModel_DWork.EdgeDetection1_HOU_DW[i] =
          VisionModel_ConstP.pooled11[i] * 160 + VisionModel_ConstP.pooled12[i];
        VisionModel_DWork.EdgeDetection1_HOD_DW[i] =
          VisionModel_ConstP.pooled11[i] * 160;
      } else {
        VisionModel_DWork.EdgeDetection1_HOU_DW[i] =
          VisionModel_ConstP.pooled11[i] * 160;
        VisionModel_DWork.EdgeDetection1_HOD_DW[i] =
          VisionModel_ConstP.pooled11[i] * 160 + VisionModel_ConstP.pooled12[i];
      }

      if (VisionModel_ConstP.pooled11[i] > 0) {
        VisionModel_DWork.EdgeDetection1_HOL_DW[i] =
          VisionModel_ConstP.pooled11[i] * 160 + VisionModel_ConstP.pooled12[i];
        VisionModel_DWork.EdgeDetection1_HOR_DW[i] =
          VisionModel_ConstP.pooled12[i];
      } else {
        VisionModel_DWork.EdgeDetection1_HOL_DW[i] =
          VisionModel_ConstP.pooled12[i];
        VisionModel_DWork.EdgeDetection1_HOR_DW[i] =
          VisionModel_ConstP.pooled11[i] * 160 + VisionModel_ConstP.pooled12[i];
      }

      if ((VisionModel_ConstP.pooled12[i] < 0) && (VisionModel_ConstP.pooled11[i]
           < 0)) {
        VisionModel_DWork.EdgeDetection1_HOUL_DW[i] = 0;
        VisionModel_DWork.EdgeDetection1_HOLR_DW[i] =
          VisionModel_ConstP.pooled11[i] * 160 + VisionModel_ConstP.pooled12[i];
        VisionModel_DWork.EdgeDetection1_HOLL_DW[i] =
          VisionModel_ConstP.pooled12[i];
        VisionModel_DWork.EdgeDetection1_HOUR_DW[i] =
          VisionModel_ConstP.pooled11[i] * 160;
      }

      if ((VisionModel_ConstP.pooled12[i] >= 0) &&
          (VisionModel_ConstP.pooled11[i] < 0)) {
        VisionModel_DWork.EdgeDetection1_HOLL_DW[i] = 0;
        VisionModel_DWork.EdgeDetection1_HOUR_DW[i] =
          VisionModel_ConstP.pooled11[i] * 160 + VisionModel_ConstP.pooled12[i];
        VisionModel_DWork.EdgeDetection1_HOUL_DW[i] =
          VisionModel_ConstP.pooled12[i];
        VisionModel_DWork.EdgeDetection1_HOLR_DW[i] =
          VisionModel_ConstP.pooled11[i] * 160;
      }

      if ((VisionModel_ConstP.pooled12[i] < 0) && (VisionModel_ConstP.pooled11[i]
           >= 0)) {
        VisionModel_DWork.EdgeDetection1_HOUR_DW[i] = 0;
        VisionModel_DWork.EdgeDetection1_HOLL_DW[i] =
          VisionModel_ConstP.pooled11[i] * 160 + VisionModel_ConstP.pooled12[i];
        VisionModel_DWork.EdgeDetection1_HOUL_DW[i] =
          VisionModel_ConstP.pooled11[i] * 160;
        VisionModel_DWork.EdgeDetection1_HOLR_DW[i] =
          VisionModel_ConstP.pooled12[i];
      }

      if ((VisionModel_ConstP.pooled12[i] >= 0) &&
          (VisionModel_ConstP.pooled11[i] >= 0)) {
        VisionModel_DWork.EdgeDetection1_HOLR_DW[i] = 0;
        VisionModel_DWork.EdgeDetection1_HOUL_DW[i] =
          VisionModel_ConstP.pooled11[i] * 160 + VisionModel_ConstP.pooled12[i];
        VisionModel_DWork.EdgeDetection1_HOLL_DW[i] =
          VisionModel_ConstP.pooled11[i] * 160;
        VisionModel_DWork.EdgeDetection1_HOUR_DW[i] =
          VisionModel_ConstP.pooled12[i];
      }
    }

    /* end of Start for SubSystem: '<Root>/L_detector' */
  }
}

/*
 * File trailer for Real-Time Workshop generated code.
 *
 * [EOF]
 */
