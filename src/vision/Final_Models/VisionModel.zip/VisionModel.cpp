/*
 * File: VisionModel.cpp
 *
 * Real-Time Workshop code generated for Simulink model VisionModel.
 *
 * Model version                        : 1.430
 * Real-Time Workshop file version      : 7.6  (R2010b)  03-Aug-2010
 * Real-Time Workshop file generated on : Wed Jun 22 18:44:26 2011
 * TLC version                          : 7.6 (Jul 13 2010)
 * C/C++ source code generated on       : Wed Jun 22 18:44:26 2011
 *
 * Target selection: ert.tlc
 * Embedded hardware selection: 32-bit Generic
 * Code generation objectives: Unspecified
 * Validation result: Not run
 */

#include "VisionModel.h"
#include "VisionModel_private.h"

/* Block signals (auto storage) */
BlockIO_VisionModel VisionModel_B;

/* Block states (auto storage) */
D_Work_VisionModel VisionModel_DWork;

/* External inputs (root inport signals with auto storage) */
ExternalInputs_VisionModel VisionModel_U;

/* External outputs (root outports fed by signals with auto storage) */
ExternalOutputs_VisionModel VisionModel_Y;

/* Real-time model */
RT_MODEL_VisionModel VisionModel_M_;
RT_MODEL_VisionModel *VisionModel_M = &VisionModel_M_;

/* Model step function */
void VisionModel_step(void)
{
  real_T maxval[160];
  int32_T ix;
  int32_T iy;
  boolean_T b_searchingForNonNaN;
  boolean_T guard;
  boolean_T exitg;
  int32_T imgCol;
  real_T accumOne;
  real_T accumTwo;
  real_T accumThree;
  real_T accumFour;
  int32_T imgIdx_u;
  int32_T imgIdx_r;
  int32_T i;

  /* Outport: '<Root>/TargetSelect' */
  VisionModel_Y.TargetSelect = 0.0;

  /* Outport: '<Root>/TargetFound' */
  VisionModel_Y.TargetFound = 0.0;

  /* Outport: '<Root>/MaintainHeading' */
  VisionModel_Y.MaintainHeading = 0.0;

  /* Outport: '<Root>/TargetX' */
  VisionModel_Y.TargetX = 0.0;

  /* Outport: '<Root>/TargetY' */
  VisionModel_Y.TargetY = 0.0;

  /* Outport: '<Root>/TargetZ' */
  VisionModel_Y.TargetZ = 0.0;

  /* Outport: '<Root>/TargetYaw' */
  VisionModel_Y.TargetYaw = 0.0;

  /* Outport: '<Root>/DesiredTargetX' */
  VisionModel_Y.DesiredTargetX = 0.0;

  /* Outport: '<Root>/DesiredTargetY' */
  VisionModel_Y.DesiredTargetY = 0.0;

  /* Outport: '<Root>/DesiredTargetZ' */
  VisionModel_Y.DesiredTargetZ = 0.0;

  /* Outport: '<Root>/DesiredTargetYaw' */
  VisionModel_Y.DesiredTargetYaw = 0.0;

  /* Outport: '<Root>/MeasuredZ' */
  VisionModel_Y.MeasuredZ = 0.0;

  /* Outport: '<Root>/MeasuredYAccel' */
  VisionModel_Y.MeasuredYAccel = 0.0;

  /* Outport: '<Root>/MeasuredYaw' */
  VisionModel_Y.MeasuredYaw = 0.0;

  /* Outport: '<Root>/MeasuredYawRate' */
  VisionModel_Y.MeasuredYawRate = 0.0;

  /* Outport: '<Root>/DesiredZ' */
  VisionModel_Y.DesiredZ = 0.0;

  /* Outport: '<Root>/DesiredXVelocity' */
  VisionModel_Y.DesiredXVelocity = 0.0;

  /* Outport: '<Root>/DesiredYaw' */
  VisionModel_Y.DesiredYaw = 0.0;

  /* Outport: '<Root>/TargetDetected' */
  VisionModel_Y.TargetDetected = 0.0;

  /* Outport: '<Root>/PathState' */
  VisionModel_Y.PathState = 0.0;

  /* Outport: '<Root>/BuoyColors' */
  VisionModel_Y.BuoyColors = 0.0;

  /* Outport: '<Root>/FireAuthorization' */
  VisionModel_Y.FireAuthorization = 0.0;

  /* Outport: '<Root>/DummieVariable' */
  VisionModel_Y.DummieVariable = 0.0;

  /* Outport: '<Root>/R' */
  VisionModel_Y.R = 0.0;

  /* Outport: '<Root>/G' */
  VisionModel_Y.G = 0.0;

  /* Outport: '<Root>/B' */
  VisionModel_Y.B = 0.0;

  /* Outport: '<Root>/Iter_Segment_Thresh' */
  VisionModel_Y.Iter_Segment_Thresh = 0.0;

  /* Outport: '<Root>/theta' */
  VisionModel_Y.theta = 0.0;

  /* Outport: '<Root>/LabelMatrix' */
  VisionModel_Y.LabelMatrix = 0.0;

  /* Outport: '<Root>/num_colors' */
  VisionModel_Y.num_colors = 0.0;

  /* Outport: '<Root>/ref_colors' */
  VisionModel_Y.ref_colors = 0.0;

  /* Outport: '<Root>/bw_image' */
  VisionModel_Y.bw_image = 0.0;

  /* Embedded MATLAB: '<Root>/Transform Coordinates2' incorporates:
   *  Inport: '<Root>/B_forward_in'
   *  Inport: '<Root>/G_forward_in'
   *  Inport: '<Root>/R_forward_in'
   */
  /* Embedded MATLAB Function 'Transform Coordinates2': '<S2>:1' */
  /* '<S2>:1:3' */
  for (i = 0; i < 19200; i++) {
    VisionModel_B.intensityImageOut[i] = (VisionModel_U.R_forward_in[i] +
      VisionModel_U.G_forward_in[i]) + VisionModel_U.B_forward_in[i];
  }

  /* '<S2>:1:4' */
  ix = 0;
  iy = 0;
  for (imgCol = 0; imgCol < 160; imgCol++) {
    ix++;
    accumOne = VisionModel_B.intensityImageOut[ix - 1];
    imgIdx_r = 1;
    i = ix;
    guard = FALSE;
    if (rtIsNaN(VisionModel_B.intensityImageOut[ix - 1])) {
      b_searchingForNonNaN = TRUE;
      imgIdx_u = 2;
      exitg = FALSE;
      while (((uint32_T)exitg == 0U) && (imgIdx_u < 121)) {
        i++;
        if (!rtIsNaN(VisionModel_B.intensityImageOut[i - 1])) {
          accumOne = VisionModel_B.intensityImageOut[i - 1];
          imgIdx_r = imgIdx_u;
          b_searchingForNonNaN = FALSE;
          exitg = TRUE;
        } else {
          imgIdx_u++;
        }
      }

      if (!b_searchingForNonNaN) {
        guard = TRUE;
      }
    } else {
      guard = TRUE;
    }

    if (guard) {
      for (imgIdx_r++; imgIdx_r < 121; imgIdx_r++) {
        i++;
        if (VisionModel_B.intensityImageOut[i - 1] > accumOne) {
          accumOne = VisionModel_B.intensityImageOut[i - 1];
        }
      }
    }

    iy++;
    maxval[iy - 1] = accumOne;
    ix += 119;
  }

  accumOne = maxval[0];
  imgIdx_r = 1;
  ix = 1;
  guard = FALSE;
  if (rtIsNaN(maxval[0])) {
    b_searchingForNonNaN = TRUE;
    imgIdx_u = 2;
    exitg = FALSE;
    while (((uint32_T)exitg == 0U) && (imgIdx_u < 161)) {
      ix++;
      if (!rtIsNaN(maxval[ix - 1])) {
        accumOne = maxval[ix - 1];
        imgIdx_r = imgIdx_u;
        b_searchingForNonNaN = FALSE;
        exitg = TRUE;
      } else {
        imgIdx_u++;
      }
    }

    if (!b_searchingForNonNaN) {
      guard = TRUE;
    }
  } else {
    guard = TRUE;
  }

  if (guard) {
    for (imgIdx_r++; imgIdx_r < 161; imgIdx_r++) {
      ix++;
      if (maxval[ix - 1] > accumOne) {
        accumOne = maxval[ix - 1];
      }
    }
  }

  for (i = 0; i < 19200; i++) {
    VisionModel_B.intensityImageOut[i] = VisionModel_B.intensityImageOut[i] /
      accumOne;
  }

  /* { */
  /*  */
  /* [rows, cols] = size(R); */
  /*  */
  /* for r = 1:rows */
  /*     for c = 1:cols */
  /*          */
  /*         if( intensityImageOut(r,c) == 0 ) */
  /*             intensityImageOut(r,c) = 0; */
  /*         else */
  /*             intensityImageOut(r,c) = intensityImageOut(r,c)/max(max(intensityImageOut)); */
  /*         end */
  /*     end */
  /* end */
  /*  */
  /* return */
  /*  */
  /* } */

  /* S-Function (svipedge): '<Root>/Edge Detection' */
  for (imgCol = 1; imgCol < 159; imgCol++) {
    for (iy = 1; iy < 119; iy++) {
      accumOne = 0.0;
      accumTwo = 0.0;
      ix = imgCol * 120 + iy;
      for (i = 0; i < 6; i++) {
        accumOne += VisionModel_B.intensityImageOut[ix +
          VisionModel_DWork.EdgeDetection_VO_DW[i]] *
          VisionModel_ConstP.EdgeDetection_VC_RTP[i];
        accumTwo += VisionModel_B.intensityImageOut[ix +
          VisionModel_DWork.EdgeDetection_HO_DW[i]] *
          VisionModel_ConstP.EdgeDetection_HC_RTP[i];
      }

      VisionModel_DWork.EdgeDetection_GV_SQUARED_DW[ix] = accumOne * accumOne;
      VisionModel_DWork.EdgeDetection_GH_SQUARED_DW[ix] = accumTwo * accumTwo;
    }
  }

  for (imgCol = 1; imgCol < 159; imgCol++) {
    accumOne = 0.0;
    accumTwo = 0.0;
    accumThree = 0.0;
    accumFour = 0.0;
    imgIdx_u = imgCol * 120;
    ix = imgCol * 120 + 119;
    for (i = 0; i < 6; i++) {
      accumOne += VisionModel_B.intensityImageOut[imgIdx_u +
        VisionModel_DWork.EdgeDetection_HOU_DW[i]] *
        VisionModel_ConstP.EdgeDetection_HC_RTP[i];
      accumTwo += VisionModel_B.intensityImageOut[ix +
        VisionModel_DWork.EdgeDetection_HOD_DW[i]] *
        VisionModel_ConstP.EdgeDetection_HC_RTP[i];
      accumThree += VisionModel_B.intensityImageOut[imgIdx_u +
        VisionModel_DWork.EdgeDetection_VOU_DW[i]] *
        VisionModel_ConstP.EdgeDetection_VC_RTP[i];
      accumFour += VisionModel_B.intensityImageOut[ix +
        VisionModel_DWork.EdgeDetection_VOD_DW[i]] *
        VisionModel_ConstP.EdgeDetection_VC_RTP[i];
    }

    VisionModel_DWork.EdgeDetection_GV_SQUARED_DW[imgIdx_u] = accumThree *
      accumThree;
    VisionModel_DWork.EdgeDetection_GH_SQUARED_DW[imgIdx_u] = accumOne *
      accumOne;
    VisionModel_DWork.EdgeDetection_GV_SQUARED_DW[ix] = accumFour * accumFour;
    VisionModel_DWork.EdgeDetection_GH_SQUARED_DW[ix] = accumTwo * accumTwo;
  }

  for (iy = 1; iy < 119; iy++) {
    accumOne = 0.0;
    accumTwo = 0.0;
    accumThree = 0.0;
    accumFour = 0.0;
    imgIdx_r = 19080 + iy;
    for (i = 0; i < 6; i++) {
      accumOne += VisionModel_B.intensityImageOut[iy +
        VisionModel_DWork.EdgeDetection_VOL_DW[i]] *
        VisionModel_ConstP.EdgeDetection_VC_RTP[i];
      accumTwo += VisionModel_B.intensityImageOut[imgIdx_r +
        VisionModel_DWork.EdgeDetection_VOR_DW[i]] *
        VisionModel_ConstP.EdgeDetection_VC_RTP[i];
      accumThree += VisionModel_B.intensityImageOut[iy +
        VisionModel_DWork.EdgeDetection_HOL_DW[i]] *
        VisionModel_ConstP.EdgeDetection_HC_RTP[i];
      accumFour += VisionModel_B.intensityImageOut[imgIdx_r +
        VisionModel_DWork.EdgeDetection_HOR_DW[i]] *
        VisionModel_ConstP.EdgeDetection_HC_RTP[i];
    }

    VisionModel_DWork.EdgeDetection_GV_SQUARED_DW[iy] = accumOne * accumOne;
    VisionModel_DWork.EdgeDetection_GH_SQUARED_DW[iy] = accumThree * accumThree;
    VisionModel_DWork.EdgeDetection_GV_SQUARED_DW[imgIdx_r] = accumTwo *
      accumTwo;
    VisionModel_DWork.EdgeDetection_GH_SQUARED_DW[imgIdx_r] = accumFour *
      accumFour;
  }

  accumOne = 0.0;
  accumTwo = 0.0;
  accumThree = 0.0;
  accumFour = 0.0;
  for (i = 0; i < 6; i++) {
    accumOne +=
      VisionModel_B.intensityImageOut[VisionModel_DWork.EdgeDetection_VOUL_DW[i]]
      * VisionModel_ConstP.EdgeDetection_VC_RTP[i];
    accumTwo +=
      VisionModel_B.intensityImageOut[VisionModel_DWork.EdgeDetection_HOUL_DW[i]]
      * VisionModel_ConstP.EdgeDetection_HC_RTP[i];
    accumThree += VisionModel_B.intensityImageOut[119 +
      VisionModel_DWork.EdgeDetection_VOLL_DW[i]] *
      VisionModel_ConstP.EdgeDetection_VC_RTP[i];
    accumFour += VisionModel_B.intensityImageOut[119 +
      VisionModel_DWork.EdgeDetection_HOLL_DW[i]] *
      VisionModel_ConstP.EdgeDetection_HC_RTP[i];
  }

  VisionModel_DWork.EdgeDetection_GV_SQUARED_DW[0] = accumOne * accumOne;
  VisionModel_DWork.EdgeDetection_GH_SQUARED_DW[0] = accumTwo * accumTwo;
  VisionModel_DWork.EdgeDetection_GV_SQUARED_DW[119] = accumThree * accumThree;
  VisionModel_DWork.EdgeDetection_GH_SQUARED_DW[119] = accumFour * accumFour;
  accumOne = 0.0;
  accumTwo = 0.0;
  accumThree = 0.0;
  accumFour = 0.0;
  for (i = 0; i < 6; i++) {
    accumOne += VisionModel_B.intensityImageOut[19080 +
      VisionModel_DWork.EdgeDetection_VOUR_DW[i]] *
      VisionModel_ConstP.EdgeDetection_VC_RTP[i];
    accumTwo += VisionModel_B.intensityImageOut[19080 +
      VisionModel_DWork.EdgeDetection_HOUR_DW[i]] *
      VisionModel_ConstP.EdgeDetection_HC_RTP[i];
    accumThree += VisionModel_B.intensityImageOut[19199 +
      VisionModel_DWork.EdgeDetection_VOLR_DW[i]] *
      VisionModel_ConstP.EdgeDetection_VC_RTP[i];
    accumFour += VisionModel_B.intensityImageOut[19199 +
      VisionModel_DWork.EdgeDetection_HOLR_DW[i]] *
      VisionModel_ConstP.EdgeDetection_HC_RTP[i];
  }

  VisionModel_DWork.EdgeDetection_GV_SQUARED_DW[19080] = accumOne * accumOne;
  VisionModel_DWork.EdgeDetection_GH_SQUARED_DW[19080] = accumTwo * accumTwo;
  VisionModel_DWork.EdgeDetection_GV_SQUARED_DW[19199] = accumThree * accumThree;
  VisionModel_DWork.EdgeDetection_GH_SQUARED_DW[19199] = accumFour * accumFour;
  accumTwo = 0.0;
  for (i = 0; i < 19200; i++) {
    VisionModel_DWork.EdgeDetection_GRAD_SUM_DW[i] =
      VisionModel_DWork.EdgeDetection_GV_SQUARED_DW[i];
    VisionModel_DWork.EdgeDetection_GRAD_SUM_DW[i] =
      VisionModel_DWork.EdgeDetection_GRAD_SUM_DW[i] +
      VisionModel_DWork.EdgeDetection_GH_SQUARED_DW[i];
    accumTwo += VisionModel_DWork.EdgeDetection_GRAD_SUM_DW[i] *
      VisionModel_DWork.EdgeDetection_MEAN_FACTOR_DW;
  }

  accumOne = VisionModel_P.EdgeDetection_THRESH_TUNING_RTP * accumTwo;
  for (imgCol = 0; imgCol < 160; imgCol++) {
    for (iy = 0; iy < 120; iy++) {
      i = imgCol * 120 + iy;
      VisionModel_Y.edge_image[i] =
        ((VisionModel_DWork.EdgeDetection_GRAD_SUM_DW[i] > accumOne) &&
         (((VisionModel_DWork.EdgeDetection_GV_SQUARED_DW[i] >=
            VisionModel_DWork.EdgeDetection_GH_SQUARED_DW[i]) && (imgCol != 0 ?
            VisionModel_DWork.EdgeDetection_GRAD_SUM_DW[i - 120] <=
            VisionModel_DWork.EdgeDetection_GRAD_SUM_DW[i] : TRUE) && (imgCol !=
            159 ? VisionModel_DWork.EdgeDetection_GRAD_SUM_DW[i] >
            VisionModel_DWork.EdgeDetection_GRAD_SUM_DW[i + 120] : TRUE)) ||
          ((VisionModel_DWork.EdgeDetection_GH_SQUARED_DW[i] >=
            VisionModel_DWork.EdgeDetection_GV_SQUARED_DW[i]) && (iy != 0 ?
            VisionModel_DWork.EdgeDetection_GRAD_SUM_DW[i - 1] <=
            VisionModel_DWork.EdgeDetection_GRAD_SUM_DW[i] : TRUE) && (iy != 119
            ? VisionModel_DWork.EdgeDetection_GRAD_SUM_DW[i] >
            VisionModel_DWork.EdgeDetection_GRAD_SUM_DW[i + 1] : TRUE))));
    }
  }

  /* Embedded MATLAB: '<Root>/Transform Coordinates1' */
  /* Embedded MATLAB Function 'Transform Coordinates1': '<S1>:1' */
  /*  Ensure the image components are between 0 and newMax */
  /* '<S1>:1:10' */
}

/* Model initialize function */
void VisionModel_initialize(void)
{
  /* Registration code */

  /* initialize non-finites */
  rt_InitInfAndNaN(sizeof(real_T));

  /* initialize error status */
  rtmSetErrorStatus(VisionModel_M, (NULL));

  /* states (dwork) */
  (void) memset((void *)&VisionModel_DWork, 0,
                sizeof(D_Work_VisionModel));

  /* external inputs */
  (void) memset((void *)&VisionModel_U, 0,
                sizeof(ExternalInputs_VisionModel));

  /* external outputs */
  (void) memset((void *)&VisionModel_Y, 0,
                sizeof(ExternalOutputs_VisionModel));

  {
    int32_T nonZeroIdx;

    /* InitializeConditions for S-Function (svipedge): '<Root>/Edge Detection' */
    VisionModel_DWork.EdgeDetection_MEAN_FACTOR_DW = 5.2083333333333337E-5;
    for (nonZeroIdx = 0; nonZeroIdx < 6; nonZeroIdx++) {
      VisionModel_DWork.EdgeDetection_VO_DW[nonZeroIdx] =
        VisionModel_ConstP.EdgeDetection_VRO_RTP[nonZeroIdx] * 120 +
        VisionModel_ConstP.EdgeDetection_VCO_RTP[nonZeroIdx];
      if (VisionModel_ConstP.EdgeDetection_VCO_RTP[nonZeroIdx] > 0) {
        VisionModel_DWork.EdgeDetection_VOU_DW[nonZeroIdx] =
          VisionModel_ConstP.EdgeDetection_VRO_RTP[nonZeroIdx] * 120 +
          VisionModel_ConstP.EdgeDetection_VCO_RTP[nonZeroIdx];
        VisionModel_DWork.EdgeDetection_VOD_DW[nonZeroIdx] =
          VisionModel_ConstP.EdgeDetection_VRO_RTP[nonZeroIdx] * 120;
      } else {
        VisionModel_DWork.EdgeDetection_VOU_DW[nonZeroIdx] =
          VisionModel_ConstP.EdgeDetection_VRO_RTP[nonZeroIdx] * 120;
        VisionModel_DWork.EdgeDetection_VOD_DW[nonZeroIdx] =
          VisionModel_ConstP.EdgeDetection_VRO_RTP[nonZeroIdx] * 120 +
          VisionModel_ConstP.EdgeDetection_VCO_RTP[nonZeroIdx];
      }

      if (VisionModel_ConstP.EdgeDetection_VRO_RTP[nonZeroIdx] > 0) {
        VisionModel_DWork.EdgeDetection_VOL_DW[nonZeroIdx] =
          VisionModel_ConstP.EdgeDetection_VRO_RTP[nonZeroIdx] * 120 +
          VisionModel_ConstP.EdgeDetection_VCO_RTP[nonZeroIdx];
        VisionModel_DWork.EdgeDetection_VOR_DW[nonZeroIdx] =
          VisionModel_ConstP.EdgeDetection_VCO_RTP[nonZeroIdx];
      } else {
        VisionModel_DWork.EdgeDetection_VOL_DW[nonZeroIdx] =
          VisionModel_ConstP.EdgeDetection_VCO_RTP[nonZeroIdx];
        VisionModel_DWork.EdgeDetection_VOR_DW[nonZeroIdx] =
          VisionModel_ConstP.EdgeDetection_VRO_RTP[nonZeroIdx] * 120 +
          VisionModel_ConstP.EdgeDetection_VCO_RTP[nonZeroIdx];
      }

      if ((VisionModel_ConstP.EdgeDetection_VCO_RTP[nonZeroIdx] < 0) &&
          (VisionModel_ConstP.EdgeDetection_VRO_RTP[nonZeroIdx] < 0)) {
        VisionModel_DWork.EdgeDetection_VOUL_DW[nonZeroIdx] = 0;
        VisionModel_DWork.EdgeDetection_VOLR_DW[nonZeroIdx] =
          VisionModel_ConstP.EdgeDetection_VRO_RTP[nonZeroIdx] * 120 +
          VisionModel_ConstP.EdgeDetection_VCO_RTP[nonZeroIdx];
        VisionModel_DWork.EdgeDetection_VOLL_DW[nonZeroIdx] =
          VisionModel_ConstP.EdgeDetection_VCO_RTP[nonZeroIdx];
        VisionModel_DWork.EdgeDetection_VOUR_DW[nonZeroIdx] =
          VisionModel_ConstP.EdgeDetection_VRO_RTP[nonZeroIdx] * 120;
      }

      if ((VisionModel_ConstP.EdgeDetection_VCO_RTP[nonZeroIdx] >= 0) &&
          (VisionModel_ConstP.EdgeDetection_VRO_RTP[nonZeroIdx] < 0)) {
        VisionModel_DWork.EdgeDetection_VOLL_DW[nonZeroIdx] = 0;
        VisionModel_DWork.EdgeDetection_VOUR_DW[nonZeroIdx] =
          VisionModel_ConstP.EdgeDetection_VRO_RTP[nonZeroIdx] * 120 +
          VisionModel_ConstP.EdgeDetection_VCO_RTP[nonZeroIdx];
        VisionModel_DWork.EdgeDetection_VOUL_DW[nonZeroIdx] =
          VisionModel_ConstP.EdgeDetection_VCO_RTP[nonZeroIdx];
        VisionModel_DWork.EdgeDetection_VOLR_DW[nonZeroIdx] =
          VisionModel_ConstP.EdgeDetection_VRO_RTP[nonZeroIdx] * 120;
      }

      if ((VisionModel_ConstP.EdgeDetection_VCO_RTP[nonZeroIdx] < 0) &&
          (VisionModel_ConstP.EdgeDetection_VRO_RTP[nonZeroIdx] >= 0)) {
        VisionModel_DWork.EdgeDetection_VOUR_DW[nonZeroIdx] = 0;
        VisionModel_DWork.EdgeDetection_VOLL_DW[nonZeroIdx] =
          VisionModel_ConstP.EdgeDetection_VRO_RTP[nonZeroIdx] * 120 +
          VisionModel_ConstP.EdgeDetection_VCO_RTP[nonZeroIdx];
        VisionModel_DWork.EdgeDetection_VOUL_DW[nonZeroIdx] =
          VisionModel_ConstP.EdgeDetection_VRO_RTP[nonZeroIdx] * 120;
        VisionModel_DWork.EdgeDetection_VOLR_DW[nonZeroIdx] =
          VisionModel_ConstP.EdgeDetection_VCO_RTP[nonZeroIdx];
      }

      if ((VisionModel_ConstP.EdgeDetection_VCO_RTP[nonZeroIdx] >= 0) &&
          (VisionModel_ConstP.EdgeDetection_VRO_RTP[nonZeroIdx] >= 0)) {
        VisionModel_DWork.EdgeDetection_VOLR_DW[nonZeroIdx] = 0;
        VisionModel_DWork.EdgeDetection_VOUL_DW[nonZeroIdx] =
          VisionModel_ConstP.EdgeDetection_VRO_RTP[nonZeroIdx] * 120 +
          VisionModel_ConstP.EdgeDetection_VCO_RTP[nonZeroIdx];
        VisionModel_DWork.EdgeDetection_VOLL_DW[nonZeroIdx] =
          VisionModel_ConstP.EdgeDetection_VRO_RTP[nonZeroIdx] * 120;
        VisionModel_DWork.EdgeDetection_VOUR_DW[nonZeroIdx] =
          VisionModel_ConstP.EdgeDetection_VCO_RTP[nonZeroIdx];
      }

      VisionModel_DWork.EdgeDetection_HO_DW[nonZeroIdx] =
        VisionModel_ConstP.EdgeDetection_HRO_RTP[nonZeroIdx] * 120 +
        VisionModel_ConstP.EdgeDetection_HCO_RTP[nonZeroIdx];
      if (VisionModel_ConstP.EdgeDetection_HCO_RTP[nonZeroIdx] > 0) {
        VisionModel_DWork.EdgeDetection_HOU_DW[nonZeroIdx] =
          VisionModel_ConstP.EdgeDetection_HRO_RTP[nonZeroIdx] * 120 +
          VisionModel_ConstP.EdgeDetection_HCO_RTP[nonZeroIdx];
        VisionModel_DWork.EdgeDetection_HOD_DW[nonZeroIdx] =
          VisionModel_ConstP.EdgeDetection_HRO_RTP[nonZeroIdx] * 120;
      } else {
        VisionModel_DWork.EdgeDetection_HOU_DW[nonZeroIdx] =
          VisionModel_ConstP.EdgeDetection_HRO_RTP[nonZeroIdx] * 120;
        VisionModel_DWork.EdgeDetection_HOD_DW[nonZeroIdx] =
          VisionModel_ConstP.EdgeDetection_HRO_RTP[nonZeroIdx] * 120 +
          VisionModel_ConstP.EdgeDetection_HCO_RTP[nonZeroIdx];
      }

      if (VisionModel_ConstP.EdgeDetection_HRO_RTP[nonZeroIdx] > 0) {
        VisionModel_DWork.EdgeDetection_HOL_DW[nonZeroIdx] =
          VisionModel_ConstP.EdgeDetection_HRO_RTP[nonZeroIdx] * 120 +
          VisionModel_ConstP.EdgeDetection_HCO_RTP[nonZeroIdx];
        VisionModel_DWork.EdgeDetection_HOR_DW[nonZeroIdx] =
          VisionModel_ConstP.EdgeDetection_HCO_RTP[nonZeroIdx];
      } else {
        VisionModel_DWork.EdgeDetection_HOL_DW[nonZeroIdx] =
          VisionModel_ConstP.EdgeDetection_HCO_RTP[nonZeroIdx];
        VisionModel_DWork.EdgeDetection_HOR_DW[nonZeroIdx] =
          VisionModel_ConstP.EdgeDetection_HRO_RTP[nonZeroIdx] * 120 +
          VisionModel_ConstP.EdgeDetection_HCO_RTP[nonZeroIdx];
      }

      if ((VisionModel_ConstP.EdgeDetection_HCO_RTP[nonZeroIdx] < 0) &&
          (VisionModel_ConstP.EdgeDetection_HRO_RTP[nonZeroIdx] < 0)) {
        VisionModel_DWork.EdgeDetection_HOUL_DW[nonZeroIdx] = 0;
        VisionModel_DWork.EdgeDetection_HOLR_DW[nonZeroIdx] =
          VisionModel_ConstP.EdgeDetection_HRO_RTP[nonZeroIdx] * 120 +
          VisionModel_ConstP.EdgeDetection_HCO_RTP[nonZeroIdx];
        VisionModel_DWork.EdgeDetection_HOLL_DW[nonZeroIdx] =
          VisionModel_ConstP.EdgeDetection_HCO_RTP[nonZeroIdx];
        VisionModel_DWork.EdgeDetection_HOUR_DW[nonZeroIdx] =
          VisionModel_ConstP.EdgeDetection_HRO_RTP[nonZeroIdx] * 120;
      }

      if ((VisionModel_ConstP.EdgeDetection_HCO_RTP[nonZeroIdx] >= 0) &&
          (VisionModel_ConstP.EdgeDetection_HRO_RTP[nonZeroIdx] < 0)) {
        VisionModel_DWork.EdgeDetection_HOLL_DW[nonZeroIdx] = 0;
        VisionModel_DWork.EdgeDetection_HOUR_DW[nonZeroIdx] =
          VisionModel_ConstP.EdgeDetection_HRO_RTP[nonZeroIdx] * 120 +
          VisionModel_ConstP.EdgeDetection_HCO_RTP[nonZeroIdx];
        VisionModel_DWork.EdgeDetection_HOUL_DW[nonZeroIdx] =
          VisionModel_ConstP.EdgeDetection_HCO_RTP[nonZeroIdx];
        VisionModel_DWork.EdgeDetection_HOLR_DW[nonZeroIdx] =
          VisionModel_ConstP.EdgeDetection_HRO_RTP[nonZeroIdx] * 120;
      }

      if ((VisionModel_ConstP.EdgeDetection_HCO_RTP[nonZeroIdx] < 0) &&
          (VisionModel_ConstP.EdgeDetection_HRO_RTP[nonZeroIdx] >= 0)) {
        VisionModel_DWork.EdgeDetection_HOUR_DW[nonZeroIdx] = 0;
        VisionModel_DWork.EdgeDetection_HOLL_DW[nonZeroIdx] =
          VisionModel_ConstP.EdgeDetection_HRO_RTP[nonZeroIdx] * 120 +
          VisionModel_ConstP.EdgeDetection_HCO_RTP[nonZeroIdx];
        VisionModel_DWork.EdgeDetection_HOUL_DW[nonZeroIdx] =
          VisionModel_ConstP.EdgeDetection_HRO_RTP[nonZeroIdx] * 120;
        VisionModel_DWork.EdgeDetection_HOLR_DW[nonZeroIdx] =
          VisionModel_ConstP.EdgeDetection_HCO_RTP[nonZeroIdx];
      }

      if ((VisionModel_ConstP.EdgeDetection_HCO_RTP[nonZeroIdx] >= 0) &&
          (VisionModel_ConstP.EdgeDetection_HRO_RTP[nonZeroIdx] >= 0)) {
        VisionModel_DWork.EdgeDetection_HOLR_DW[nonZeroIdx] = 0;
        VisionModel_DWork.EdgeDetection_HOUL_DW[nonZeroIdx] =
          VisionModel_ConstP.EdgeDetection_HRO_RTP[nonZeroIdx] * 120 +
          VisionModel_ConstP.EdgeDetection_HCO_RTP[nonZeroIdx];
        VisionModel_DWork.EdgeDetection_HOLL_DW[nonZeroIdx] =
          VisionModel_ConstP.EdgeDetection_HRO_RTP[nonZeroIdx] * 120;
        VisionModel_DWork.EdgeDetection_HOUR_DW[nonZeroIdx] =
          VisionModel_ConstP.EdgeDetection_HCO_RTP[nonZeroIdx];
      }
    }
  }
}

/*
 * File trailer for Real-Time Workshop generated code.
 *
 * [EOF]
 */
