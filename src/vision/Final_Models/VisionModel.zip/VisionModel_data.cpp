/*
 * File: VisionModel_data.cpp
 *
 * Real-Time Workshop code generated for Simulink model VisionModel.
 *
 * Model version                        : 1.430
 * Real-Time Workshop file version      : 7.6  (R2010b)  03-Aug-2010
 * Real-Time Workshop file generated on : Wed Jun 22 18:44:26 2011
 * TLC version                          : 7.6 (Jul 13 2010)
 * C/C++ source code generated on       : Wed Jun 22 18:44:26 2011
 *
 * Target selection: ert.tlc
 * Embedded hardware selection: 32-bit Generic
 * Code generation objectives: Unspecified
 * Validation result: Not run
 */

#include "VisionModel.h"
#include "VisionModel_private.h"

/* Block parameters (auto storage) */
Parameters_VisionModel VisionModel_P = {
  3.0                                  /* Expression: thresholdTuning
                                        * Referenced by: '<Root>/Edge Detection'
                                        */
};

/* Constant parameters (auto storage) */
const ConstParam_VisionModel VisionModel_ConstP = {
  /* Computed Parameter: EdgeDetection_VC_RTP
   * Referenced by: '<Root>/Edge Detection'
   */
  { 0.125, 0.25, 0.125, -0.125, -0.25, -0.125 },

  /* Computed Parameter: EdgeDetection_HC_RTP
   * Referenced by: '<Root>/Edge Detection'
   */
  { 0.125, -0.125, 0.25, -0.25, 0.125, -0.125 },

  /* Computed Parameter: EdgeDetection_VRO_RTP
   * Referenced by: '<Root>/Edge Detection'
   */
  { -1, -1, -1, 1, 1, 1 },

  /* Computed Parameter: EdgeDetection_VCO_RTP
   * Referenced by: '<Root>/Edge Detection'
   */
  { -1, 0, 1, -1, 0, 1 },

  /* Computed Parameter: EdgeDetection_HRO_RTP
   * Referenced by: '<Root>/Edge Detection'
   */
  { -1, -1, 0, 0, 1, 1 },

  /* Computed Parameter: EdgeDetection_HCO_RTP
   * Referenced by: '<Root>/Edge Detection'
   */
  { -1, 1, -1, 1, -1, 1 }
};

/*
 * File trailer for Real-Time Workshop generated code.
 *
 * [EOF]
 */
