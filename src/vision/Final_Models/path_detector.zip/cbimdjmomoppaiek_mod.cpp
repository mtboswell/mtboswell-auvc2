/*
 * File: /home/auvt/auvc/src/vision/Final_Models/slprj/ert/_sharedutils/cbimdjmomoppaiek_mod.cpp
 *
 * Real-Time Workshop code generated for Simulink model L_detector.
 *
 * Model version                        : 1.1365
 * Real-Time Workshop file version      : 7.6  (R2010b)  03-Aug-2010
 * Real-Time Workshop file generated on : Wed Jun 29 18:16:50 2011
 * TLC version                          : 7.6 (Jul 13 2010)
 * C/C++ source code generated on       : Wed Jun 29 18:16:50 2011
 */

#include "rtwtypes.h"
#include "rtw_shared_utils.h"
#include <math.h>

/* Function for Embedded MATLAB: '<Root>/Identify L-Obstacle' */
real_T cbimdjmomoppaiek_mod(real_T x, real_T y)
{
  real_T r;
  real_T b_x;
  if (y == 0.0) {
    return x;
  } else if (y == floor(y)) {
    return x - floor(x / y) * y;
  } else {
    r = x / y;
    if (r < 0.0) {
      b_x = ceil(r - 0.5);
    } else {
      b_x = floor(r + 0.5);
    }

    if (fabs(r - b_x) <= 2.2204460492503131E-16 * fabs(r)) {
      return 0.0;
    } else {
      return (r - floor(r)) * y;
    }
  }
}

/*
 * File trailer for Real-Time Workshop generated code.
 *
 * [EOF]
 */
