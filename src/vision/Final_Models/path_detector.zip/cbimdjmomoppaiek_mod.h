/*
 * File: /home/auvt/auvc/src/vision/Final_Models/slprj/ert/_sharedutils/cbimdjmomoppaiek_mod.h
 *
 * Real-Time Workshop code generated for Simulink model L_detector.
 *
 * Model version                        : 1.1365
 * Real-Time Workshop file version      : 7.6  (R2010b)  03-Aug-2010
 * Real-Time Workshop file generated on : Wed Jun 29 18:16:50 2011
 * TLC version                          : 7.6 (Jul 13 2010)
 * C/C++ source code generated on       : Wed Jun 29 18:16:50 2011
 */

#ifndef SHARE_cbimdjmomoppaiek_mod
#define SHARE_cbimdjmomoppaiek_mod

extern real_T cbimdjmomoppaiek_mod(real_T x, real_T y);

#endif

/*
 * File trailer for Real-Time Workshop generated code.
 *
 * [EOF]
 */
