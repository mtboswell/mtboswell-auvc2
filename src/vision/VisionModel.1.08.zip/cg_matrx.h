/* Copyright 1994-2002 The MathWorks, Inc.
 *
 * File    : cg_matrx.h      $Revision: 1.1.10.1 $ $Date: 2007/03/03 04:17:35 $
 * Abstract:
 *	Provided for backwards compatibility. See rt_matrx.h for details.
 */

#include "rt_matrx.h"

/* [EOF] cg_matrx.h */
