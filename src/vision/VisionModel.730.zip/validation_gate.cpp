/*
 * File: validation_gate.cpp
 *
 * Real-Time Workshop code generated for Simulink model validation_gate.
 *
 * Model version                        : 1.1219
 * Real-Time Workshop file version      : 7.6  (R2010b)  03-Aug-2010
 * Real-Time Workshop file generated on : Wed Jun 22 19:28:55 2011
 * TLC version                          : 7.6 (Jul 13 2010)
 * C/C++ source code generated on       : Wed Jun 22 19:28:55 2011
 *
 * Target selection: ert.tlc
 * Embedded hardware selection: 32-bit Generic
 * Code generation objectives: Unspecified
 * Validation result: Not run
 */

#include "validation_gate.h"
#include "validation_gate_private.h"

/* Initial conditions for referenced model: 'validation_gate' */
void mr_validation_gate_Init(rtDW_mr_validation_gate *localDW)
{
  int32_T nonZeroIdx;

  /* InitializeConditions for S-Function (svipedge): '<Root>/Edge Detection' */
  localDW->EdgeDetection_MEAN_FACTOR_DW = 5.2083333333333337E-5;
  for (nonZeroIdx = 0; nonZeroIdx < 6; nonZeroIdx++) {
    localDW->EdgeDetection_VO_DW[nonZeroIdx] =
      validation_gate_ConstP.EdgeDetection_VRO_RTP[nonZeroIdx] * 160 +
      validation_gate_ConstP.EdgeDetection_VCO_RTP[nonZeroIdx];
    if (validation_gate_ConstP.EdgeDetection_VCO_RTP[nonZeroIdx] > 0) {
      localDW->EdgeDetection_VOU_DW[nonZeroIdx] =
        validation_gate_ConstP.EdgeDetection_VRO_RTP[nonZeroIdx] * 160 +
        validation_gate_ConstP.EdgeDetection_VCO_RTP[nonZeroIdx];
      localDW->EdgeDetection_VOD_DW[nonZeroIdx] =
        validation_gate_ConstP.EdgeDetection_VRO_RTP[nonZeroIdx] * 160;
    } else {
      localDW->EdgeDetection_VOU_DW[nonZeroIdx] =
        validation_gate_ConstP.EdgeDetection_VRO_RTP[nonZeroIdx] * 160;
      localDW->EdgeDetection_VOD_DW[nonZeroIdx] =
        validation_gate_ConstP.EdgeDetection_VRO_RTP[nonZeroIdx] * 160 +
        validation_gate_ConstP.EdgeDetection_VCO_RTP[nonZeroIdx];
    }

    if (validation_gate_ConstP.EdgeDetection_VRO_RTP[nonZeroIdx] > 0) {
      localDW->EdgeDetection_VOL_DW[nonZeroIdx] =
        validation_gate_ConstP.EdgeDetection_VRO_RTP[nonZeroIdx] * 160 +
        validation_gate_ConstP.EdgeDetection_VCO_RTP[nonZeroIdx];
      localDW->EdgeDetection_VOR_DW[nonZeroIdx] =
        validation_gate_ConstP.EdgeDetection_VCO_RTP[nonZeroIdx];
    } else {
      localDW->EdgeDetection_VOL_DW[nonZeroIdx] =
        validation_gate_ConstP.EdgeDetection_VCO_RTP[nonZeroIdx];
      localDW->EdgeDetection_VOR_DW[nonZeroIdx] =
        validation_gate_ConstP.EdgeDetection_VRO_RTP[nonZeroIdx] * 160 +
        validation_gate_ConstP.EdgeDetection_VCO_RTP[nonZeroIdx];
    }

    if ((validation_gate_ConstP.EdgeDetection_VCO_RTP[nonZeroIdx] < 0) &&
        (validation_gate_ConstP.EdgeDetection_VRO_RTP[nonZeroIdx] < 0)) {
      localDW->EdgeDetection_VOUL_DW[nonZeroIdx] = 0;
      localDW->EdgeDetection_VOLR_DW[nonZeroIdx] =
        validation_gate_ConstP.EdgeDetection_VRO_RTP[nonZeroIdx] * 160 +
        validation_gate_ConstP.EdgeDetection_VCO_RTP[nonZeroIdx];
      localDW->EdgeDetection_VOLL_DW[nonZeroIdx] =
        validation_gate_ConstP.EdgeDetection_VCO_RTP[nonZeroIdx];
      localDW->EdgeDetection_VOUR_DW[nonZeroIdx] =
        validation_gate_ConstP.EdgeDetection_VRO_RTP[nonZeroIdx] * 160;
    }

    if ((validation_gate_ConstP.EdgeDetection_VCO_RTP[nonZeroIdx] >= 0) &&
        (validation_gate_ConstP.EdgeDetection_VRO_RTP[nonZeroIdx] < 0)) {
      localDW->EdgeDetection_VOLL_DW[nonZeroIdx] = 0;
      localDW->EdgeDetection_VOUR_DW[nonZeroIdx] =
        validation_gate_ConstP.EdgeDetection_VRO_RTP[nonZeroIdx] * 160 +
        validation_gate_ConstP.EdgeDetection_VCO_RTP[nonZeroIdx];
      localDW->EdgeDetection_VOUL_DW[nonZeroIdx] =
        validation_gate_ConstP.EdgeDetection_VCO_RTP[nonZeroIdx];
      localDW->EdgeDetection_VOLR_DW[nonZeroIdx] =
        validation_gate_ConstP.EdgeDetection_VRO_RTP[nonZeroIdx] * 160;
    }

    if ((validation_gate_ConstP.EdgeDetection_VCO_RTP[nonZeroIdx] < 0) &&
        (validation_gate_ConstP.EdgeDetection_VRO_RTP[nonZeroIdx] >= 0)) {
      localDW->EdgeDetection_VOUR_DW[nonZeroIdx] = 0;
      localDW->EdgeDetection_VOLL_DW[nonZeroIdx] =
        validation_gate_ConstP.EdgeDetection_VRO_RTP[nonZeroIdx] * 160 +
        validation_gate_ConstP.EdgeDetection_VCO_RTP[nonZeroIdx];
      localDW->EdgeDetection_VOUL_DW[nonZeroIdx] =
        validation_gate_ConstP.EdgeDetection_VRO_RTP[nonZeroIdx] * 160;
      localDW->EdgeDetection_VOLR_DW[nonZeroIdx] =
        validation_gate_ConstP.EdgeDetection_VCO_RTP[nonZeroIdx];
    }

    if ((validation_gate_ConstP.EdgeDetection_VCO_RTP[nonZeroIdx] >= 0) &&
        (validation_gate_ConstP.EdgeDetection_VRO_RTP[nonZeroIdx] >= 0)) {
      localDW->EdgeDetection_VOLR_DW[nonZeroIdx] = 0;
      localDW->EdgeDetection_VOUL_DW[nonZeroIdx] =
        validation_gate_ConstP.EdgeDetection_VRO_RTP[nonZeroIdx] * 160 +
        validation_gate_ConstP.EdgeDetection_VCO_RTP[nonZeroIdx];
      localDW->EdgeDetection_VOLL_DW[nonZeroIdx] =
        validation_gate_ConstP.EdgeDetection_VRO_RTP[nonZeroIdx] * 160;
      localDW->EdgeDetection_VOUR_DW[nonZeroIdx] =
        validation_gate_ConstP.EdgeDetection_VCO_RTP[nonZeroIdx];
    }

    localDW->EdgeDetection_HO_DW[nonZeroIdx] =
      validation_gate_ConstP.EdgeDetection_HRO_RTP[nonZeroIdx] * 160 +
      validation_gate_ConstP.EdgeDetection_HCO_RTP[nonZeroIdx];
    if (validation_gate_ConstP.EdgeDetection_HCO_RTP[nonZeroIdx] > 0) {
      localDW->EdgeDetection_HOU_DW[nonZeroIdx] =
        validation_gate_ConstP.EdgeDetection_HRO_RTP[nonZeroIdx] * 160 +
        validation_gate_ConstP.EdgeDetection_HCO_RTP[nonZeroIdx];
      localDW->EdgeDetection_HOD_DW[nonZeroIdx] =
        validation_gate_ConstP.EdgeDetection_HRO_RTP[nonZeroIdx] * 160;
    } else {
      localDW->EdgeDetection_HOU_DW[nonZeroIdx] =
        validation_gate_ConstP.EdgeDetection_HRO_RTP[nonZeroIdx] * 160;
      localDW->EdgeDetection_HOD_DW[nonZeroIdx] =
        validation_gate_ConstP.EdgeDetection_HRO_RTP[nonZeroIdx] * 160 +
        validation_gate_ConstP.EdgeDetection_HCO_RTP[nonZeroIdx];
    }

    if (validation_gate_ConstP.EdgeDetection_HRO_RTP[nonZeroIdx] > 0) {
      localDW->EdgeDetection_HOL_DW[nonZeroIdx] =
        validation_gate_ConstP.EdgeDetection_HRO_RTP[nonZeroIdx] * 160 +
        validation_gate_ConstP.EdgeDetection_HCO_RTP[nonZeroIdx];
      localDW->EdgeDetection_HOR_DW[nonZeroIdx] =
        validation_gate_ConstP.EdgeDetection_HCO_RTP[nonZeroIdx];
    } else {
      localDW->EdgeDetection_HOL_DW[nonZeroIdx] =
        validation_gate_ConstP.EdgeDetection_HCO_RTP[nonZeroIdx];
      localDW->EdgeDetection_HOR_DW[nonZeroIdx] =
        validation_gate_ConstP.EdgeDetection_HRO_RTP[nonZeroIdx] * 160 +
        validation_gate_ConstP.EdgeDetection_HCO_RTP[nonZeroIdx];
    }

    if ((validation_gate_ConstP.EdgeDetection_HCO_RTP[nonZeroIdx] < 0) &&
        (validation_gate_ConstP.EdgeDetection_HRO_RTP[nonZeroIdx] < 0)) {
      localDW->EdgeDetection_HOUL_DW[nonZeroIdx] = 0;
      localDW->EdgeDetection_HOLR_DW[nonZeroIdx] =
        validation_gate_ConstP.EdgeDetection_HRO_RTP[nonZeroIdx] * 160 +
        validation_gate_ConstP.EdgeDetection_HCO_RTP[nonZeroIdx];
      localDW->EdgeDetection_HOLL_DW[nonZeroIdx] =
        validation_gate_ConstP.EdgeDetection_HCO_RTP[nonZeroIdx];
      localDW->EdgeDetection_HOUR_DW[nonZeroIdx] =
        validation_gate_ConstP.EdgeDetection_HRO_RTP[nonZeroIdx] * 160;
    }

    if ((validation_gate_ConstP.EdgeDetection_HCO_RTP[nonZeroIdx] >= 0) &&
        (validation_gate_ConstP.EdgeDetection_HRO_RTP[nonZeroIdx] < 0)) {
      localDW->EdgeDetection_HOLL_DW[nonZeroIdx] = 0;
      localDW->EdgeDetection_HOUR_DW[nonZeroIdx] =
        validation_gate_ConstP.EdgeDetection_HRO_RTP[nonZeroIdx] * 160 +
        validation_gate_ConstP.EdgeDetection_HCO_RTP[nonZeroIdx];
      localDW->EdgeDetection_HOUL_DW[nonZeroIdx] =
        validation_gate_ConstP.EdgeDetection_HCO_RTP[nonZeroIdx];
      localDW->EdgeDetection_HOLR_DW[nonZeroIdx] =
        validation_gate_ConstP.EdgeDetection_HRO_RTP[nonZeroIdx] * 160;
    }

    if ((validation_gate_ConstP.EdgeDetection_HCO_RTP[nonZeroIdx] < 0) &&
        (validation_gate_ConstP.EdgeDetection_HRO_RTP[nonZeroIdx] >= 0)) {
      localDW->EdgeDetection_HOUR_DW[nonZeroIdx] = 0;
      localDW->EdgeDetection_HOLL_DW[nonZeroIdx] =
        validation_gate_ConstP.EdgeDetection_HRO_RTP[nonZeroIdx] * 160 +
        validation_gate_ConstP.EdgeDetection_HCO_RTP[nonZeroIdx];
      localDW->EdgeDetection_HOUL_DW[nonZeroIdx] =
        validation_gate_ConstP.EdgeDetection_HRO_RTP[nonZeroIdx] * 160;
      localDW->EdgeDetection_HOLR_DW[nonZeroIdx] =
        validation_gate_ConstP.EdgeDetection_HCO_RTP[nonZeroIdx];
    }

    if ((validation_gate_ConstP.EdgeDetection_HCO_RTP[nonZeroIdx] >= 0) &&
        (validation_gate_ConstP.EdgeDetection_HRO_RTP[nonZeroIdx] >= 0)) {
      localDW->EdgeDetection_HOLR_DW[nonZeroIdx] = 0;
      localDW->EdgeDetection_HOUL_DW[nonZeroIdx] =
        validation_gate_ConstP.EdgeDetection_HRO_RTP[nonZeroIdx] * 160 +
        validation_gate_ConstP.EdgeDetection_HCO_RTP[nonZeroIdx];
      localDW->EdgeDetection_HOLL_DW[nonZeroIdx] =
        validation_gate_ConstP.EdgeDetection_HRO_RTP[nonZeroIdx] * 160;
      localDW->EdgeDetection_HOUR_DW[nonZeroIdx] =
        validation_gate_ConstP.EdgeDetection_HCO_RTP[nonZeroIdx];
    }
  }
}

/* Output and update for referenced model: 'validation_gate' */
void mr_validation_gate(const real_T rtu_R_forward_in[19200], const real_T
  rtu_G_forward_in[19200], const real_T rtu_B_forward_in[19200], boolean_T
  rty_edge_image[19200], rtB_mr_validation_gate *localB, rtDW_mr_validation_gate
  *localDW)
{
  real_T maxval[120];
  int32_T ix;
  int32_T iy;
  boolean_T b_searchingForNonNaN;
  boolean_T guard;
  boolean_T exitg;
  int32_T imgCol;
  real_T accumOne;
  real_T accumTwo;
  real_T accumThree;
  real_T accumFour;
  int32_T imgIdx_u;
  int32_T imgIdx_r;
  int32_T i;

  /* Embedded MATLAB: '<Root>/Transform Coordinates2' */
  /* Embedded MATLAB Function 'Transform Coordinates2': '<S1>:1' */
  /* '<S1>:1:3' */
  for (i = 0; i < 19200; i++) {
    localB->intensityImageOut[i] = (rtu_R_forward_in[i] + rtu_G_forward_in[i]) +
      rtu_B_forward_in[i];
  }

  /* '<S1>:1:4' */
  ix = 0;
  iy = 0;
  for (imgCol = 0; imgCol < 120; imgCol++) {
    ix++;
    accumOne = localB->intensityImageOut[ix - 1];
    imgIdx_r = 1;
    i = ix;
    guard = FALSE;
    if (rtIsNaN(localB->intensityImageOut[ix - 1])) {
      b_searchingForNonNaN = TRUE;
      imgIdx_u = 2;
      exitg = FALSE;
      while (((uint32_T)exitg == 0U) && (imgIdx_u < 161)) {
        i++;
        if (!rtIsNaN(localB->intensityImageOut[i - 1])) {
          accumOne = localB->intensityImageOut[i - 1];
          imgIdx_r = imgIdx_u;
          b_searchingForNonNaN = FALSE;
          exitg = TRUE;
        } else {
          imgIdx_u++;
        }
      }

      if (!b_searchingForNonNaN) {
        guard = TRUE;
      }
    } else {
      guard = TRUE;
    }

    if (guard) {
      for (imgIdx_r++; imgIdx_r < 161; imgIdx_r++) {
        i++;
        if (localB->intensityImageOut[i - 1] > accumOne) {
          accumOne = localB->intensityImageOut[i - 1];
        }
      }
    }

    iy++;
    maxval[iy - 1] = accumOne;
    ix += 159;
  }

  accumOne = maxval[0];
  imgIdx_r = 1;
  ix = 1;
  guard = FALSE;
  if (rtIsNaN(maxval[0])) {
    b_searchingForNonNaN = TRUE;
    imgIdx_u = 2;
    exitg = FALSE;
    while (((uint32_T)exitg == 0U) && (imgIdx_u < 121)) {
      ix++;
      if (!rtIsNaN(maxval[ix - 1])) {
        accumOne = maxval[ix - 1];
        imgIdx_r = imgIdx_u;
        b_searchingForNonNaN = FALSE;
        exitg = TRUE;
      } else {
        imgIdx_u++;
      }
    }

    if (!b_searchingForNonNaN) {
      guard = TRUE;
    }
  } else {
    guard = TRUE;
  }

  if (guard) {
    for (imgIdx_r++; imgIdx_r < 121; imgIdx_r++) {
      ix++;
      if (maxval[ix - 1] > accumOne) {
        accumOne = maxval[ix - 1];
      }
    }
  }

  for (i = 0; i < 19200; i++) {
    localB->intensityImageOut[i] = localB->intensityImageOut[i] / accumOne;
  }

  /* { */
  /*  */
  /* [rows, cols] = size(R); */
  /*  */
  /* for r = 1:rows */
  /*     for c = 1:cols */
  /*          */
  /*         if( intensityImageOut(r,c) == 0 ) */
  /*             intensityImageOut(r,c) = 0; */
  /*         else */
  /*             intensityImageOut(r,c) = intensityImageOut(r,c)/max(max(intensityImageOut)); */
  /*         end */
  /*     end */
  /* end */
  /*  */
  /* return */
  /*  */
  /* } */

  /* S-Function (svipedge): '<Root>/Edge Detection' */
  for (imgCol = 1; imgCol < 119; imgCol++) {
    for (iy = 1; iy < 159; iy++) {
      accumOne = 0.0;
      accumTwo = 0.0;
      ix = imgCol * 160 + iy;
      for (i = 0; i < 6; i++) {
        accumOne += localB->intensityImageOut[ix + localDW->
          EdgeDetection_VO_DW[i]] *
          validation_gate_ConstP.EdgeDetection_VC_RTP[i];
        accumTwo += localB->intensityImageOut[ix + localDW->
          EdgeDetection_HO_DW[i]] *
          validation_gate_ConstP.EdgeDetection_HC_RTP[i];
      }

      localDW->EdgeDetection_GV_SQUARED_DW[ix] = accumOne * accumOne;
      localDW->EdgeDetection_GH_SQUARED_DW[ix] = accumTwo * accumTwo;
    }
  }

  for (imgCol = 1; imgCol < 119; imgCol++) {
    accumOne = 0.0;
    accumTwo = 0.0;
    accumThree = 0.0;
    accumFour = 0.0;
    imgIdx_u = imgCol * 160;
    ix = imgCol * 160 + 159;
    for (i = 0; i < 6; i++) {
      accumOne += localB->intensityImageOut[imgIdx_u +
        localDW->EdgeDetection_HOU_DW[i]] *
        validation_gate_ConstP.EdgeDetection_HC_RTP[i];
      accumTwo += localB->intensityImageOut[ix + localDW->EdgeDetection_HOD_DW[i]]
        * validation_gate_ConstP.EdgeDetection_HC_RTP[i];
      accumThree += localB->intensityImageOut[imgIdx_u +
        localDW->EdgeDetection_VOU_DW[i]] *
        validation_gate_ConstP.EdgeDetection_VC_RTP[i];
      accumFour += localB->intensityImageOut[ix + localDW->
        EdgeDetection_VOD_DW[i]] * validation_gate_ConstP.EdgeDetection_VC_RTP[i];
    }

    localDW->EdgeDetection_GV_SQUARED_DW[imgIdx_u] = accumThree * accumThree;
    localDW->EdgeDetection_GH_SQUARED_DW[imgIdx_u] = accumOne * accumOne;
    localDW->EdgeDetection_GV_SQUARED_DW[ix] = accumFour * accumFour;
    localDW->EdgeDetection_GH_SQUARED_DW[ix] = accumTwo * accumTwo;
  }

  for (iy = 1; iy < 159; iy++) {
    accumOne = 0.0;
    accumTwo = 0.0;
    accumThree = 0.0;
    accumFour = 0.0;
    imgIdx_r = 19040 + iy;
    for (i = 0; i < 6; i++) {
      accumOne += localB->intensityImageOut[iy + localDW->EdgeDetection_VOL_DW[i]]
        * validation_gate_ConstP.EdgeDetection_VC_RTP[i];
      accumTwo += localB->intensityImageOut[imgIdx_r +
        localDW->EdgeDetection_VOR_DW[i]] *
        validation_gate_ConstP.EdgeDetection_VC_RTP[i];
      accumThree += localB->intensityImageOut[iy + localDW->
        EdgeDetection_HOL_DW[i]] * validation_gate_ConstP.EdgeDetection_HC_RTP[i];
      accumFour += localB->intensityImageOut[imgIdx_r +
        localDW->EdgeDetection_HOR_DW[i]] *
        validation_gate_ConstP.EdgeDetection_HC_RTP[i];
    }

    localDW->EdgeDetection_GV_SQUARED_DW[iy] = accumOne * accumOne;
    localDW->EdgeDetection_GH_SQUARED_DW[iy] = accumThree * accumThree;
    localDW->EdgeDetection_GV_SQUARED_DW[imgIdx_r] = accumTwo * accumTwo;
    localDW->EdgeDetection_GH_SQUARED_DW[imgIdx_r] = accumFour * accumFour;
  }

  accumOne = 0.0;
  accumTwo = 0.0;
  accumThree = 0.0;
  accumFour = 0.0;
  for (i = 0; i < 6; i++) {
    accumOne += localB->intensityImageOut[localDW->EdgeDetection_VOUL_DW[i]] *
      validation_gate_ConstP.EdgeDetection_VC_RTP[i];
    accumTwo += localB->intensityImageOut[localDW->EdgeDetection_HOUL_DW[i]] *
      validation_gate_ConstP.EdgeDetection_HC_RTP[i];
    accumThree += localB->intensityImageOut[159 + localDW->
      EdgeDetection_VOLL_DW[i]] * validation_gate_ConstP.EdgeDetection_VC_RTP[i];
    accumFour += localB->intensityImageOut[159 + localDW->
      EdgeDetection_HOLL_DW[i]] * validation_gate_ConstP.EdgeDetection_HC_RTP[i];
  }

  localDW->EdgeDetection_GV_SQUARED_DW[0] = accumOne * accumOne;
  localDW->EdgeDetection_GH_SQUARED_DW[0] = accumTwo * accumTwo;
  localDW->EdgeDetection_GV_SQUARED_DW[159] = accumThree * accumThree;
  localDW->EdgeDetection_GH_SQUARED_DW[159] = accumFour * accumFour;
  accumOne = 0.0;
  accumTwo = 0.0;
  accumThree = 0.0;
  accumFour = 0.0;
  for (i = 0; i < 6; i++) {
    accumOne += localB->intensityImageOut[19040 + localDW->
      EdgeDetection_VOUR_DW[i]] * validation_gate_ConstP.EdgeDetection_VC_RTP[i];
    accumTwo += localB->intensityImageOut[19040 + localDW->
      EdgeDetection_HOUR_DW[i]] * validation_gate_ConstP.EdgeDetection_HC_RTP[i];
    accumThree += localB->intensityImageOut[19199 +
      localDW->EdgeDetection_VOLR_DW[i]] *
      validation_gate_ConstP.EdgeDetection_VC_RTP[i];
    accumFour += localB->intensityImageOut[19199 +
      localDW->EdgeDetection_HOLR_DW[i]] *
      validation_gate_ConstP.EdgeDetection_HC_RTP[i];
  }

  localDW->EdgeDetection_GV_SQUARED_DW[19040] = accumOne * accumOne;
  localDW->EdgeDetection_GH_SQUARED_DW[19040] = accumTwo * accumTwo;
  localDW->EdgeDetection_GV_SQUARED_DW[19199] = accumThree * accumThree;
  localDW->EdgeDetection_GH_SQUARED_DW[19199] = accumFour * accumFour;
  accumTwo = 0.0;
  for (i = 0; i < 19200; i++) {
    localDW->EdgeDetection_GRAD_SUM_DW[i] = localDW->
      EdgeDetection_GV_SQUARED_DW[i];
    localDW->EdgeDetection_GRAD_SUM_DW[i] = localDW->EdgeDetection_GRAD_SUM_DW[i]
      + localDW->EdgeDetection_GH_SQUARED_DW[i];
    accumTwo += localDW->EdgeDetection_GRAD_SUM_DW[i] *
      localDW->EdgeDetection_MEAN_FACTOR_DW;
  }

  accumOne = 3.0 * accumTwo;
  for (imgCol = 0; imgCol < 120; imgCol++) {
    for (iy = 0; iy < 160; iy++) {
      i = imgCol * 160 + iy;
      rty_edge_image[i] = ((localDW->EdgeDetection_GRAD_SUM_DW[i] > accumOne) &&
                           (((localDW->EdgeDetection_GV_SQUARED_DW[i] >=
        localDW->EdgeDetection_GH_SQUARED_DW[i]) && (imgCol != 0 ?
        localDW->EdgeDetection_GRAD_SUM_DW[i - 160] <=
        localDW->EdgeDetection_GRAD_SUM_DW[i] : TRUE) && (imgCol != 119 ?
        localDW->EdgeDetection_GRAD_SUM_DW[i] >
        localDW->EdgeDetection_GRAD_SUM_DW[i + 160] : TRUE)) ||
                            ((localDW->EdgeDetection_GH_SQUARED_DW[i] >=
        localDW->EdgeDetection_GV_SQUARED_DW[i]) && (iy != 0 ?
        localDW->EdgeDetection_GRAD_SUM_DW[i - 1] <=
        localDW->EdgeDetection_GRAD_SUM_DW[i] : TRUE) && (iy != 159 ?
        localDW->EdgeDetection_GRAD_SUM_DW[i] >
        localDW->EdgeDetection_GRAD_SUM_DW[i + 1] : TRUE))));
    }
  }
}

/* Model initialize function */
void mr_validation_gate_initialize(const char_T **rt_errorStatus,
  RT_MODEL_validation_gate *const validation_gate_M, rtDW_mr_validation_gate
  *localDW)
{
  /* Registration code */

  /* initialize non-finites */
  rt_InitInfAndNaN(sizeof(real_T));

  /* initialize error status */
  rtmSetErrorStatusPointer(validation_gate_M, rt_errorStatus);

  /* states (dwork) */
  (void) memset((void *)localDW, 0,
                sizeof(rtDW_mr_validation_gate));
}

/*
 * File trailer for Real-Time Workshop generated code.
 *
 * [EOF]
 */
