/*
 * File: VisionModel.cpp
 *
 * Real-Time Workshop code generated for Simulink model VisionModel.
 *
 * Model version                        : 1.436
 * Real-Time Workshop file version      : 7.6  (R2010b)  03-Aug-2010
 * Real-Time Workshop file generated on : Wed Jun 22 19:29:01 2011
 * TLC version                          : 7.6 (Jul 13 2010)
 * C/C++ source code generated on       : Wed Jun 22 19:29:01 2011
 *
 * Target selection: ert.tlc
 * Embedded hardware selection: 32-bit Generic
 * Code generation objectives: Unspecified
 * Validation result: Not run
 */

#include "VisionModel.h"
#include "VisionModel_private.h"

/* Block states (auto storage) */
D_Work_VisionModel VisionModel_DWork;

/* External inputs (root inport signals with auto storage) */
ExternalInputs_VisionModel VisionModel_U;

/* External outputs (root outports fed by signals with auto storage) */
ExternalOutputs_VisionModel VisionModel_Y;

/* Real-time model */
RT_MODEL_VisionModel VisionModel_M_;
RT_MODEL_VisionModel *VisionModel_M = &VisionModel_M_;

/* Model step function */
void VisionModel_step(void)
{
  /* Outport: '<Root>/TargetSelect' */
  VisionModel_Y.TargetSelect = 0.0;

  /* Outport: '<Root>/TargetFound' */
  VisionModel_Y.TargetFound = 0.0;

  /* Outport: '<Root>/MaintainHeading' */
  VisionModel_Y.MaintainHeading = 0.0;

  /* Outport: '<Root>/TargetX' */
  VisionModel_Y.TargetX = 0.0;

  /* Outport: '<Root>/TargetY' */
  VisionModel_Y.TargetY = 0.0;

  /* Outport: '<Root>/TargetZ' */
  VisionModel_Y.TargetZ = 0.0;

  /* Outport: '<Root>/TargetYaw' */
  VisionModel_Y.TargetYaw = 0.0;

  /* Outport: '<Root>/DesiredTargetX' */
  VisionModel_Y.DesiredTargetX = 0.0;

  /* Outport: '<Root>/DesiredTargetY' */
  VisionModel_Y.DesiredTargetY = 0.0;

  /* Outport: '<Root>/DesiredTargetZ' */
  VisionModel_Y.DesiredTargetZ = 0.0;

  /* Outport: '<Root>/DesiredTargetYaw' */
  VisionModel_Y.DesiredTargetYaw = 0.0;

  /* Outport: '<Root>/MeasuredZ' */
  VisionModel_Y.MeasuredZ = 0.0;

  /* Outport: '<Root>/MeasuredYAccel' */
  VisionModel_Y.MeasuredYAccel = 0.0;

  /* Outport: '<Root>/MeasuredYaw' */
  VisionModel_Y.MeasuredYaw = 0.0;

  /* Outport: '<Root>/MeasuredYawRate' */
  VisionModel_Y.MeasuredYawRate = 0.0;

  /* Outport: '<Root>/DesiredZ' */
  VisionModel_Y.DesiredZ = 0.0;

  /* Outport: '<Root>/DesiredXVelocity' */
  VisionModel_Y.DesiredXVelocity = 0.0;

  /* Outport: '<Root>/DesiredYaw' */
  VisionModel_Y.DesiredYaw = 0.0;

  /* Outport: '<Root>/TargetDetected' */
  VisionModel_Y.TargetDetected = 0.0;

  /* Outport: '<Root>/PathState' */
  VisionModel_Y.PathState = 0.0;

  /* Outport: '<Root>/BuoyColors' */
  VisionModel_Y.BuoyColors = 0.0;

  /* Outport: '<Root>/FireAuthorization' */
  VisionModel_Y.FireAuthorization = 0.0;

  /* Outport: '<Root>/DummieVariable' */
  VisionModel_Y.DummieVariable = 0.0;

  /* Outport: '<Root>/R' */
  VisionModel_Y.R = 0.0;

  /* Outport: '<Root>/G' */
  VisionModel_Y.G = 0.0;

  /* Outport: '<Root>/B' */
  VisionModel_Y.B = 0.0;

  /* Outport: '<Root>/Iter_Segment_Thresh' */
  VisionModel_Y.Iter_Segment_Thresh = 0.0;

  /* Outport: '<Root>/theta' */
  VisionModel_Y.theta = 0.0;

  /* Outport: '<Root>/LabelMatrix' */
  VisionModel_Y.LabelMatrix = 0.0;

  /* Outport: '<Root>/num_colors' */
  VisionModel_Y.num_colors = 0.0;

  /* Outport: '<Root>/ref_colors' */
  VisionModel_Y.ref_colors = 0.0;

  /* Outport: '<Root>/bw_image' */
  VisionModel_Y.bw_image = 0.0;

  /* If: '<Root>/If' incorporates:
   *  ActionPort: '<S2>/Action Port'
   *  Inport: '<Root>/ModeSelect'
   *  SubSystem: '<Root>/Validation Gate'
   */
  if (VisionModel_U.ModeSelect == 1.0) {
    /* ModelReference: '<S2>/validation_gate.mdl' */
    mr_validation_gate(&VisionModel_U.R_forward_in[0],
                       &VisionModel_U.G_forward_in[0],
                       &VisionModel_U.B_forward_in[0],
                       &VisionModel_Y.edge_image[0],
                       &(VisionModel_DWork.validation_gatemdl_DWORK1.rtb),
                       &(VisionModel_DWork.validation_gatemdl_DWORK1.rtdw));
  }

  /* Embedded MATLAB: '<Root>/Transform Coordinates1' */
  /* Embedded MATLAB Function 'Transform Coordinates1': '<S1>:1' */
  /*  Ensure the image components are between 0 and newMax */
  /* '<S1>:1:10' */
}

/* Model initialize function */
void VisionModel_initialize(void)
{
  /* Registration code */

  /* initialize error status */
  rtmSetErrorStatus(VisionModel_M, (NULL));

  /* states (dwork) */
  (void) memset((void *)&VisionModel_DWork, 0,
                sizeof(D_Work_VisionModel));

  /* external inputs */
  (void) memset((void *)&VisionModel_U, 0,
                sizeof(ExternalInputs_VisionModel));

  /* external outputs */
  (void) memset((void *)&VisionModel_Y, 0,
                sizeof(ExternalOutputs_VisionModel));

  /* Model Initialize fcn for ModelReference Block: '<S2>/validation_gate.mdl' */
  mr_validation_gate_initialize(rtmGetErrorStatusPointer(VisionModel_M),
    &(VisionModel_DWork.validation_gatemdl_DWORK1.rtm),
    &(VisionModel_DWork.validation_gatemdl_DWORK1.rtdw));

  /* Start for ifaction SubSystem: '<Root>/Validation Gate' */
  /* InitializeConditions for ModelReference: '<S2>/validation_gate.mdl' */
  mr_validation_gate_Init(&(VisionModel_DWork.validation_gatemdl_DWORK1.rtdw));

  /* end of Start for SubSystem: '<Root>/Validation Gate' */
}

/*
 * File trailer for Real-Time Workshop generated code.
 *
 * [EOF]
 */
