/*
 * File: validation_gate.cpp
 *
 * Real-Time Workshop code generated for Simulink model validation_gate.
 *
 * Model version                        : 1.1221
 * Real-Time Workshop file version      : 7.6  (R2010b)  03-Aug-2010
 * Real-Time Workshop file generated on : Wed Jun 22 19:42:18 2011
 * TLC version                          : 7.6 (Jul 13 2010)
 * C/C++ source code generated on       : Wed Jun 22 19:42:18 2011
 *
 * Target selection: ert.tlc
 * Embedded hardware selection: 32-bit Generic
 * Code generation objectives: Unspecified
 * Validation result: Not run
 */

#include "validation_gate.h"
#include "validation_gate_private.h"

/*
 * Output and update for atomic system:
 *    '<S4>/Low Pass Filter'
 *    '<S4>/Low Pass Filter1'
 *    '<S4>/Low Pass Filter2'
 */
void validation_gate_LowPassFilter(const real_T rtu_I[19200],
  rtB_LowPassFilter_validation_ga *localB)
{
  real_T G[9];
  real_T Gsum;
  int32_T i;

  /* Embedded MATLAB: '<S4>/Low Pass Filter' */
  /* Embedded MATLAB Function 'Convert to BW/IterativeSegmentation/Low Pass Filter/Low Pass Filter': '<S6>:1' */
  /*  This function calculates the gaussian blur of an intensity image */
  /*  Gaussian matrix rows */
  /*  Gaussian matrix columns */
  /* '<S6>:1:11' */
  memset((void *)(&localB->Iout[0]), 0, 19200U * sizeof(real_T));

  /* '<S6>:1:17' */
  memset((void *)&G[0], 0, 9U * sizeof(real_T));

  /* '<S6>:1:19' */
  /* '<S6>:1:21' */
  /* '<S6>:1:23' */
  Gsum = 0.0;

  /* '<S6>:1:24' */
  for (i = -1; i < 2; i++) {
    /* '<S6>:1:24' */
    /* '<S6>:1:25' */
    /* '<S6>:1:26' */
    G[i + 1] = exp((-((real_T)(i * i) + 1.0)) / 4.0000000000000009);

    /* '<S6>:1:27' */
    Gsum += G[i + 1];

    /* '<S6>:1:25' */
    /* '<S6>:1:26' */
    G[i + 4] = exp((real_T)(-(i * i)) / 4.0000000000000009);

    /* '<S6>:1:27' */
    Gsum += G[i + 4];

    /* '<S6>:1:25' */
    /* '<S6>:1:26' */
    G[i + 7] = exp((-((real_T)(i * i) + 1.0)) / 4.0000000000000009);

    /* '<S6>:1:27' */
    Gsum += G[i + 7];
  }

  /* '<S6>:1:31' */
  for (i = 0; i < 9; i++) {
    G[i] = G[i] / Gsum;
  }

  /* '<S6>:1:33' */
  fknoophdhdjeohdj_conv2(&rtu_I[0], G, &localB->Itemp[0]);

  /*  reflect boundaries to keep image the same size */
  /*  top */
  /* '<S6>:1:37' */
  for (i = 0; i < 118; i++) {
    localB->Iout[160 * (1 + i)] = localB->Itemp[158 * i];
  }

  /*  bottom */
  /* '<S6>:1:39' */
  for (i = 0; i < 118; i++) {
    localB->Iout[159 + 160 * (1 + i)] = localB->Itemp[158 * i + 157];
  }

  /*  left */
  /* '<S6>:1:41' */
  memcpy((void *)(&localB->Iout[1]), (void *)(&localB->Itemp[0]), 158U * sizeof
         (real_T));

  /*  right */
  /* '<S6>:1:43' */
  memcpy((void *)(&localB->Iout[19041]), (void *)(&localB->Itemp[18486]), 158U *
         sizeof(real_T));

  /*  center */
  /* '<S6>:1:45' */
  for (i = 0; i < 118; i++) {
    memcpy((void *)(&localB->Iout[1 + 160 * (1 + i)]), (void *)(&localB->Itemp
            [158 * i]), 158U * sizeof(real_T));
  }

  /*  top left corner */
  /* '<S6>:1:47' */
  localB->Iout[0] = localB->Itemp[0];

  /*  top right corner */
  /* '<S6>:1:49' */
  localB->Iout[18880] = localB->Itemp[18328];
  localB->Iout[19040] = localB->Itemp[18486];

  /*  bottom left corner */
  /* '<S6>:1:51' */
  localB->Iout[158] = localB->Itemp[156];
  localB->Iout[159] = localB->Itemp[157];

  /*  bottom right corner */
  /* '<S6>:1:53' */
  localB->Iout[19038] = localB->Itemp[18484];
  localB->Iout[19039] = localB->Itemp[18485];
  localB->Iout[19198] = localB->Itemp[18642];
  localB->Iout[19199] = localB->Itemp[18643];
}

/* Initial conditions for referenced model: 'validation_gate' */
void mr_validation_gate_Init(rtDW_mr_validation_gate *localDW)
{
  int32_T nonZeroIdx;

  /* InitializeConditions for S-Function (svipedge): '<Root>/Edge Detection' */
  localDW->EdgeDetection_MEAN_FACTOR_DW = 5.2083333333333337E-5;
  for (nonZeroIdx = 0; nonZeroIdx < 6; nonZeroIdx++) {
    localDW->EdgeDetection_VO_DW[nonZeroIdx] =
      validation_gate_ConstP.EdgeDetection_VRO_RTP[nonZeroIdx] * 160 +
      validation_gate_ConstP.EdgeDetection_VCO_RTP[nonZeroIdx];
    if (validation_gate_ConstP.EdgeDetection_VCO_RTP[nonZeroIdx] > 0) {
      localDW->EdgeDetection_VOU_DW[nonZeroIdx] =
        validation_gate_ConstP.EdgeDetection_VRO_RTP[nonZeroIdx] * 160 +
        validation_gate_ConstP.EdgeDetection_VCO_RTP[nonZeroIdx];
      localDW->EdgeDetection_VOD_DW[nonZeroIdx] =
        validation_gate_ConstP.EdgeDetection_VRO_RTP[nonZeroIdx] * 160;
    } else {
      localDW->EdgeDetection_VOU_DW[nonZeroIdx] =
        validation_gate_ConstP.EdgeDetection_VRO_RTP[nonZeroIdx] * 160;
      localDW->EdgeDetection_VOD_DW[nonZeroIdx] =
        validation_gate_ConstP.EdgeDetection_VRO_RTP[nonZeroIdx] * 160 +
        validation_gate_ConstP.EdgeDetection_VCO_RTP[nonZeroIdx];
    }

    if (validation_gate_ConstP.EdgeDetection_VRO_RTP[nonZeroIdx] > 0) {
      localDW->EdgeDetection_VOL_DW[nonZeroIdx] =
        validation_gate_ConstP.EdgeDetection_VRO_RTP[nonZeroIdx] * 160 +
        validation_gate_ConstP.EdgeDetection_VCO_RTP[nonZeroIdx];
      localDW->EdgeDetection_VOR_DW[nonZeroIdx] =
        validation_gate_ConstP.EdgeDetection_VCO_RTP[nonZeroIdx];
    } else {
      localDW->EdgeDetection_VOL_DW[nonZeroIdx] =
        validation_gate_ConstP.EdgeDetection_VCO_RTP[nonZeroIdx];
      localDW->EdgeDetection_VOR_DW[nonZeroIdx] =
        validation_gate_ConstP.EdgeDetection_VRO_RTP[nonZeroIdx] * 160 +
        validation_gate_ConstP.EdgeDetection_VCO_RTP[nonZeroIdx];
    }

    if ((validation_gate_ConstP.EdgeDetection_VCO_RTP[nonZeroIdx] < 0) &&
        (validation_gate_ConstP.EdgeDetection_VRO_RTP[nonZeroIdx] < 0)) {
      localDW->EdgeDetection_VOUL_DW[nonZeroIdx] = 0;
      localDW->EdgeDetection_VOLR_DW[nonZeroIdx] =
        validation_gate_ConstP.EdgeDetection_VRO_RTP[nonZeroIdx] * 160 +
        validation_gate_ConstP.EdgeDetection_VCO_RTP[nonZeroIdx];
      localDW->EdgeDetection_VOLL_DW[nonZeroIdx] =
        validation_gate_ConstP.EdgeDetection_VCO_RTP[nonZeroIdx];
      localDW->EdgeDetection_VOUR_DW[nonZeroIdx] =
        validation_gate_ConstP.EdgeDetection_VRO_RTP[nonZeroIdx] * 160;
    }

    if ((validation_gate_ConstP.EdgeDetection_VCO_RTP[nonZeroIdx] >= 0) &&
        (validation_gate_ConstP.EdgeDetection_VRO_RTP[nonZeroIdx] < 0)) {
      localDW->EdgeDetection_VOLL_DW[nonZeroIdx] = 0;
      localDW->EdgeDetection_VOUR_DW[nonZeroIdx] =
        validation_gate_ConstP.EdgeDetection_VRO_RTP[nonZeroIdx] * 160 +
        validation_gate_ConstP.EdgeDetection_VCO_RTP[nonZeroIdx];
      localDW->EdgeDetection_VOUL_DW[nonZeroIdx] =
        validation_gate_ConstP.EdgeDetection_VCO_RTP[nonZeroIdx];
      localDW->EdgeDetection_VOLR_DW[nonZeroIdx] =
        validation_gate_ConstP.EdgeDetection_VRO_RTP[nonZeroIdx] * 160;
    }

    if ((validation_gate_ConstP.EdgeDetection_VCO_RTP[nonZeroIdx] < 0) &&
        (validation_gate_ConstP.EdgeDetection_VRO_RTP[nonZeroIdx] >= 0)) {
      localDW->EdgeDetection_VOUR_DW[nonZeroIdx] = 0;
      localDW->EdgeDetection_VOLL_DW[nonZeroIdx] =
        validation_gate_ConstP.EdgeDetection_VRO_RTP[nonZeroIdx] * 160 +
        validation_gate_ConstP.EdgeDetection_VCO_RTP[nonZeroIdx];
      localDW->EdgeDetection_VOUL_DW[nonZeroIdx] =
        validation_gate_ConstP.EdgeDetection_VRO_RTP[nonZeroIdx] * 160;
      localDW->EdgeDetection_VOLR_DW[nonZeroIdx] =
        validation_gate_ConstP.EdgeDetection_VCO_RTP[nonZeroIdx];
    }

    if ((validation_gate_ConstP.EdgeDetection_VCO_RTP[nonZeroIdx] >= 0) &&
        (validation_gate_ConstP.EdgeDetection_VRO_RTP[nonZeroIdx] >= 0)) {
      localDW->EdgeDetection_VOLR_DW[nonZeroIdx] = 0;
      localDW->EdgeDetection_VOUL_DW[nonZeroIdx] =
        validation_gate_ConstP.EdgeDetection_VRO_RTP[nonZeroIdx] * 160 +
        validation_gate_ConstP.EdgeDetection_VCO_RTP[nonZeroIdx];
      localDW->EdgeDetection_VOLL_DW[nonZeroIdx] =
        validation_gate_ConstP.EdgeDetection_VRO_RTP[nonZeroIdx] * 160;
      localDW->EdgeDetection_VOUR_DW[nonZeroIdx] =
        validation_gate_ConstP.EdgeDetection_VCO_RTP[nonZeroIdx];
    }

    localDW->EdgeDetection_HO_DW[nonZeroIdx] =
      validation_gate_ConstP.EdgeDetection_HRO_RTP[nonZeroIdx] * 160 +
      validation_gate_ConstP.EdgeDetection_HCO_RTP[nonZeroIdx];
    if (validation_gate_ConstP.EdgeDetection_HCO_RTP[nonZeroIdx] > 0) {
      localDW->EdgeDetection_HOU_DW[nonZeroIdx] =
        validation_gate_ConstP.EdgeDetection_HRO_RTP[nonZeroIdx] * 160 +
        validation_gate_ConstP.EdgeDetection_HCO_RTP[nonZeroIdx];
      localDW->EdgeDetection_HOD_DW[nonZeroIdx] =
        validation_gate_ConstP.EdgeDetection_HRO_RTP[nonZeroIdx] * 160;
    } else {
      localDW->EdgeDetection_HOU_DW[nonZeroIdx] =
        validation_gate_ConstP.EdgeDetection_HRO_RTP[nonZeroIdx] * 160;
      localDW->EdgeDetection_HOD_DW[nonZeroIdx] =
        validation_gate_ConstP.EdgeDetection_HRO_RTP[nonZeroIdx] * 160 +
        validation_gate_ConstP.EdgeDetection_HCO_RTP[nonZeroIdx];
    }

    if (validation_gate_ConstP.EdgeDetection_HRO_RTP[nonZeroIdx] > 0) {
      localDW->EdgeDetection_HOL_DW[nonZeroIdx] =
        validation_gate_ConstP.EdgeDetection_HRO_RTP[nonZeroIdx] * 160 +
        validation_gate_ConstP.EdgeDetection_HCO_RTP[nonZeroIdx];
      localDW->EdgeDetection_HOR_DW[nonZeroIdx] =
        validation_gate_ConstP.EdgeDetection_HCO_RTP[nonZeroIdx];
    } else {
      localDW->EdgeDetection_HOL_DW[nonZeroIdx] =
        validation_gate_ConstP.EdgeDetection_HCO_RTP[nonZeroIdx];
      localDW->EdgeDetection_HOR_DW[nonZeroIdx] =
        validation_gate_ConstP.EdgeDetection_HRO_RTP[nonZeroIdx] * 160 +
        validation_gate_ConstP.EdgeDetection_HCO_RTP[nonZeroIdx];
    }

    if ((validation_gate_ConstP.EdgeDetection_HCO_RTP[nonZeroIdx] < 0) &&
        (validation_gate_ConstP.EdgeDetection_HRO_RTP[nonZeroIdx] < 0)) {
      localDW->EdgeDetection_HOUL_DW[nonZeroIdx] = 0;
      localDW->EdgeDetection_HOLR_DW[nonZeroIdx] =
        validation_gate_ConstP.EdgeDetection_HRO_RTP[nonZeroIdx] * 160 +
        validation_gate_ConstP.EdgeDetection_HCO_RTP[nonZeroIdx];
      localDW->EdgeDetection_HOLL_DW[nonZeroIdx] =
        validation_gate_ConstP.EdgeDetection_HCO_RTP[nonZeroIdx];
      localDW->EdgeDetection_HOUR_DW[nonZeroIdx] =
        validation_gate_ConstP.EdgeDetection_HRO_RTP[nonZeroIdx] * 160;
    }

    if ((validation_gate_ConstP.EdgeDetection_HCO_RTP[nonZeroIdx] >= 0) &&
        (validation_gate_ConstP.EdgeDetection_HRO_RTP[nonZeroIdx] < 0)) {
      localDW->EdgeDetection_HOLL_DW[nonZeroIdx] = 0;
      localDW->EdgeDetection_HOUR_DW[nonZeroIdx] =
        validation_gate_ConstP.EdgeDetection_HRO_RTP[nonZeroIdx] * 160 +
        validation_gate_ConstP.EdgeDetection_HCO_RTP[nonZeroIdx];
      localDW->EdgeDetection_HOUL_DW[nonZeroIdx] =
        validation_gate_ConstP.EdgeDetection_HCO_RTP[nonZeroIdx];
      localDW->EdgeDetection_HOLR_DW[nonZeroIdx] =
        validation_gate_ConstP.EdgeDetection_HRO_RTP[nonZeroIdx] * 160;
    }

    if ((validation_gate_ConstP.EdgeDetection_HCO_RTP[nonZeroIdx] < 0) &&
        (validation_gate_ConstP.EdgeDetection_HRO_RTP[nonZeroIdx] >= 0)) {
      localDW->EdgeDetection_HOUR_DW[nonZeroIdx] = 0;
      localDW->EdgeDetection_HOLL_DW[nonZeroIdx] =
        validation_gate_ConstP.EdgeDetection_HRO_RTP[nonZeroIdx] * 160 +
        validation_gate_ConstP.EdgeDetection_HCO_RTP[nonZeroIdx];
      localDW->EdgeDetection_HOUL_DW[nonZeroIdx] =
        validation_gate_ConstP.EdgeDetection_HRO_RTP[nonZeroIdx] * 160;
      localDW->EdgeDetection_HOLR_DW[nonZeroIdx] =
        validation_gate_ConstP.EdgeDetection_HCO_RTP[nonZeroIdx];
    }

    if ((validation_gate_ConstP.EdgeDetection_HCO_RTP[nonZeroIdx] >= 0) &&
        (validation_gate_ConstP.EdgeDetection_HRO_RTP[nonZeroIdx] >= 0)) {
      localDW->EdgeDetection_HOLR_DW[nonZeroIdx] = 0;
      localDW->EdgeDetection_HOUL_DW[nonZeroIdx] =
        validation_gate_ConstP.EdgeDetection_HRO_RTP[nonZeroIdx] * 160 +
        validation_gate_ConstP.EdgeDetection_HCO_RTP[nonZeroIdx];
      localDW->EdgeDetection_HOLL_DW[nonZeroIdx] =
        validation_gate_ConstP.EdgeDetection_HRO_RTP[nonZeroIdx] * 160;
      localDW->EdgeDetection_HOUR_DW[nonZeroIdx] =
        validation_gate_ConstP.EdgeDetection_HCO_RTP[nonZeroIdx];
    }
  }
}

/* Output and update for referenced model: 'validation_gate' */
void mr_validation_gate(const real_T rtu_R_forward_in[19200], const real_T
  rtu_G_forward_in[19200], const real_T rtu_B_forward_in[19200], real_T
  *rty_TargetSelect, real_T *rty_TargetFound, real_T *rty_MaintainHeading,
  real_T *rty_TargetYaw, real_T rty_LabelMatrix[19200], real_T *rty_num_colors,
  real_T rty_ref_colors[150], real_T rty_bw_image[19200], boolean_T
  rty_edge_image[19200], rtB_mr_validation_gate *localB, rtDW_mr_validation_gate
  *localDW)
{
  int32_T flag;
  int32_T j;
  real_T ref_color_L_avg[50];
  real_T ref_color_a_avg[50];
  real_T ref_color_b_avg[50];
  real_T color_count[50];
  real_T ref_colors[150];
  int32_T numElem;
  int32_T imgCol;
  real_T accumOne;
  int32_T m;
  int32_T imgIdx_r;
  real_T Resize2_LineBuffer[160];
  real_T gate_i_idx;
  real_T gate_i_idx_0;
  real_T maxL_idx;
  real_T maxL_idx_0;

  /* Constant: '<Root>/Constant3' */
  (*rty_TargetSelect) = 1.0;

  /* Constant: '<Root>/Constant4' */
  (*rty_TargetFound) = 1.0;

  /* Constant: '<Root>/Constant5' */
  (*rty_MaintainHeading) = 1.0;

  /* Constant: '<Root>/Constant6' */
  (*rty_TargetYaw) = 0.0;

  /* Embedded MATLAB: '<S4>/Low Pass Filter' */
  validation_gate_LowPassFilter(rtu_R_forward_in, &localB->sf_LowPassFilter);

  /* Embedded MATLAB: '<S4>/Low Pass Filter1' */
  validation_gate_LowPassFilter(rtu_G_forward_in, &localB->sf_LowPassFilter1);

  /* Embedded MATLAB: '<S4>/Low Pass Filter2' */
  validation_gate_LowPassFilter(rtu_B_forward_in, &localB->sf_LowPassFilter2);

  /* S-Function (svipcolorconv): '<S3>/Color Space  Conversion1' */
  /* temporary variables for in-place operation */
  /* Convert to XYZ */
  /* temporary variables for in-place operation */
  for (imgIdx_r = 0; imgIdx_r < 19200; imgIdx_r++) {
    /* First, linearize (de-gamma) the RGB values; the operation is */
    /* equivalent to running the gamma correction block with break */
    /* point of 0.00304 and gamma of 2.4; it's built into this */
    /* conversion for convenience */
    if (localB->sf_LowPassFilter.Iout[imgIdx_r] <= 0.039286085583733095) {
      accumOne = localB->sf_LowPassFilter.Iout[imgIdx_r] / 12.923054468333255;
    } else {
      accumOne = rt_pow_snf((localB->sf_LowPassFilter.Iout[imgIdx_r] +
        0.055000519817226347) / 1.0550005198172263, 2.4);
    }

    if (localB->sf_LowPassFilter1.Iout[imgIdx_r] <= 0.039286085583733095) {
      maxL_idx_0 = localB->sf_LowPassFilter1.Iout[imgIdx_r] / 12.923054468333255;
    } else {
      maxL_idx_0 = rt_pow_snf((localB->sf_LowPassFilter1.Iout[imgIdx_r] +
        0.055000519817226347) / 1.0550005198172263, 2.4);
    }

    if (localB->sf_LowPassFilter2.Iout[imgIdx_r] <= 0.039286085583733095) {
      gate_i_idx_0 = localB->sf_LowPassFilter2.Iout[imgIdx_r] /
        12.923054468333255;
    } else {
      gate_i_idx_0 = rt_pow_snf((localB->sf_LowPassFilter2.Iout[imgIdx_r] +
        0.055000519817226347) / 1.0550005198172263, 2.4);
    }

    /* The coefficients for this conversion were derived from ITU-R */
    /* BT.709 reference primaries for sRGB and CIE standard illuminant */
    /* D65, 2 degree observer */
    maxL_idx = (0.41239079926596 * accumOne + 0.35758433938388 * maxL_idx_0) +
      0.18048078840183 * gate_i_idx_0;
    gate_i_idx = (0.21263900587151 * accumOne + 0.71516867876776 * maxL_idx_0) +
      0.07219231536073 * gate_i_idx_0;
    accumOne = (0.01933081871559 * accumOne + 0.11919477979463 * maxL_idx_0) +
      0.95053215224966 * gate_i_idx_0;

    /* Make sure that the output is in [0..1] range; clip if necessary */
    if (maxL_idx > 1.0) {
      maxL_idx = 1.0;
    } else {
      if (maxL_idx < 0.0) {
        maxL_idx = 0.0;
      }
    }

    if (gate_i_idx > 1.0) {
      gate_i_idx = 1.0;
    } else {
      if (gate_i_idx < 0.0) {
        gate_i_idx = 0.0;
      }
    }

    if (accumOne > 1.0) {
      accumOne = 1.0;
    } else {
      if (accumOne < 0.0) {
        accumOne = 0.0;
      }
    }

    /* assign the results */
    localB->ColorSpaceConversion1_o1[imgIdx_r] = maxL_idx;
    localB->ColorSpaceConversion1_o2[imgIdx_r] = gate_i_idx;
    localB->ColorSpaceConversion1_o3[imgIdx_r] = accumOne;
  }

  /* Convert from XYZ to L*a*b* */
  for (imgIdx_r = 0; imgIdx_r < 19200; imgIdx_r++) {
    accumOne = localB->ColorSpaceConversion1_o1[imgIdx_r] / 0.9641986557609;
    gate_i_idx_0 = localB->ColorSpaceConversion1_o3[imgIdx_r] / 0.82511648322104;

    /* Prepare Xf, Yf, and Zf for computation of a* and b* components */
    if (accumOne > 0.0088564516790356311) {
      maxL_idx = rt_pow_snf(accumOne, 0.33333333333333331);
    } else {
      maxL_idx = 7.7870370370370372 * accumOne + 0.13793103448275862;
    }

    if (localB->ColorSpaceConversion1_o2[imgIdx_r] > 0.0088564516790356311) {
      maxL_idx_0 = rt_pow_snf(localB->ColorSpaceConversion1_o2[imgIdx_r],
        0.33333333333333331);
    } else {
      maxL_idx_0 = 7.7870370370370372 * localB->
        ColorSpaceConversion1_o2[imgIdx_r] + 0.13793103448275862;
    }

    if (gate_i_idx_0 > 0.0088564516790356311) {
      accumOne = rt_pow_snf(gate_i_idx_0, 0.33333333333333331);
    } else {
      accumOne = 7.7870370370370372 * gate_i_idx_0 + 0.13793103448275862;
    }

    /* assign the results */
    localB->ColorSpaceConversion1_o1[imgIdx_r] = 116.0 * maxL_idx_0 - 16.0;
    localB->ColorSpaceConversion1_o2[imgIdx_r] = (maxL_idx - maxL_idx_0) * 500.0;
    localB->ColorSpaceConversion1_o3[imgIdx_r] = (maxL_idx_0 - accumOne) * 200.0;
  }

  /* S-Function (svipresize): '<S11>/Resize' */
  /* use pre-computed weights and index table to perform interpolation */
  j = 0;
  for (m = 0; m < 160; m++) {
    imgIdx_r = m;
    for (flag = 0; flag < 80; flag++) {
      numElem = flag + 80;
      accumOne = localB->
        ColorSpaceConversion1_o1[validation_gate_ConstP.pooled5[flag] * 160 + m]
        * validation_gate_ConstP.pooled3[flag] +
        localB->ColorSpaceConversion1_o1[validation_gate_ConstP.pooled5[numElem]
        * 160 + m] * validation_gate_ConstP.pooled3[numElem];
      numElem += 80;
      accumOne += localB->
        ColorSpaceConversion1_o1[validation_gate_ConstP.pooled5[numElem] * 160 +
        m] * validation_gate_ConstP.pooled3[numElem];
      localDW->Resize_IntBuffer[imgIdx_r] = accumOne;
      imgIdx_r += 160;
    }
  }

  for (flag = 0; flag < 80; flag++) {
    memcpy((void *)&Resize2_LineBuffer[0], (void *)(&localDW->
            Resize_IntBuffer[flag * 160]), 160U * sizeof(real_T));
    for (m = 0; m < 60; m++) {
      numElem = m;
      accumOne = 0.0;
      for (imgCol = 0; imgCol < 6; imgCol++) {
        accumOne += Resize2_LineBuffer[validation_gate_ConstP.pooled4[numElem]] *
          validation_gate_ConstP.pooled2[numElem];
        numElem += 60;
      }

      localB->Resize[j] = accumOne;
      j++;
    }
  }

  /* S-Function (svipresize): '<S11>/Resize1' */
  /* use pre-computed weights and index table to perform interpolation */
  j = 0;
  for (m = 0; m < 160; m++) {
    imgIdx_r = m;
    for (flag = 0; flag < 80; flag++) {
      numElem = flag + 80;
      accumOne = localB->
        ColorSpaceConversion1_o2[validation_gate_ConstP.pooled5[flag] * 160 + m]
        * validation_gate_ConstP.pooled3[flag] +
        localB->ColorSpaceConversion1_o2[validation_gate_ConstP.pooled5[numElem]
        * 160 + m] * validation_gate_ConstP.pooled3[numElem];
      numElem += 80;
      accumOne += localB->
        ColorSpaceConversion1_o2[validation_gate_ConstP.pooled5[numElem] * 160 +
        m] * validation_gate_ConstP.pooled3[numElem];
      localDW->Resize1_IntBuffer[imgIdx_r] = accumOne;
      imgIdx_r += 160;
    }
  }

  for (flag = 0; flag < 80; flag++) {
    memcpy((void *)&Resize2_LineBuffer[0], (void *)(&localDW->
            Resize1_IntBuffer[flag * 160]), 160U * sizeof(real_T));
    for (m = 0; m < 60; m++) {
      numElem = m;
      accumOne = 0.0;
      for (imgCol = 0; imgCol < 6; imgCol++) {
        accumOne += Resize2_LineBuffer[validation_gate_ConstP.pooled4[numElem]] *
          validation_gate_ConstP.pooled2[numElem];
        numElem += 60;
      }

      localB->Resize1[j] = accumOne;
      j++;
    }
  }

  /* S-Function (svipresize): '<S11>/Resize2' */
  /* use pre-computed weights and index table to perform interpolation */
  j = 0;
  for (m = 0; m < 160; m++) {
    imgIdx_r = m;
    for (flag = 0; flag < 80; flag++) {
      numElem = flag + 80;
      accumOne = localB->
        ColorSpaceConversion1_o3[validation_gate_ConstP.pooled5[flag] * 160 + m]
        * validation_gate_ConstP.pooled3[flag] +
        localB->ColorSpaceConversion1_o3[validation_gate_ConstP.pooled5[numElem]
        * 160 + m] * validation_gate_ConstP.pooled3[numElem];
      numElem += 80;
      accumOne += localB->
        ColorSpaceConversion1_o3[validation_gate_ConstP.pooled5[numElem] * 160 +
        m] * validation_gate_ConstP.pooled3[numElem];
      localDW->Resize2_IntBuffer[imgIdx_r] = accumOne;
      imgIdx_r += 160;
    }
  }

  for (flag = 0; flag < 80; flag++) {
    memcpy((void *)&Resize2_LineBuffer[0], (void *)(&localDW->
            Resize2_IntBuffer[flag * 160]), 160U * sizeof(real_T));
    for (m = 0; m < 60; m++) {
      numElem = m;
      accumOne = 0.0;
      for (imgCol = 0; imgCol < 6; imgCol++) {
        accumOne += Resize2_LineBuffer[validation_gate_ConstP.pooled4[numElem]] *
          validation_gate_ConstP.pooled2[numElem];
        numElem += 60;
      }

      localB->Resize2[j] = accumOne;
      j++;
    }
  }

  /* Embedded MATLAB: '<S5>/Reference Color Selection' incorporates:
   *  Constant: '<S5>/Dist_Thresh'
   */
  /* Embedded MATLAB Function 'Convert to BW/IterativeSegmentation/Segmentation/Reference Color Selection': '<S10>:1' */
  /*  This function tries segmentation by adding new reference colors everytime */
  /*  a pixel is found with a distance greater than a certain amount from */
  /*  every other reference color */
  /* '<S10>:1:6' */
  /*  L = 0 to 100, a = -100 to 100, b = -100 to 100 */
  /*  max dist = 300 -> 60/300 is 20% */
  /*  coefficients determining distance calculation */
  /* '<S10>:1:14' */
  /* '<S10>:1:15' */
  memset((void *)(&rty_ref_colors[0]), 0, 150U * sizeof(real_T));

  /*  At most 50 different reference colors */
  /* '<S10>:1:16' */
  memset((void *)(&localB->LabelMatrix[0]), (int32_T)0U, 4800U * sizeof(uint32_T));

  /* '<S10>:1:17' */
  imgCol = 1;

  /*  Define first reference color to be colr */
  /* '<S10>:1:23' */
  rty_ref_colors[0] = localB->Resize[2369];
  rty_ref_colors[50] = localB->Resize1[2369];
  rty_ref_colors[100] = localB->Resize2[2369];

  /* '<S10>:1:25' */
  flag = 0;

  /* '<S10>:1:26' */
  imgIdx_r = 1;

  /* '<S10>:1:27' */
  j = 1;
  while (imgIdx_r <= 60) {
    /* '<S10>:1:28' */
    /*  perform initial segmentation */
    while ((imgIdx_r <= 60) && (flag == 0)) {
      /* '<S10>:1:29' */
      while ((j <= 80) && (flag == 0)) {
        /* '<S10>:1:30' */
        /* '<S10>:1:31' */
        gate_i_idx_0 = 1.0;

        /* '<S10>:1:32' */
        accumOne = 1000.0;

        /* '<S10>:1:33' */
        maxL_idx_0 = 1.0;
        while ((uint32_T)gate_i_idx_0 <= (uint32_T)imgCol) {
          /* '<S10>:1:34' */
          /* '<S10>:1:35' */
          maxL_idx = sqrt((rt_pow_snf(rty_ref_colors[(int32_T)gate_i_idx_0 + 49]
            - localB->Resize1[(j - 1) * 60 + (imgIdx_r - 1)], 2.0) * 1.5 +
                           rt_pow_snf(rty_ref_colors[(int32_T)gate_i_idx_0 - 1]
            - localB->Resize[(j - 1) * 60 + (imgIdx_r - 1)], 2.0)) + rt_pow_snf
                          (rty_ref_colors[(int32_T)gate_i_idx_0 + 99] -
                           localB->Resize2[(j - 1) * 60 + (imgIdx_r - 1)], 2.0) *
                          1.5);
          if (accumOne > maxL_idx) {
            /* '<S10>:1:36' */
            /* '<S10>:1:37' */
            accumOne = maxL_idx;

            /* '<S10>:1:38' */
            maxL_idx_0 = gate_i_idx_0;
          }

          /* '<S10>:1:40' */
          gate_i_idx_0++;
        }

        if ((accumOne > 20.0) && (imgCol < 50)) {
          /* '<S10>:1:45' */
          /* '<S10>:1:46' */
          rty_ref_colors[imgCol] = localB->Resize[(j - 1) * 60 + (imgIdx_r - 1)];
          rty_ref_colors[imgCol + 50] = localB->Resize1[(j - 1) * 60 + (imgIdx_r
            - 1)];
          rty_ref_colors[imgCol + 100] = localB->Resize2[(j - 1) * 60 +
            (imgIdx_r - 1)];

          /* '<S10>:1:47' */
          imgCol++;

          /* '<S10>:1:48' */
          flag = 1;

          /* '<S10>:1:49' */
          imgIdx_r = 0;

          /* '<S10>:1:50' */
          j = 0;
        } else {
          /* '<S10>:1:52' */
          localB->LabelMatrix[(imgIdx_r - 1) + 60 * (j - 1)] = (uint32_T)
            maxL_idx_0;
        }

        /* '<S10>:1:54' */
        j++;
      }

      /* '<S10>:1:56' */
      j = 1;

      /* '<S10>:1:57' */
      imgIdx_r++;
    }

    /* '<S10>:1:59' */
    flag = 0;
  }

  /*  Go through image once more to get more accurate values for the different regions */
  /* '<S10>:1:63' */
  /* '<S10>:1:64' */
  /* '<S10>:1:65' */
  /* '<S10>:1:66' */
  for (imgIdx_r = 0; imgIdx_r < 50; imgIdx_r++) {
    ref_color_L_avg[imgIdx_r] = 0.0;
    ref_color_a_avg[imgIdx_r] = 0.0;
    ref_color_b_avg[imgIdx_r] = 0.0;
    color_count[imgIdx_r] = 0.0;
  }

  /* '<S10>:1:67' */
  for (imgIdx_r = 0; imgIdx_r < 60; imgIdx_r++) {
    /* '<S10>:1:67' */
    /* '<S10>:1:68' */
    for (flag = 0; flag < 80; flag++) {
      /* '<S10>:1:68' */
      /* '<S10>:1:69' */
      /* '<S10>:1:70' */
      ref_color_L_avg[(int32_T)localB->LabelMatrix[imgIdx_r + 60 * flag] - 1] =
        ref_color_L_avg[(int32_T)localB->LabelMatrix[60 * flag + imgIdx_r] - 1]
        + localB->Resize[60 * flag + imgIdx_r];

      /* '<S10>:1:71' */
      ref_color_a_avg[(int32_T)localB->LabelMatrix[imgIdx_r + 60 * flag] - 1] =
        ref_color_a_avg[(int32_T)localB->LabelMatrix[60 * flag + imgIdx_r] - 1]
        + localB->Resize1[60 * flag + imgIdx_r];

      /* '<S10>:1:72' */
      ref_color_b_avg[(int32_T)localB->LabelMatrix[imgIdx_r + 60 * flag] - 1] =
        ref_color_b_avg[(int32_T)localB->LabelMatrix[60 * flag + imgIdx_r] - 1]
        + localB->Resize2[60 * flag + imgIdx_r];

      /* '<S10>:1:73' */
      color_count[(int32_T)localB->LabelMatrix[imgIdx_r + 60 * flag] - 1] =
        color_count[(int32_T)localB->LabelMatrix[60 * flag + imgIdx_r] - 1] +
        1.0;
    }
  }

  /* '<S10>:1:76' */
  /* '<S10>:1:77' */
  /* '<S10>:1:78' */
  for (imgIdx_r = 0; imgIdx_r < 50; imgIdx_r++) {
    ref_color_L_avg[imgIdx_r] = ref_color_L_avg[imgIdx_r] / color_count[imgIdx_r];
    ref_color_a_avg[imgIdx_r] = ref_color_a_avg[imgIdx_r] / color_count[imgIdx_r];
    ref_color_b_avg[imgIdx_r] = ref_color_b_avg[imgIdx_r] / color_count[imgIdx_r];
  }

  /* '<S10>:1:80' */
  for (accumOne = 1.0; (uint32_T)accumOne <= (uint32_T)imgCol; accumOne++) {
    /* '<S10>:1:80' */
    /* '<S10>:1:81' */
    rty_ref_colors[(int32_T)accumOne - 1] = ref_color_L_avg[(int32_T)accumOne -
      1];

    /* '<S10>:1:82' */
    rty_ref_colors[(int32_T)accumOne + 49] = ref_color_a_avg[(int32_T)accumOne -
      1];

    /* '<S10>:1:83' */
    rty_ref_colors[(int32_T)accumOne + 99] = ref_color_b_avg[(int32_T)accumOne -
      1];
  }

  (*rty_num_colors) = (real_T)imgCol;

  /* Embedded MATLAB: '<S5>/LabSegmentation' */
  /* Embedded MATLAB Function 'Convert to BW/IterativeSegmentation/Segmentation/LabSegmentation': '<S9>:1' */
  /*  This function generates the label matrix */
  /* '<S9>:1:10' */
  memset((void *)(&rty_LabelMatrix[0]), 0, 19200U * sizeof(real_T));

  /* '<S9>:1:12' */
  for (imgIdx_r = 0; imgIdx_r < 160; imgIdx_r++) {
    /* '<S9>:1:12' */
    /* '<S9>:1:13' */
    for (j = 0; j < 120; j++) {
      /* '<S9>:1:13' */
      /* '<S9>:1:14' */
      accumOne = 1000.0;

      /* '<S9>:1:15' */
      maxL_idx_0 = 1.0;

      /* '<S9>:1:16' */
      for (gate_i_idx_0 = 1.0; gate_i_idx_0 <= (*rty_num_colors); gate_i_idx_0++)
      {
        /* '<S9>:1:16' */
        /* '<S9>:1:17' */
        maxL_idx = sqrt((rt_pow_snf(rty_ref_colors[(int32_T)gate_i_idx_0 - 1] -
          localB->ColorSpaceConversion1_o1[160 * j + imgIdx_r], 2.0) +
                         rt_pow_snf(rty_ref_colors[(int32_T)gate_i_idx_0 + 49] -
          localB->ColorSpaceConversion1_o2[160 * j + imgIdx_r], 2.0)) +
                        rt_pow_snf(rty_ref_colors[(int32_T)gate_i_idx_0 + 99] -
          localB->ColorSpaceConversion1_o3[160 * j + imgIdx_r], 2.0));
        if (maxL_idx < accumOne) {
          /* '<S9>:1:18' */
          /* '<S9>:1:19' */
          accumOne = maxL_idx;

          /* '<S9>:1:20' */
          maxL_idx_0 = gate_i_idx_0;
        }
      }

      /* '<S9>:1:23' */
      rty_LabelMatrix[imgIdx_r + 160 * j] = maxL_idx_0;
    }
  }

  /* '<S9>:1:27' */

  /* Embedded MATLAB: '<S1>/Identify Validation Gate2' */
  memcpy((void *)&ref_colors[0], (void *)(&rty_ref_colors[0]), 150U * sizeof
         (real_T));

  /* Embedded MATLAB Function 'Convert to BW/Identify Validation Gate2': '<S2>:1' */
  /*  Initialize */
  /* [rows, cols] = size(LabelMatrix); */
  /* rows = Forward_Camera_Dimensions(1); */
  /* cols = Forward_Camera_Dimensions(2); */
  /* '<S2>:1:13' */
  memset((void *)(&rty_bw_image[0]), 0, 19200U * sizeof(real_T));

  /* intensity_image = zeros(160 120); */
  /* '<S2>:1:17' */
  /* '<S2>:1:18' */
  maxL_idx_0 = 0.0;
  gate_i_idx_0 = 1.0;
  maxL_idx = 0.0;
  gate_i_idx = 1.0;

  /*  Identify max_num_cols colors with the brightest L color components */
  /* '<S2>:1:22' */
  /* '<S2>:1:24' */
  for (accumOne = 1.0; accumOne <= (*rty_num_colors); accumOne++) {
    /* '<S2>:1:24' */
    if (ref_colors[(int32_T)accumOne - 1] > maxL_idx_0) {
      /* '<S2>:1:25' */
      /* '<S2>:1:26' */
      gate_i_idx_0 = accumOne;

      /* '<S2>:1:27' */
      maxL_idx_0 = ref_colors[(int32_T)accumOne - 1];
    }
  }

  /* '<S2>:1:31' */
  ref_colors[(int32_T)gate_i_idx_0 - 1] = -1.0;

  /* '<S2>:1:22' */
  /* '<S2>:1:24' */
  for (accumOne = 1.0; accumOne <= (*rty_num_colors); accumOne++) {
    /* '<S2>:1:24' */
    if (ref_colors[(int32_T)accumOne - 1] > maxL_idx) {
      /* '<S2>:1:25' */
      /* '<S2>:1:26' */
      gate_i_idx = accumOne;

      /* '<S2>:1:27' */
      maxL_idx = ref_colors[(int32_T)accumOne - 1];
    }
  }

  /* '<S2>:1:31' */
  /*  Ignore all non-white values */
  /* '<S2>:1:37' */
  for (imgIdx_r = 0; imgIdx_r < 160; imgIdx_r++) {
    /* '<S2>:1:37' */
    /* '<S2>:1:38' */
    for (flag = 0; flag < 120; flag++) {
      /* '<S2>:1:38' */
      /* '<S2>:1:40' */
      if (rty_LabelMatrix[160 * flag + imgIdx_r] == gate_i_idx_0) {
        /* '<S2>:1:41' */
        /* '<S2>:1:42' */
        rty_bw_image[imgIdx_r + 160 * flag] = 1.0;
      }

      /* '<S2>:1:40' */
      if (rty_LabelMatrix[160 * flag + imgIdx_r] == gate_i_idx) {
        /* '<S2>:1:41' */
        /* '<S2>:1:42' */
        rty_bw_image[imgIdx_r + 160 * flag] = 1.0;
      }
    }
  }

  /* S-Function (svipedge): '<Root>/Edge Detection' */
  for (imgCol = 1; imgCol < 119; imgCol++) {
    for (j = 1; j < 159; j++) {
      accumOne = 0.0;
      maxL_idx_0 = 0.0;
      flag = imgCol * 160 + j;
      for (m = 0; m < 6; m++) {
        accumOne += rty_bw_image[flag + localDW->EdgeDetection_VO_DW[m]] *
          validation_gate_ConstP.EdgeDetection_VC_RTP[m];
        maxL_idx_0 += rty_bw_image[flag + localDW->EdgeDetection_HO_DW[m]] *
          validation_gate_ConstP.EdgeDetection_HC_RTP[m];
      }

      localDW->EdgeDetection_GV_SQUARED_DW[flag] = accumOne * accumOne;
      localDW->EdgeDetection_GH_SQUARED_DW[flag] = maxL_idx_0 * maxL_idx_0;
    }
  }

  for (imgCol = 1; imgCol < 119; imgCol++) {
    accumOne = 0.0;
    maxL_idx_0 = 0.0;
    gate_i_idx_0 = 0.0;
    maxL_idx = 0.0;
    flag = imgCol * 160;
    j = imgCol * 160 + 159;
    for (m = 0; m < 6; m++) {
      accumOne += rty_bw_image[flag + localDW->EdgeDetection_HOU_DW[m]] *
        validation_gate_ConstP.EdgeDetection_HC_RTP[m];
      maxL_idx_0 += rty_bw_image[j + localDW->EdgeDetection_HOD_DW[m]] *
        validation_gate_ConstP.EdgeDetection_HC_RTP[m];
      gate_i_idx_0 += rty_bw_image[flag + localDW->EdgeDetection_VOU_DW[m]] *
        validation_gate_ConstP.EdgeDetection_VC_RTP[m];
      maxL_idx += rty_bw_image[j + localDW->EdgeDetection_VOD_DW[m]] *
        validation_gate_ConstP.EdgeDetection_VC_RTP[m];
    }

    localDW->EdgeDetection_GV_SQUARED_DW[flag] = gate_i_idx_0 * gate_i_idx_0;
    localDW->EdgeDetection_GH_SQUARED_DW[flag] = accumOne * accumOne;
    localDW->EdgeDetection_GV_SQUARED_DW[j] = maxL_idx * maxL_idx;
    localDW->EdgeDetection_GH_SQUARED_DW[j] = maxL_idx_0 * maxL_idx_0;
  }

  for (j = 1; j < 159; j++) {
    accumOne = 0.0;
    maxL_idx_0 = 0.0;
    gate_i_idx_0 = 0.0;
    maxL_idx = 0.0;
    imgIdx_r = 19040 + j;
    for (m = 0; m < 6; m++) {
      accumOne += rty_bw_image[j + localDW->EdgeDetection_VOL_DW[m]] *
        validation_gate_ConstP.EdgeDetection_VC_RTP[m];
      maxL_idx_0 += rty_bw_image[imgIdx_r + localDW->EdgeDetection_VOR_DW[m]] *
        validation_gate_ConstP.EdgeDetection_VC_RTP[m];
      gate_i_idx_0 += rty_bw_image[j + localDW->EdgeDetection_HOL_DW[m]] *
        validation_gate_ConstP.EdgeDetection_HC_RTP[m];
      maxL_idx += rty_bw_image[imgIdx_r + localDW->EdgeDetection_HOR_DW[m]] *
        validation_gate_ConstP.EdgeDetection_HC_RTP[m];
    }

    localDW->EdgeDetection_GV_SQUARED_DW[j] = accumOne * accumOne;
    localDW->EdgeDetection_GH_SQUARED_DW[j] = gate_i_idx_0 * gate_i_idx_0;
    localDW->EdgeDetection_GV_SQUARED_DW[imgIdx_r] = maxL_idx_0 * maxL_idx_0;
    localDW->EdgeDetection_GH_SQUARED_DW[imgIdx_r] = maxL_idx * maxL_idx;
  }

  accumOne = 0.0;
  maxL_idx_0 = 0.0;
  gate_i_idx_0 = 0.0;
  maxL_idx = 0.0;
  for (m = 0; m < 6; m++) {
    accumOne += rty_bw_image[localDW->EdgeDetection_VOUL_DW[m]] *
      validation_gate_ConstP.EdgeDetection_VC_RTP[m];
    maxL_idx_0 += rty_bw_image[localDW->EdgeDetection_HOUL_DW[m]] *
      validation_gate_ConstP.EdgeDetection_HC_RTP[m];
    gate_i_idx_0 += rty_bw_image[159 + localDW->EdgeDetection_VOLL_DW[m]] *
      validation_gate_ConstP.EdgeDetection_VC_RTP[m];
    maxL_idx += rty_bw_image[159 + localDW->EdgeDetection_HOLL_DW[m]] *
      validation_gate_ConstP.EdgeDetection_HC_RTP[m];
  }

  localDW->EdgeDetection_GV_SQUARED_DW[0] = accumOne * accumOne;
  localDW->EdgeDetection_GH_SQUARED_DW[0] = maxL_idx_0 * maxL_idx_0;
  localDW->EdgeDetection_GV_SQUARED_DW[159] = gate_i_idx_0 * gate_i_idx_0;
  localDW->EdgeDetection_GH_SQUARED_DW[159] = maxL_idx * maxL_idx;
  accumOne = 0.0;
  maxL_idx_0 = 0.0;
  gate_i_idx_0 = 0.0;
  maxL_idx = 0.0;
  for (m = 0; m < 6; m++) {
    accumOne += rty_bw_image[19040 + localDW->EdgeDetection_VOUR_DW[m]] *
      validation_gate_ConstP.EdgeDetection_VC_RTP[m];
    maxL_idx_0 += rty_bw_image[19040 + localDW->EdgeDetection_HOUR_DW[m]] *
      validation_gate_ConstP.EdgeDetection_HC_RTP[m];
    gate_i_idx_0 += rty_bw_image[19199 + localDW->EdgeDetection_VOLR_DW[m]] *
      validation_gate_ConstP.EdgeDetection_VC_RTP[m];
    maxL_idx += rty_bw_image[19199 + localDW->EdgeDetection_HOLR_DW[m]] *
      validation_gate_ConstP.EdgeDetection_HC_RTP[m];
  }

  localDW->EdgeDetection_GV_SQUARED_DW[19040] = accumOne * accumOne;
  localDW->EdgeDetection_GH_SQUARED_DW[19040] = maxL_idx_0 * maxL_idx_0;
  localDW->EdgeDetection_GV_SQUARED_DW[19199] = gate_i_idx_0 * gate_i_idx_0;
  localDW->EdgeDetection_GH_SQUARED_DW[19199] = maxL_idx * maxL_idx;
  maxL_idx_0 = 0.0;
  for (m = 0; m < 19200; m++) {
    localDW->EdgeDetection_GRAD_SUM_DW[m] = localDW->
      EdgeDetection_GV_SQUARED_DW[m];
    localDW->EdgeDetection_GRAD_SUM_DW[m] = localDW->EdgeDetection_GRAD_SUM_DW[m]
      + localDW->EdgeDetection_GH_SQUARED_DW[m];
    maxL_idx_0 += localDW->EdgeDetection_GRAD_SUM_DW[m] *
      localDW->EdgeDetection_MEAN_FACTOR_DW;
  }

  accumOne = 3.0 * maxL_idx_0;
  for (imgCol = 0; imgCol < 120; imgCol++) {
    for (j = 0; j < 160; j++) {
      m = imgCol * 160 + j;
      rty_edge_image[m] = ((localDW->EdgeDetection_GRAD_SUM_DW[m] > accumOne) &&
                           (((localDW->EdgeDetection_GV_SQUARED_DW[m] >=
        localDW->EdgeDetection_GH_SQUARED_DW[m]) && (imgCol != 0 ?
        localDW->EdgeDetection_GRAD_SUM_DW[m - 160] <=
        localDW->EdgeDetection_GRAD_SUM_DW[m] : TRUE) && (imgCol != 119 ?
        localDW->EdgeDetection_GRAD_SUM_DW[m] >
        localDW->EdgeDetection_GRAD_SUM_DW[m + 160] : TRUE)) ||
                            ((localDW->EdgeDetection_GH_SQUARED_DW[m] >=
        localDW->EdgeDetection_GV_SQUARED_DW[m]) && (j != 0 ?
        localDW->EdgeDetection_GRAD_SUM_DW[m - 1] <=
        localDW->EdgeDetection_GRAD_SUM_DW[m] : TRUE) && (j != 159 ?
        localDW->EdgeDetection_GRAD_SUM_DW[m] >
        localDW->EdgeDetection_GRAD_SUM_DW[m + 1] : TRUE))));
    }
  }
}

/* Model initialize function */
void mr_validation_gate_initialize(const char_T **rt_errorStatus,
  RT_MODEL_validation_gate *const validation_gate_M, rtB_mr_validation_gate
  *localB, rtDW_mr_validation_gate *localDW)
{
  /* Registration code */

  /* initialize non-finites */
  rt_InitInfAndNaN(sizeof(real_T));

  /* initialize error status */
  rtmSetErrorStatusPointer(validation_gate_M, rt_errorStatus);

  /* block I/O */
  (void) memset(((void *) localB), 0,
                sizeof(rtB_mr_validation_gate));

  /* states (dwork) */
  (void) memset((void *)localDW, 0,
                sizeof(rtDW_mr_validation_gate));
}

/*
 * File trailer for Real-Time Workshop generated code.
 *
 * [EOF]
 */
