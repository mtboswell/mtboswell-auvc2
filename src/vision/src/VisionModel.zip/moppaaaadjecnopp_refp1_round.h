/*
 * File: /home/auvt/auvc/src/vision/Final_Models/slprj/ert/_sharedutils/moppaaaadjecnopp_refp1_round.h
 *
 * Real-Time Workshop code generated for Simulink model buoy_detector.
 *
 * Model version                        : 1.645
 * Real-Time Workshop file version      : 7.6  (R2010b)  03-Aug-2010
 * Real-Time Workshop file generated on : Tue Jun  7 22:47:27 2011
 * TLC version                          : 7.6 (Jul 13 2010)
 * C/C++ source code generated on       : Tue Jun  7 22:47:28 2011
 */

#ifndef SHARE_moppaaaadjecnopp_refp1_round
#define SHARE_moppaaaadjecnopp_refp1_round

extern void moppaaaadjecnopp_refp1_round(real_T *x);

#endif

/*
 * File trailer for Real-Time Workshop generated code.
 *
 * [EOF]
 */
