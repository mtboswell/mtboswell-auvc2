/*
 * File: /home/auvt/auvc/src/vision/Final_Models/slprj/ert/_sharedutils/div_s32_floor.h
 *
 * Real-Time Workshop code generated for Simulink model validation_gate.
 *
 * Model version                        : 1.1183
 * Real-Time Workshop file version      : 7.6  (R2010b)  03-Aug-2010
 * Real-Time Workshop file generated on : Tue Jun 21 22:26:09 2011
 * TLC version                          : 7.6 (Jul 13 2010)
 * C/C++ source code generated on       : Tue Jun 21 22:26:10 2011
 */

#ifndef SHARE_div_s32_floor
#define SHARE_div_s32_floor

extern int32_T div_s32_floor(int32_T numerator, int32_T denominator);

#endif

/*
 * File trailer for Real-Time Workshop generated code.
 *
 * [EOF]
 */
