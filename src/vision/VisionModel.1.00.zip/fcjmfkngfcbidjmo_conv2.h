/*
 * File: /home/auvt/auvc/src/vision/Final_Models/slprj/ert/_sharedutils/fcjmfkngfcbidjmo_conv2.h
 *
 * Real-Time Workshop code generated for Simulink model buoy_detector.
 *
 * Model version                        : 1.645
 * Real-Time Workshop file version      : 7.6  (R2010b)  03-Aug-2010
 * Real-Time Workshop file generated on : Tue Jun  7 22:47:27 2011
 * TLC version                          : 7.6 (Jul 13 2010)
 * C/C++ source code generated on       : Tue Jun  7 22:47:28 2011
 */

#ifndef SHARE_fcjmfkngfcbidjmo_conv2
#define SHARE_fcjmfkngfcbidjmo_conv2

extern void fcjmfkngfcbidjmo_conv2(const real_T arg1[19200], const real_T arg2[9],
  real_T c[18644]);

#endif

/*
 * File trailer for Real-Time Workshop generated code.
 *
 * [EOF]
 */
