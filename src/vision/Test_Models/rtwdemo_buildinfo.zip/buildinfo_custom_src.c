/*
 *  File : sfun_buildinfo_src.c
 * 
 *  Abstract:
 *  Custom Source file for rtwdemo_buildinfo 
 *
 *  Copyright 1994-2006 The MathWorks, Inc.
 *  File : 
 *  $Revision: 1.1.8.1 $
 */
int buildinfo_custom_src(int i)
{
    return i;
    
}

