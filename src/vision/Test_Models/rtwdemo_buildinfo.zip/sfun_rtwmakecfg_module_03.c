/*
 *  File : sfun_rtwmakecfg_module_03.c
 * 
 *  Abstract:
 *  rtwmakecfg source file for demo rtwdemo_buildinfo. 
 *
 *  Copyright 1994-2006 The MathWorks, Inc.
 *  $Revision: 1.1.8.1 $
 */

int sfun_rtwmakecfg_module_03(int i)
{
    return i+3;
    
}

