/*
 * rtwdemo_buildinfo.c
 *
 * Real-Time Workshop code generation for Simulink model "rtwdemo_buildinfo.mdl".
 *
 * Model version              : 1.107
 * Real-Time Workshop version : 7.6  (R2010b)  03-Aug-2010
 * C source code generated on : Tue May 31 22:03:09 2011
 *
 * Target selection: grt.tlc
 * Note: GRT includes extra infrastructure and instrumentation for prototyping
 * Embedded hardware selection: Specified
 * Code generation objectives: Unspecified
 * Validation result: Not run
 */

#include "rtwdemo_buildinfo.h"
#include "rtwdemo_buildinfo_private.h"

/* Block signals (auto storage) */
BlockIO_rtwdemo_buildinfo rtwdemo_buildinfo_B;

/* Block states (auto storage) */
D_Work_rtwdemo_buildinfo rtwdemo_buildinfo_DWork;

/* External inputs (root inport signals with auto storage) */
ExternalInputs_rtwdemo_buildinfo rtwdemo_buildinfo_U;

/* External outputs (root outports fed by signals with auto storage) */
ExternalOutputs_rtwdemo_buildinfo rtwdemo_buildinfo_Y;

/* Real-time model */
RT_MODEL_rtwdemo_buildinfo rtwdemo_buildinfo_M_;
RT_MODEL_rtwdemo_buildinfo *rtwdemo_buildinfo_M = &rtwdemo_buildinfo_M_;

/* Model output function */
static void rtwdemo_buildinfo_output(int_T tid)
{
  /* Sum: '<Root>/Sum' incorporates:
   *  Inport: '<Root>/In1'
   *  Sin: '<Root>/Sine Wave'
   */
  rtwdemo_buildinfo_B.Sum = sin(rtwdemo_buildinfo_M->Timing.t[0]) * 2.0 +
    rtwdemo_buildinfo_U.In1;

  /* Level2 S-Function Block: '<Root>/S-Function' (sfun_buildinfo_timestwo) */
  {
    SimStruct *rts = rtwdemo_buildinfo_M->childSfunctions[0];
    sfcnOutputs(rts, 0);
  }

  /* Outport: '<Root>/Out1' */
  rtwdemo_buildinfo_Y.Out1 = rtwdemo_buildinfo_B.SFunction;

  /* tid is required for a uniform function interface.
   * Argument tid is not used in the function. */
  UNUSED_PARAMETER(tid);
}

/* Model update function */
static void rtwdemo_buildinfo_update(int_T tid)
{
  /* Update absolute time for base rate */
  /* The "clockTick0" counts the number of times the code of this task has
   * been executed. The absolute time is the multiplication of "clockTick0"
   * and "Timing.stepSize0". Size of "clockTick0" ensures timer will not
   * overflow during the application lifespan selected.
   * Timer of this task consists of two 32 bit unsigned integers.
   * The two integers represent the low bits Timing.clockTick0 and the high bits
   * Timing.clockTickH0. When the low bit overflows to 0, the high bits increment.
   */
  if (!(++rtwdemo_buildinfo_M->Timing.clockTick0)) {
    ++rtwdemo_buildinfo_M->Timing.clockTickH0;
  }

  rtwdemo_buildinfo_M->Timing.t[0] = rtwdemo_buildinfo_M->Timing.clockTick0 *
    rtwdemo_buildinfo_M->Timing.stepSize0 +
    rtwdemo_buildinfo_M->Timing.clockTickH0 *
    rtwdemo_buildinfo_M->Timing.stepSize0 * 4294967296.0;

  {
    /* Update absolute timer for sample time: [0.01s, 0.0s] */
    /* The "clockTick1" counts the number of times the code of this task has
     * been executed. The absolute time is the multiplication of "clockTick1"
     * and "Timing.stepSize1". Size of "clockTick1" ensures timer will not
     * overflow during the application lifespan selected.
     * Timer of this task consists of two 32 bit unsigned integers.
     * The two integers represent the low bits Timing.clockTick1 and the high bits
     * Timing.clockTickH1. When the low bit overflows to 0, the high bits increment.
     */
    if (!(++rtwdemo_buildinfo_M->Timing.clockTick1)) {
      ++rtwdemo_buildinfo_M->Timing.clockTickH1;
    }

    rtwdemo_buildinfo_M->Timing.t[1] = rtwdemo_buildinfo_M->Timing.clockTick1 *
      rtwdemo_buildinfo_M->Timing.stepSize1 +
      rtwdemo_buildinfo_M->Timing.clockTickH1 *
      rtwdemo_buildinfo_M->Timing.stepSize1 * 4294967296.0;
  }

  /* tid is required for a uniform function interface.
   * Argument tid is not used in the function. */
  UNUSED_PARAMETER(tid);
}

/* Model initialize function */
void rtwdemo_buildinfo_initialize(boolean_T firstTime)
{
  (void)firstTime;

  /* Registration code */

  /* initialize non-finites */
  rt_InitInfAndNaN(sizeof(real_T));

  /* initialize real-time model */
  (void) memset((void *)rtwdemo_buildinfo_M, 0,
                sizeof(RT_MODEL_rtwdemo_buildinfo));

  {
    /* Setup solver object */
    rtsiSetSimTimeStepPtr(&rtwdemo_buildinfo_M->solverInfo,
                          &rtwdemo_buildinfo_M->Timing.simTimeStep);
    rtsiSetTPtr(&rtwdemo_buildinfo_M->solverInfo, &rtmGetTPtr
                (rtwdemo_buildinfo_M));
    rtsiSetStepSizePtr(&rtwdemo_buildinfo_M->solverInfo,
                       &rtwdemo_buildinfo_M->Timing.stepSize0);
    rtsiSetErrorStatusPtr(&rtwdemo_buildinfo_M->solverInfo, (&rtmGetErrorStatus
      (rtwdemo_buildinfo_M)));
    rtsiSetRTModelPtr(&rtwdemo_buildinfo_M->solverInfo, rtwdemo_buildinfo_M);
  }

  rtsiSetSimTimeStep(&rtwdemo_buildinfo_M->solverInfo, MAJOR_TIME_STEP);
  rtsiSetSolverName(&rtwdemo_buildinfo_M->solverInfo,"FixedStepDiscrete");
  rtwdemo_buildinfo_M->solverInfoPtr = (&rtwdemo_buildinfo_M->solverInfo);

  /* Initialize timing info */
  {
    int_T *mdlTsMap = rtwdemo_buildinfo_M->Timing.sampleTimeTaskIDArray;
    mdlTsMap[0] = 0;
    mdlTsMap[1] = 1;
    rtwdemo_buildinfo_M->Timing.sampleTimeTaskIDPtr = (&mdlTsMap[0]);
    rtwdemo_buildinfo_M->Timing.sampleTimes =
      (&rtwdemo_buildinfo_M->Timing.sampleTimesArray[0]);
    rtwdemo_buildinfo_M->Timing.offsetTimes =
      (&rtwdemo_buildinfo_M->Timing.offsetTimesArray[0]);

    /* task periods */
    rtwdemo_buildinfo_M->Timing.sampleTimes[0] = (0.0);
    rtwdemo_buildinfo_M->Timing.sampleTimes[1] = (0.01);

    /* task offsets */
    rtwdemo_buildinfo_M->Timing.offsetTimes[0] = (0.0);
    rtwdemo_buildinfo_M->Timing.offsetTimes[1] = (0.0);
  }

  rtmSetTPtr(rtwdemo_buildinfo_M, &rtwdemo_buildinfo_M->Timing.tArray[0]);

  {
    int_T *mdlSampleHits = rtwdemo_buildinfo_M->Timing.sampleHitArray;
    mdlSampleHits[0] = 1;
    mdlSampleHits[1] = 1;
    rtwdemo_buildinfo_M->Timing.sampleHits = (&mdlSampleHits[0]);
  }

  rtmSetTFinal(rtwdemo_buildinfo_M, 10.0);
  rtwdemo_buildinfo_M->Timing.stepSize0 = 0.01;
  rtwdemo_buildinfo_M->Timing.stepSize1 = 0.01;
  rtwdemo_buildinfo_M->solverInfoPtr = (&rtwdemo_buildinfo_M->solverInfo);
  rtwdemo_buildinfo_M->Timing.stepSize = (0.01);
  rtsiSetFixedStepSize(&rtwdemo_buildinfo_M->solverInfo, 0.01);
  rtsiSetSolverMode(&rtwdemo_buildinfo_M->solverInfo, SOLVER_MODE_SINGLETASKING);

  /* block I/O */
  rtwdemo_buildinfo_M->ModelData.blockIO = ((void *) &rtwdemo_buildinfo_B);
  (void) memset(((void *) &rtwdemo_buildinfo_B), 0,
                sizeof(BlockIO_rtwdemo_buildinfo));

  /* states (dwork) */
  rtwdemo_buildinfo_M->Work.dwork = ((void *) &rtwdemo_buildinfo_DWork);
  (void) memset((void *)&rtwdemo_buildinfo_DWork, 0,
                sizeof(D_Work_rtwdemo_buildinfo));

  /* external inputs */
  rtwdemo_buildinfo_M->ModelData.inputs = (((void*)&rtwdemo_buildinfo_U));
  rtwdemo_buildinfo_U.In1 = 0.0;

  /* external outputs */
  rtwdemo_buildinfo_M->ModelData.outputs = (&rtwdemo_buildinfo_Y);
  rtwdemo_buildinfo_Y.Out1 = 0.0;

  /* child S-Function registration */
  {
    RTWSfcnInfo *sfcnInfo = &rtwdemo_buildinfo_M->NonInlinedSFcns.sfcnInfo;
    rtwdemo_buildinfo_M->sfcnInfo = (sfcnInfo);
    rtssSetErrorStatusPtr(sfcnInfo, (&rtmGetErrorStatus(rtwdemo_buildinfo_M)));
    rtssSetNumRootSampTimesPtr(sfcnInfo,
      &rtwdemo_buildinfo_M->Sizes.numSampTimes);
    rtssSetTPtrPtr(sfcnInfo, &rtmGetTPtr(rtwdemo_buildinfo_M));
    rtssSetTStartPtr(sfcnInfo, &rtmGetTStart(rtwdemo_buildinfo_M));
    rtssSetTFinalPtr(sfcnInfo, &rtmGetTFinal(rtwdemo_buildinfo_M));
    rtssSetTimeOfLastOutputPtr(sfcnInfo, &rtmGetTimeOfLastOutput
      (rtwdemo_buildinfo_M));
    rtssSetStepSizePtr(sfcnInfo, &rtwdemo_buildinfo_M->Timing.stepSize);
    rtssSetStopRequestedPtr(sfcnInfo, &rtmGetStopRequested(rtwdemo_buildinfo_M));
    rtssSetDerivCacheNeedsResetPtr(sfcnInfo,
      &rtwdemo_buildinfo_M->ModelData.derivCacheNeedsReset);
    rtssSetZCCacheNeedsResetPtr(sfcnInfo,
      &rtwdemo_buildinfo_M->ModelData.zCCacheNeedsReset);
    rtssSetBlkStateChangePtr(sfcnInfo,
      &rtwdemo_buildinfo_M->ModelData.blkStateChange);
    rtssSetSampleHitsPtr(sfcnInfo, &rtwdemo_buildinfo_M->Timing.sampleHits);
    rtssSetPerTaskSampleHitsPtr(sfcnInfo,
      &rtwdemo_buildinfo_M->Timing.perTaskSampleHits);
    rtssSetSimModePtr(sfcnInfo, &rtwdemo_buildinfo_M->simMode);
    rtssSetSolverInfoPtr(sfcnInfo, &rtwdemo_buildinfo_M->solverInfoPtr);
  }

  rtwdemo_buildinfo_M->Sizes.numSFcns = (1);

  /* register each child */
  {
    (void) memset((void *)&rtwdemo_buildinfo_M->NonInlinedSFcns.childSFunctions
                  [0], 0,
                  1*sizeof(SimStruct));
    rtwdemo_buildinfo_M->childSfunctions =
      (&rtwdemo_buildinfo_M->NonInlinedSFcns.childSFunctionPtrs[0]);
    rtwdemo_buildinfo_M->childSfunctions[0] =
      (&rtwdemo_buildinfo_M->NonInlinedSFcns.childSFunctions[0]);

    /* Level2 S-Function Block: rtwdemo_buildinfo/<Root>/S-Function (sfun_buildinfo_timestwo) */
    {
      SimStruct *rts = rtwdemo_buildinfo_M->childSfunctions[0];

      /* timing info */
      time_T *sfcnPeriod = rtwdemo_buildinfo_M->NonInlinedSFcns.Sfcn0.sfcnPeriod;
      time_T *sfcnOffset = rtwdemo_buildinfo_M->NonInlinedSFcns.Sfcn0.sfcnOffset;
      int_T *sfcnTsMap = rtwdemo_buildinfo_M->NonInlinedSFcns.Sfcn0.sfcnTsMap;
      (void) memset((void*)sfcnPeriod, 0,
                    sizeof(time_T)*1);
      (void) memset((void*)sfcnOffset, 0,
                    sizeof(time_T)*1);
      ssSetSampleTimePtr(rts, &sfcnPeriod[0]);
      ssSetOffsetTimePtr(rts, &sfcnOffset[0]);
      ssSetSampleTimeTaskIDPtr(rts, sfcnTsMap);

      /* Set up the mdlInfo pointer */
      {
        ssSetBlkInfo2Ptr(rts, &rtwdemo_buildinfo_M->NonInlinedSFcns.blkInfo2[0]);
      }

      ssSetRTWSfcnInfo(rts, rtwdemo_buildinfo_M->sfcnInfo);

      /* Allocate memory of model methods 2 */
      {
        ssSetModelMethods2(rts, &rtwdemo_buildinfo_M->NonInlinedSFcns.methods2[0]);
      }

      /* Allocate memory of model methods 3 */
      {
        ssSetModelMethods3(rts, &rtwdemo_buildinfo_M->NonInlinedSFcns.methods3[0]);
      }

      /* inputs */
      {
        _ssSetNumInputPorts(rts, 1);
        ssSetPortInfoForInputs(rts,
          &rtwdemo_buildinfo_M->NonInlinedSFcns.Sfcn0.inputPortInfo[0]);

        /* port 0 */
        {
          real_T const **sfcnUPtrs = (real_T const **)
            &rtwdemo_buildinfo_M->NonInlinedSFcns.Sfcn0.UPtrs0;
          sfcnUPtrs[0] = &rtwdemo_buildinfo_B.Sum;
          ssSetInputPortSignalPtrs(rts, 0, (InputPtrsType)&sfcnUPtrs[0]);
          _ssSetInputPortNumDimensions(rts, 0, 1);
          ssSetInputPortWidth(rts, 0, 1);
        }
      }

      /* outputs */
      {
        ssSetPortInfoForOutputs(rts,
          &rtwdemo_buildinfo_M->NonInlinedSFcns.Sfcn0.outputPortInfo[0]);
        _ssSetNumOutputPorts(rts, 1);

        /* port 0 */
        {
          _ssSetOutputPortNumDimensions(rts, 0, 1);
          ssSetOutputPortWidth(rts, 0, 1);
          ssSetOutputPortSignal(rts, 0, ((real_T *)
            &rtwdemo_buildinfo_B.SFunction));
        }
      }

      /* path info */
      ssSetModelName(rts, "S-Function");
      ssSetPath(rts, "rtwdemo_buildinfo/S-Function");
      ssSetRTModel(rts,rtwdemo_buildinfo_M);
      ssSetParentSS(rts, (NULL));
      ssSetRootSS(rts, rts);
      ssSetVersion(rts, SIMSTRUCT_VERSION_LEVEL2);

      /* registration */
      sfun_buildinfo_timestwo(rts);
      sfcnInitializeSizes(rts);
      sfcnInitializeSampleTimes(rts);

      /* adjust sample time */
      ssSetSampleTime(rts, 0, 0.0);
      ssSetOffsetTime(rts, 0, 0.0);
      sfcnTsMap[0] = 0;

      /* set compiled values of dynamic vector attributes */
      ssSetInputPortWidth(rts, 0, 1);
      ssSetInputPortDataType(rts, 0, SS_DOUBLE);
      ssSetInputPortComplexSignal(rts, 0, 0);
      ssSetInputPortFrameData(rts, 0, 0);
      ssSetOutputPortWidth(rts, 0, 1);
      ssSetOutputPortDataType(rts, 0, SS_DOUBLE);
      ssSetOutputPortComplexSignal(rts, 0, 0);
      ssSetOutputPortFrameData(rts, 0, 0);
      ssSetNumNonsampledZCs(rts, 0);

      /* Update connectivity flags for each port */
      _ssSetInputPortConnected(rts, 0, 1);
      _ssSetOutputPortConnected(rts, 0, 1);
      _ssSetOutputPortBeingMerged(rts, 0, 0);

      /* Update the BufferDstPort flags for each input port */
      ssSetInputPortBufferDstPort(rts, 0, -1);
    }
  }
}

/* Model terminate function */
void rtwdemo_buildinfo_terminate(void)
{
  /* Level2 S-Function Block: '<Root>/S-Function' (sfun_buildinfo_timestwo) */
  {
    SimStruct *rts = rtwdemo_buildinfo_M->childSfunctions[0];
    sfcnTerminate(rts);
  }
}

/*========================================================================*
 * Start of GRT compatible call interface                                 *
 *========================================================================*/
void MdlOutputs(int_T tid)
{
  rtwdemo_buildinfo_output(tid);
}

void MdlUpdate(int_T tid)
{
  rtwdemo_buildinfo_update(tid);
}

void MdlInitializeSizes(void)
{
  rtwdemo_buildinfo_M->Sizes.numContStates = (0);/* Number of continuous states */
  rtwdemo_buildinfo_M->Sizes.numY = (1);/* Number of model outputs */
  rtwdemo_buildinfo_M->Sizes.numU = (1);/* Number of model inputs */
  rtwdemo_buildinfo_M->Sizes.sysDirFeedThru = (1);/* The model is direct feedthrough */
  rtwdemo_buildinfo_M->Sizes.numSampTimes = (2);/* Number of sample times */
  rtwdemo_buildinfo_M->Sizes.numBlocks = (5);/* Number of blocks */
  rtwdemo_buildinfo_M->Sizes.numBlockIO = (2);/* Number of block outputs */
}

void MdlInitializeSampleTimes(void)
{
}

void MdlInitialize(void)
{
}

void MdlStart(void)
{
  MdlInitialize();
}

void MdlTerminate(void)
{
  rtwdemo_buildinfo_terminate();
}

RT_MODEL_rtwdemo_buildinfo *rtwdemo_buildinfo(void)
{
  rtwdemo_buildinfo_initialize(1);
  return rtwdemo_buildinfo_M;
}

/*========================================================================*
 * End of GRT compatible call interface                                   *
 *========================================================================*/
