/* Copyright 2007 The MathWorks, Inc. */
/* Provided the function proto-type for Simple Table */
extern double SimpleTable(double xIn, double xAxis[], double yAxis[], int axisLength);

