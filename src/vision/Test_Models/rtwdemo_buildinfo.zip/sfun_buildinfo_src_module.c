/*
 *  File : sfun_buildinfo_src.c
 * 
 *  Abstract:
 *  S-Function Source module for rtwdemo_buildinfo 
 *
 *  Copyright 1994-2006 The MathWorks, Inc.
 *  $Revision: 1.1.8.1 $
 */

int sfun_buildinfo_src_module_func(int i)
{
    return i*2;
    
}

