/* Copyright 2009 The MathWorks, Inc. */
#define MODE 1
