/*
 *  File : sfun_buildinfo_src.c
 * 
 *  Abstract:
 *  rtwmakecfg source file for rtwdemo_buildinfo 
 *
 *  Copyright 1994-2006 The MathWorks, Inc.
 *  File : 
 *  $Revision: 1.1.8.1 $
 */
int buildinfo_rtwmakecfg_src(int i)
{
    return i;
    
}

