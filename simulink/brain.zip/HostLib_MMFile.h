/**
 * @file HostLib_MMFile.h
 * @brief Helper for the To/FromMMFile block.
 * Copyright 2008-2009 The MathWorks, Inc.
 * $Revision: 1.1.6.5 $ $Date: 2009/08/14 03:57:13 $
 */ 


/* Wrap everything in extern C */
#ifdef __cplusplus
extern "C" {
#endif 

extern const char *libName_FromMMFile;
extern const char *libName_ToMMFile;

#include "VideoDefs.h"
#include "AudioDefs.h"
  
/*******************************
 * Routines which are defined in the library in question
 *******************************/
typedef void* (*pFnLibCreate_FromMMFile)(char *err, char *warn, const char *fileName, 
                                         MMAudioInfo* aInfo, MMVideoInfo* vInfo, 
                                         unsigned int numRepeats, unsigned char loopIndef, 
                                         FourCCType fourcc,
                                         unsigned char scaledDoubleAudio, unsigned char scaledDoubleVideo);
typedef void (*pFnLibOutputs_FromMMFile)(void *hostLib, char *err, unsigned char *bDone, void *audio, void *R, void *G, void *B);


typedef void* (*pFnLibCreate_ToMMFile)(char *err, char *warn, const char *fileName, MMFileType fileType,
                                       MMAudioInfo* aInfo, MMVideoInfo* vInfo,
                                       unsigned char scaledDoubleAudio, unsigned char scaledDoubleVideo);
typedef void (*pFnLibUpdate_ToMMFile)(void *hostLib, char *err, const void *audio, const void *R, const void *G, const void *B);


/*******************************
 * Routines which we define to call the functions in the library 
 *******************************/
void LibCreate_FromMMFile(void *hostLib, char *warn, const char *fileName,
                          void* aInfo, void* vInfo, 
                          unsigned int numRepeats, unsigned char loopIndef, 
                          int fourcc,
                          unsigned char scaledDoubleAudio, unsigned char scaledDoubleVideo);
void LibOutputs_FromMMFile(void *hostLib, void *bDone, void *audio, void *R, void *G, void *B);


void LibCreate_ToMMFile(void *hostLib, char *warn, const char *fileName, int fileType,
                        void* aInfo, void* vInfo,
                        unsigned char scaledDoubleAudio, unsigned char scaledDoubleVideo);
void LibUpdate_ToMMFile(void *hostLib, const void *audio, const void *R, const void *G, const void *B);


/* Include HostLib for declarations of LibStart, LibTerminate, CreateHostLibrary, and DestroyHostLibrary. */
#include "HostLib_rtw.h"


#ifdef __cplusplus
} // extern "C"
#endif 

